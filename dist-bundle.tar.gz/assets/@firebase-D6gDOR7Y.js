import{R as co}from"./re2js-lP7qdP7J.js";import{o as yf}from"./idb-BXWtuYvb.js";const Ef=()=>{};var lu={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gc=function(n){const t=[];let e=0;for(let r=0;r<n.length;r++){let s=n.charCodeAt(r);s<128?t[e++]=s:s<2048?(t[e++]=s>>6|192,t[e++]=s&63|128):(s&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(s=65536+((s&1023)<<10)+(n.charCodeAt(++r)&1023),t[e++]=s>>18|240,t[e++]=s>>12&63|128,t[e++]=s>>6&63|128,t[e++]=s&63|128):(t[e++]=s>>12|224,t[e++]=s>>6&63|128,t[e++]=s&63|128)}return t},Tf=function(n){const t=[];let e=0,r=0;for(;e<n.length;){const s=n[e++];if(s<128)t[r++]=String.fromCharCode(s);else if(s>191&&s<224){const o=n[e++];t[r++]=String.fromCharCode((s&31)<<6|o&63)}else if(s>239&&s<365){const o=n[e++],a=n[e++],c=n[e++],h=((s&7)<<18|(o&63)<<12|(a&63)<<6|c&63)-65536;t[r++]=String.fromCharCode(55296+(h>>10)),t[r++]=String.fromCharCode(56320+(h&1023))}else{const o=n[e++],a=n[e++];t[r++]=String.fromCharCode((s&15)<<12|(o&63)<<6|a&63)}}return t.join("")},_c={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,t){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const e=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let s=0;s<n.length;s+=3){const o=n[s],a=s+1<n.length,c=a?n[s+1]:0,h=s+2<n.length,f=h?n[s+2]:0,p=o>>2,m=(o&3)<<4|c>>4;let I=(c&15)<<2|f>>6,b=f&63;h||(b=64,a||(I=64)),r.push(e[p],e[m],e[I],e[b])}return r.join("")},encodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(n):this.encodeByteArray(gc(n),t)},decodeString(n,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(n):Tf(this.decodeStringToByteArray(n,t))},decodeStringToByteArray(n,t){this.init_();const e=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let s=0;s<n.length;){const o=e[n.charAt(s++)],c=s<n.length?e[n.charAt(s)]:0;++s;const f=s<n.length?e[n.charAt(s)]:64;++s;const m=s<n.length?e[n.charAt(s)]:64;if(++s,o==null||c==null||f==null||m==null)throw new wf;const I=o<<2|c>>4;if(r.push(I),f!==64){const b=c<<4&240|f>>2;if(r.push(b),m!==64){const C=f<<6&192|m;r.push(C)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class wf extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const vf=function(n){const t=gc(n);return _c.encodeByteArray(t,!0)},Es=function(n){return vf(n).replace(/\./g,"")},If=function(n){try{return _c.decodeString(n,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Af(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rf=()=>Af().__FIREBASE_DEFAULTS__,Vf=()=>{if(typeof process>"u"||typeof lu>"u")return;const n=lu.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},Pf=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=n&&If(n[1]);return t&&JSON.parse(t)},Ms=()=>{try{return Ef()||Rf()||Vf()||Pf()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},bf=n=>{var t,e;return(e=(t=Ms())==null?void 0:t.emulatorHosts)==null?void 0:e[n]},yc=n=>{const t=bf(n);if(!t)return;const e=t.lastIndexOf(":");if(e<=0||e+1===t.length)throw new Error(`Invalid host ${t} with no separate hostname and port!`);const r=parseInt(t.substring(e+1),10);return t[0]==="["?[t.substring(1,e-1),r]:[t.substring(0,e),r]},Ec=()=>{var n;return(n=Ms())==null?void 0:n.config},$E=n=>{var t;return(t=Ms())==null?void 0:t[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sf{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}wrapCallback(t){return(e,r)=>{e?this.reject(e):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(e):t(e,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tc(n,t){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const e={alg:"none",type:"JWT"},r=t||"demo-project",s=n.iat||0,o=n.sub||n.user_id;if(!o)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const a={iss:`https://securetoken.google.com/${r}`,aud:r,iat:s,exp:s+3600,auth_time:s,sub:o,user_id:o,firebase:{sign_in_provider:"custom",identities:{}},...n};return[Es(JSON.stringify(e)),Es(JSON.stringify(a)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lo(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function zE(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(lo())}function Cf(){var t;const n=(t=Ms())==null?void 0:t.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function GE(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function HE(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function WE(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function QE(){const n=lo();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function xf(){return!Cf()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function Nf(){try{return typeof indexedDB=="object"}catch{return!1}}function Df(){return new Promise((n,t)=>{try{let e=!0;const r="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(r);s.onsuccess=()=>{s.result.close(),e||self.indexedDB.deleteDatabase(r),n(!0)},s.onupgradeneeded=()=>{e=!1},s.onerror=()=>{var o;t(((o=s.error)==null?void 0:o.message)||"")}}catch(e){t(e)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kf="FirebaseError";class an extends Error{constructor(t,e,r){super(e),this.code=t,this.customData=r,this.name=kf,Object.setPrototypeOf(this,an.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,wc.prototype.create)}}class wc{constructor(t,e,r){this.service=t,this.serviceName=e,this.errors=r}create(t,...e){const r=e[0]||{},s=`${this.service}/${t}`,o=this.errors[t],a=o?Of(o,r):"Error",c=`${this.serviceName}: ${a} (${s}).`;return new an(s,c,r)}}function Of(n,t){try{let e=0,r="";for(;e<n.length;){const s=n.indexOf("{$",e);if(s===-1){r+=n.substring(e);break}const o=n.indexOf("}",s+2);if(o===-1){r+=n.substring(e);break}const a=n.substring(s+2,o),c=t[a];r+=n.substring(e,s)+(c!=null?String(c):`<${a}?>`),e=o+1}return r}catch{return n}}function KE(n){for(const t in n)if(Object.prototype.hasOwnProperty.call(n,t))return!1;return!0}function Ts(n,t){if(n===t)return!0;const e=Object.keys(n),r=Object.keys(t);for(const s of e){if(!r.includes(s))return!1;const o=n[s],a=t[s];if(hu(o)&&hu(a)){if(!Ts(o,a))return!1}else if(o!==a)return!1}for(const s of r)if(!e.includes(s))return!1;return!0}function hu(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function XE(n){const t=[];for(const[e,r]of Object.entries(n))Array.isArray(r)?r.forEach(s=>{t.push(encodeURIComponent(e)+"="+encodeURIComponent(s))}):t.push(encodeURIComponent(e)+"="+encodeURIComponent(r));return t.length?"&"+t.join("&"):""}function JE(n){const t={};return n.replace(/^\?/,"").split("&").forEach(r=>{if(r){const[s,o]=r.split("=");t[decodeURIComponent(s)]=decodeURIComponent(o)}}),t}function YE(n){const t=n.indexOf("?");if(!t)return"";const e=n.indexOf("#",t);return n.substring(t,e>0?e:void 0)}function ZE(n,t){const e=new Lf(n,t);return e.subscribe.bind(e)}class Lf{constructor(t,e){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=e,this.task.then(()=>{t(this)}).catch(r=>{this.error(r)})}next(t){this.forEachObserver(e=>{e.next(t)})}error(t){this.forEachObserver(e=>{e.error(t)}),this.close(t)}complete(){this.forEachObserver(t=>{t.complete()}),this.close()}subscribe(t,e,r){let s;if(t===void 0&&e===void 0&&r===void 0)throw new Error("Missing Observer.");Mf(t,["next","error","complete"])?s=t:s={next:t,error:e,complete:r},s.next===void 0&&(s.next=xi),s.error===void 0&&(s.error=xi),s.complete===void 0&&(s.complete=xi);const o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),o}unsubscribeOne(t){this.observers===void 0||this.observers[t]===void 0||(delete this.observers[t],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(t){if(!this.finalized)for(let e=0;e<this.observers.length;e++)this.sendOne(e,t)}sendOne(t,e){this.task.then(()=>{if(this.observers!==void 0&&this.observers[t]!==void 0)try{e(this.observers[t])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(t){this.finalized||(this.finalized=!0,t!==void 0&&(this.finalError=t),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Mf(n,t){if(typeof n!="object"||n===null)return!1;for(const e of t)if(e in n&&typeof n[e]=="function")return!0;return!1}function xi(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yt(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Us(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function vc(n){return(await fetch(n,{credentials:"include"})).ok}class vn{constructor(t,e,r){this.name=t,this.instanceFactory=e,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const We="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uf{constructor(t,e){this.name=t,this.container=e,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const e=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(e)){const r=new Sf;if(this.instancesDeferred.set(e,r),this.isInitialized(e)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:e});s&&r.resolve(s)}catch{}}return this.instancesDeferred.get(e).promise}getImmediate(t){const e=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),r=(t==null?void 0:t.optional)??!1;if(this.isInitialized(e)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:e})}catch(s){if(r)return null;throw s}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(Bf(t))try{this.getOrInitializeService({instanceIdentifier:We})}catch{}for(const[e,r]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(e);try{const o=this.getOrInitializeService({instanceIdentifier:s});r.resolve(o)}catch{}}}}clearInstance(t=We){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(e=>"INTERNAL"in e).map(e=>e.INTERNAL.delete()),...t.filter(e=>"_delete"in e).map(e=>e._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=We){return this.instances.has(t)}getOptions(t=We){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:e={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:r,options:e});for(const[o,a]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(o);r===c&&a.resolve(s)}return s}onInit(t,e){const r=this.normalizeInstanceIdentifier(e),s=this.onInitCallbacks.get(r)??new Set;s.add(t),this.onInitCallbacks.set(r,s);const o=this.instances.get(r);return o&&t(o,r),()=>{s.delete(t)}}invokeOnInitCallbacks(t,e){const r=this.onInitCallbacks.get(e);if(r)for(const s of r)try{s(t,e)}catch{}}getOrInitializeService({instanceIdentifier:t,options:e={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Ff(t),options:e}),this.instances.set(t,r),this.instancesOptions.set(t,e),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=We){return this.component?this.component.multipleInstances?t:We:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Ff(n){return n===We?void 0:n}function Bf(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jf{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const e=this.getProvider(t.name);if(e.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);e.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const e=new Uf(t,this);return this.providers.set(t,e),e}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var X;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(X||(X={}));const qf={debug:X.DEBUG,verbose:X.VERBOSE,info:X.INFO,warn:X.WARN,error:X.ERROR,silent:X.SILENT},$f=X.INFO,zf={[X.DEBUG]:"log",[X.VERBOSE]:"log",[X.INFO]:"info",[X.WARN]:"warn",[X.ERROR]:"error"},Gf=(n,t,...e)=>{if(t<n.logLevel)return;const r=new Date().toISOString(),s=zf[t];if(s)console[s](`[${r}]  ${n.name}:`,...e);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class Ic{constructor(t){this.name=t,this._logLevel=$f,this._logHandler=Gf,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in X))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?qf[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,X.DEBUG,...t),this._logHandler(this,X.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,X.VERBOSE,...t),this._logHandler(this,X.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,X.INFO,...t),this._logHandler(this,X.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,X.WARN,...t),this._logHandler(this,X.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,X.ERROR,...t),this._logHandler(this,X.ERROR,...t)}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hf{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(e=>{if(Wf(e)){const r=e.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(e=>e).join(" ")}}function Wf(n){const t=n.getComponent();return(t==null?void 0:t.type)==="VERSION"}const qi="@firebase/app",fu="0.16.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _e=new Ic("@firebase/app"),Qf="@firebase/app-compat",Kf="@firebase/analytics-compat",Xf="@firebase/analytics",Jf="@firebase/app-check-compat",Yf="@firebase/app-check",Zf="@firebase/auth",td="@firebase/auth-compat",ed="@firebase/database",nd="@firebase/data-connect",rd="@firebase/database-compat",sd="@firebase/functions",id="@firebase/functions-compat",od="@firebase/installations",ad="@firebase/installations-compat",ud="@firebase/messaging",cd="@firebase/messaging-compat",ld="@firebase/performance",hd="@firebase/performance-compat",fd="@firebase/remote-config",dd="@firebase/remote-config-compat",pd="@firebase/storage",md="@firebase/storage-compat",gd="@firebase/firestore",_d="@firebase/ai",yd="@firebase/firestore-compat",Ed="firebase",Td="12.17.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $i="[DEFAULT]",wd={[qi]:"fire-core",[Qf]:"fire-core-compat",[Xf]:"fire-analytics",[Kf]:"fire-analytics-compat",[Yf]:"fire-app-check",[Jf]:"fire-app-check-compat",[Zf]:"fire-auth",[td]:"fire-auth-compat",[ed]:"fire-rtdb",[nd]:"fire-data-connect",[rd]:"fire-rtdb-compat",[sd]:"fire-fn",[id]:"fire-fn-compat",[od]:"fire-iid",[ad]:"fire-iid-compat",[ud]:"fire-fcm",[cd]:"fire-fcm-compat",[ld]:"fire-perf",[hd]:"fire-perf-compat",[fd]:"fire-rc",[dd]:"fire-rc-compat",[pd]:"fire-gcs",[md]:"fire-gcs-compat",[gd]:"fire-fst",[yd]:"fire-fst-compat",[_d]:"fire-vertex","fire-js":"fire-js",[Ed]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pr=new Map,vd=new Map,zi=new Map;function du(n,t){try{n.container.addComponent(t)}catch(e){_e.debug(`Component ${t.name} failed to register with FirebaseApp ${n.name}`,e)}}function mr(n){const t=n.name;if(zi.has(t))return _e.debug(`There were multiple attempts to register component ${t}.`),!1;zi.set(t,n);for(const e of pr.values())du(e,n);for(const e of vd.values())du(e,n);return!0}function Ac(n,t){const e=n.container.getProvider("heartbeat").getImmediate({optional:!0});return e&&e.triggerHeartbeat(),n.container.getProvider(t)}function Rc(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Id={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},fe=new wc("app","Firebase",Id);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ad{constructor(t,e,r){this._isDeleted=!1,this._options={...t},this._config={...e},this._name=e.name,this._automaticDataCollectionEnabled=e.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new vn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw fe.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vc=Td;function Rd(n,t={}){let e=n;typeof t!="object"&&(t={name:t});const r={name:$i,automaticDataCollectionEnabled:!0,...t},s=r.name;if(typeof s!="string"||!s)throw fe.create("bad-app-name",{appName:String(s)});if(e||(e=Ec()),!e)throw fe.create("no-options");const o=pr.get(s);if(o)if(Ts(e,o.options)){if(Ts(r,o.config))return o;throw fe.create("duplicate-app",{appName:s,mismatchedParam:"config",oldValue:JSON.stringify(o.config),newValue:JSON.stringify(r)})}else throw fe.create("duplicate-app",{appName:s,mismatchedParam:"options",oldValue:JSON.stringify(o.options),newValue:JSON.stringify(e)});const a=new jf(s);for(const h of zi.values())a.addComponent(h);const c=new Ad(e,r,a);return pr.set(s,c),c}function Pc(n=$i){const t=pr.get(n);if(!t&&n===$i&&Ec())return Rd();if(!t)throw fe.create("no-app",{appName:n});return t}function tT(){return Array.from(pr.values())}function Xe(n,t,e){let r=wd[n]??n;e&&(r+=`-${e}`);const s=r.match(/\s|\//),o=t.match(/\s|\//);if(s||o){const a=[`Unable to register library "${r}" with version "${t}":`];s&&a.push(`library name "${r}" contains illegal characters (whitespace or "/")`),s&&o&&a.push("and"),o&&a.push(`version name "${t}" contains illegal characters (whitespace or "/")`),_e.warn(a.join(" "));return}mr(new vn(`${r}-version`,()=>({library:r,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vd="firebase-heartbeat-database",Pd=1,gr="firebase-heartbeat-store";let Ni=null;function bc(){return Ni||(Ni=yf(Vd,Pd,{upgrade:(n,t)=>{switch(t){case 0:try{n.createObjectStore(gr)}catch(e){console.warn(e)}}}}).catch(n=>{throw fe.create("idb-open",{originalErrorMessage:n.message})})),Ni}async function bd(n){try{const e=(await bc()).transaction(gr),r=await e.objectStore(gr).get(Sc(n));return await e.done,r}catch(t){if(t instanceof an)_e.warn(t.message);else{const e=fe.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});_e.warn(e.message)}}}async function pu(n,t){try{const r=(await bc()).transaction(gr,"readwrite");await r.objectStore(gr).put(t,Sc(n)),await r.done}catch(e){if(e instanceof an)_e.warn(e.message);else{const r=fe.create("idb-set",{originalErrorMessage:e==null?void 0:e.message});_e.warn(r.message)}}}function Sc(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sd=1024,Cd=30;class xd{constructor(t){this.container=t,this._heartbeatsCache=null;const e=this.container.getProvider("app").getImmediate();this._storage=new Dd(e),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var t,e;try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),o=mu();if(((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===o||this._heartbeatsCache.heartbeats.some(a=>a.date===o))return;if(this._heartbeatsCache.heartbeats.push({date:o,agent:s}),this._heartbeatsCache.heartbeats.length>Cd){const a=kd(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(a,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){_e.warn(r)}}async getHeartbeatsHeader(){var t;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const e=mu(),{heartbeatsToSend:r,unsentEntries:s}=Nd(this._heartbeatsCache.heartbeats),o=Es(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=e,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}catch(e){return _e.warn(e),""}}}function mu(){return new Date().toISOString().substring(0,10)}function Nd(n,t=Sd){const e=[];let r=n.slice();for(const s of n){const o=e.find(a=>a.agent===s.agent);if(o){if(o.dates.push(s.date),gu(e)>t){o.dates.pop();break}}else if(e.push({agent:s.agent,dates:[s.date]}),gu(e)>t){e.pop();break}r=r.slice(1)}return{heartbeatsToSend:e,unsentEntries:r}}class Dd{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Nf()?Df().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const e=await bd(this.app);return e!=null&&e.heartbeats?e:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return pu(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return pu(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...t.heartbeats]})}else return}}function gu(n){return Es(JSON.stringify({version:2,heartbeats:n})).length}function kd(n){if(n.length===0)return-1;let t=0,e=n[0].date;for(let r=1;r<n.length;r++)n[r].date<e&&(e=n[r].date,t=r);return t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Od(n){mr(new vn("platform-logger",t=>new Hf(t),"PRIVATE")),mr(new vn("heartbeat",t=>new xd(t),"PRIVATE")),Xe(qi,fu,n),Xe(qi,fu,"esm2020"),Xe("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Od("");var _u=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var be,Cc;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function t(w,g){function y(){}y.prototype=g.prototype,w.F=g.prototype,w.prototype=new y,w.prototype.constructor=w,w.D=function(v,T,R){for(var _=Array(arguments.length-2),Dt=2;Dt<arguments.length;Dt++)_[Dt-2]=arguments[Dt];return g.prototype[T].apply(v,_)}}function e(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}t(r,e),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(w,g,y){y||(y=0);const v=Array(16);if(typeof g=="string")for(var T=0;T<16;++T)v[T]=g.charCodeAt(y++)|g.charCodeAt(y++)<<8|g.charCodeAt(y++)<<16|g.charCodeAt(y++)<<24;else for(T=0;T<16;++T)v[T]=g[y++]|g[y++]<<8|g[y++]<<16|g[y++]<<24;g=w.g[0],y=w.g[1],T=w.g[2];let R=w.g[3],_;_=g+(R^y&(T^R))+v[0]+3614090360&4294967295,g=y+(_<<7&4294967295|_>>>25),_=R+(T^g&(y^T))+v[1]+3905402710&4294967295,R=g+(_<<12&4294967295|_>>>20),_=T+(y^R&(g^y))+v[2]+606105819&4294967295,T=R+(_<<17&4294967295|_>>>15),_=y+(g^T&(R^g))+v[3]+3250441966&4294967295,y=T+(_<<22&4294967295|_>>>10),_=g+(R^y&(T^R))+v[4]+4118548399&4294967295,g=y+(_<<7&4294967295|_>>>25),_=R+(T^g&(y^T))+v[5]+1200080426&4294967295,R=g+(_<<12&4294967295|_>>>20),_=T+(y^R&(g^y))+v[6]+2821735955&4294967295,T=R+(_<<17&4294967295|_>>>15),_=y+(g^T&(R^g))+v[7]+4249261313&4294967295,y=T+(_<<22&4294967295|_>>>10),_=g+(R^y&(T^R))+v[8]+1770035416&4294967295,g=y+(_<<7&4294967295|_>>>25),_=R+(T^g&(y^T))+v[9]+2336552879&4294967295,R=g+(_<<12&4294967295|_>>>20),_=T+(y^R&(g^y))+v[10]+4294925233&4294967295,T=R+(_<<17&4294967295|_>>>15),_=y+(g^T&(R^g))+v[11]+2304563134&4294967295,y=T+(_<<22&4294967295|_>>>10),_=g+(R^y&(T^R))+v[12]+1804603682&4294967295,g=y+(_<<7&4294967295|_>>>25),_=R+(T^g&(y^T))+v[13]+4254626195&4294967295,R=g+(_<<12&4294967295|_>>>20),_=T+(y^R&(g^y))+v[14]+2792965006&4294967295,T=R+(_<<17&4294967295|_>>>15),_=y+(g^T&(R^g))+v[15]+1236535329&4294967295,y=T+(_<<22&4294967295|_>>>10),_=g+(T^R&(y^T))+v[1]+4129170786&4294967295,g=y+(_<<5&4294967295|_>>>27),_=R+(y^T&(g^y))+v[6]+3225465664&4294967295,R=g+(_<<9&4294967295|_>>>23),_=T+(g^y&(R^g))+v[11]+643717713&4294967295,T=R+(_<<14&4294967295|_>>>18),_=y+(R^g&(T^R))+v[0]+3921069994&4294967295,y=T+(_<<20&4294967295|_>>>12),_=g+(T^R&(y^T))+v[5]+3593408605&4294967295,g=y+(_<<5&4294967295|_>>>27),_=R+(y^T&(g^y))+v[10]+38016083&4294967295,R=g+(_<<9&4294967295|_>>>23),_=T+(g^y&(R^g))+v[15]+3634488961&4294967295,T=R+(_<<14&4294967295|_>>>18),_=y+(R^g&(T^R))+v[4]+3889429448&4294967295,y=T+(_<<20&4294967295|_>>>12),_=g+(T^R&(y^T))+v[9]+568446438&4294967295,g=y+(_<<5&4294967295|_>>>27),_=R+(y^T&(g^y))+v[14]+3275163606&4294967295,R=g+(_<<9&4294967295|_>>>23),_=T+(g^y&(R^g))+v[3]+4107603335&4294967295,T=R+(_<<14&4294967295|_>>>18),_=y+(R^g&(T^R))+v[8]+1163531501&4294967295,y=T+(_<<20&4294967295|_>>>12),_=g+(T^R&(y^T))+v[13]+2850285829&4294967295,g=y+(_<<5&4294967295|_>>>27),_=R+(y^T&(g^y))+v[2]+4243563512&4294967295,R=g+(_<<9&4294967295|_>>>23),_=T+(g^y&(R^g))+v[7]+1735328473&4294967295,T=R+(_<<14&4294967295|_>>>18),_=y+(R^g&(T^R))+v[12]+2368359562&4294967295,y=T+(_<<20&4294967295|_>>>12),_=g+(y^T^R)+v[5]+4294588738&4294967295,g=y+(_<<4&4294967295|_>>>28),_=R+(g^y^T)+v[8]+2272392833&4294967295,R=g+(_<<11&4294967295|_>>>21),_=T+(R^g^y)+v[11]+1839030562&4294967295,T=R+(_<<16&4294967295|_>>>16),_=y+(T^R^g)+v[14]+4259657740&4294967295,y=T+(_<<23&4294967295|_>>>9),_=g+(y^T^R)+v[1]+2763975236&4294967295,g=y+(_<<4&4294967295|_>>>28),_=R+(g^y^T)+v[4]+1272893353&4294967295,R=g+(_<<11&4294967295|_>>>21),_=T+(R^g^y)+v[7]+4139469664&4294967295,T=R+(_<<16&4294967295|_>>>16),_=y+(T^R^g)+v[10]+3200236656&4294967295,y=T+(_<<23&4294967295|_>>>9),_=g+(y^T^R)+v[13]+681279174&4294967295,g=y+(_<<4&4294967295|_>>>28),_=R+(g^y^T)+v[0]+3936430074&4294967295,R=g+(_<<11&4294967295|_>>>21),_=T+(R^g^y)+v[3]+3572445317&4294967295,T=R+(_<<16&4294967295|_>>>16),_=y+(T^R^g)+v[6]+76029189&4294967295,y=T+(_<<23&4294967295|_>>>9),_=g+(y^T^R)+v[9]+3654602809&4294967295,g=y+(_<<4&4294967295|_>>>28),_=R+(g^y^T)+v[12]+3873151461&4294967295,R=g+(_<<11&4294967295|_>>>21),_=T+(R^g^y)+v[15]+530742520&4294967295,T=R+(_<<16&4294967295|_>>>16),_=y+(T^R^g)+v[2]+3299628645&4294967295,y=T+(_<<23&4294967295|_>>>9),_=g+(T^(y|~R))+v[0]+4096336452&4294967295,g=y+(_<<6&4294967295|_>>>26),_=R+(y^(g|~T))+v[7]+1126891415&4294967295,R=g+(_<<10&4294967295|_>>>22),_=T+(g^(R|~y))+v[14]+2878612391&4294967295,T=R+(_<<15&4294967295|_>>>17),_=y+(R^(T|~g))+v[5]+4237533241&4294967295,y=T+(_<<21&4294967295|_>>>11),_=g+(T^(y|~R))+v[12]+1700485571&4294967295,g=y+(_<<6&4294967295|_>>>26),_=R+(y^(g|~T))+v[3]+2399980690&4294967295,R=g+(_<<10&4294967295|_>>>22),_=T+(g^(R|~y))+v[10]+4293915773&4294967295,T=R+(_<<15&4294967295|_>>>17),_=y+(R^(T|~g))+v[1]+2240044497&4294967295,y=T+(_<<21&4294967295|_>>>11),_=g+(T^(y|~R))+v[8]+1873313359&4294967295,g=y+(_<<6&4294967295|_>>>26),_=R+(y^(g|~T))+v[15]+4264355552&4294967295,R=g+(_<<10&4294967295|_>>>22),_=T+(g^(R|~y))+v[6]+2734768916&4294967295,T=R+(_<<15&4294967295|_>>>17),_=y+(R^(T|~g))+v[13]+1309151649&4294967295,y=T+(_<<21&4294967295|_>>>11),_=g+(T^(y|~R))+v[4]+4149444226&4294967295,g=y+(_<<6&4294967295|_>>>26),_=R+(y^(g|~T))+v[11]+3174756917&4294967295,R=g+(_<<10&4294967295|_>>>22),_=T+(g^(R|~y))+v[2]+718787259&4294967295,T=R+(_<<15&4294967295|_>>>17),_=y+(R^(T|~g))+v[9]+3951481745&4294967295,w.g[0]=w.g[0]+g&4294967295,w.g[1]=w.g[1]+(T+(_<<21&4294967295|_>>>11))&4294967295,w.g[2]=w.g[2]+T&4294967295,w.g[3]=w.g[3]+R&4294967295}r.prototype.v=function(w,g){g===void 0&&(g=w.length);const y=g-this.blockSize,v=this.C;let T=this.h,R=0;for(;R<g;){if(T==0)for(;R<=y;)s(this,w,R),R+=this.blockSize;if(typeof w=="string"){for(;R<g;)if(v[T++]=w.charCodeAt(R++),T==this.blockSize){s(this,v),T=0;break}}else for(;R<g;)if(v[T++]=w[R++],T==this.blockSize){s(this,v),T=0;break}}this.h=T,this.o+=g},r.prototype.A=function(){var w=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);w[0]=128;for(var g=1;g<w.length-8;++g)w[g]=0;g=this.o*8;for(var y=w.length-8;y<w.length;++y)w[y]=g&255,g/=256;for(this.v(w),w=Array(16),g=0,y=0;y<4;++y)for(let v=0;v<32;v+=8)w[g++]=this.g[y]>>>v&255;return w};function o(w,g){var y=c;return Object.prototype.hasOwnProperty.call(y,w)?y[w]:y[w]=g(w)}function a(w,g){this.h=g;const y=[];let v=!0;for(let T=w.length-1;T>=0;T--){const R=w[T]|0;v&&R==g||(y[T]=R,v=!1)}this.g=y}var c={};function h(w){return-128<=w&&w<128?o(w,function(g){return new a([g|0],g<0?-1:0)}):new a([w|0],w<0?-1:0)}function f(w){if(isNaN(w)||!isFinite(w))return m;if(w<0)return k(f(-w));const g=[];let y=1;for(let v=0;w>=y;v++)g[v]=w/y|0,y*=4294967296;return new a(g,0)}function p(w,g){if(w.length==0)throw Error("number format error: empty string");if(g=g||10,g<2||36<g)throw Error("radix out of range: "+g);if(w.charAt(0)=="-")return k(p(w.substring(1),g));if(w.indexOf("-")>=0)throw Error('number format error: interior "-" character');const y=f(Math.pow(g,8));let v=m;for(let R=0;R<w.length;R+=8){var T=Math.min(8,w.length-R);const _=parseInt(w.substring(R,R+T),g);T<8?(T=f(Math.pow(g,T)),v=v.j(T).add(f(_))):(v=v.j(y),v=v.add(f(_)))}return v}var m=h(0),I=h(1),b=h(16777216);n=a.prototype,n.m=function(){if(M(this))return-k(this).m();let w=0,g=1;for(let y=0;y<this.g.length;y++){const v=this.i(y);w+=(v>=0?v:4294967296+v)*g,g*=4294967296}return w},n.toString=function(w){if(w=w||10,w<2||36<w)throw Error("radix out of range: "+w);if(C(this))return"0";if(M(this))return"-"+k(this).toString(w);const g=f(Math.pow(w,6));var y=this;let v="";for(;;){const T=Z(y,g).g;y=z(y,T.j(g));let R=((y.g.length>0?y.g[0]:y.h)>>>0).toString(w);if(y=T,C(y))return R+v;for(;R.length<6;)R="0"+R;v=R+v}},n.i=function(w){return w<0?0:w<this.g.length?this.g[w]:this.h};function C(w){if(w.h!=0)return!1;for(let g=0;g<w.g.length;g++)if(w.g[g]!=0)return!1;return!0}function M(w){return w.h==-1}n.l=function(w){return w=z(this,w),M(w)?-1:C(w)?0:1};function k(w){const g=w.g.length,y=[];for(let v=0;v<g;v++)y[v]=~w.g[v];return new a(y,~w.h).add(I)}n.abs=function(){return M(this)?k(this):this},n.add=function(w){const g=Math.max(this.g.length,w.g.length),y=[];let v=0;for(let T=0;T<=g;T++){let R=v+(this.i(T)&65535)+(w.i(T)&65535),_=(R>>>16)+(this.i(T)>>>16)+(w.i(T)>>>16);v=_>>>16,R&=65535,_&=65535,y[T]=_<<16|R}return new a(y,y[y.length-1]&-2147483648?-1:0)};function z(w,g){return w.add(k(g))}n.j=function(w){if(C(this)||C(w))return m;if(M(this))return M(w)?k(this).j(k(w)):k(k(this).j(w));if(M(w))return k(this.j(k(w)));if(this.l(b)<0&&w.l(b)<0)return f(this.m()*w.m());const g=this.g.length+w.g.length,y=[];for(var v=0;v<2*g;v++)y[v]=0;for(v=0;v<this.g.length;v++)for(let T=0;T<w.g.length;T++){const R=this.i(v)>>>16,_=this.i(v)&65535,Dt=w.i(T)>>>16,je=w.i(T)&65535;y[2*v+2*T]+=_*je,W(y,2*v+2*T),y[2*v+2*T+1]+=R*je,W(y,2*v+2*T+1),y[2*v+2*T+1]+=_*Dt,W(y,2*v+2*T+1),y[2*v+2*T+2]+=R*Dt,W(y,2*v+2*T+2)}for(w=0;w<g;w++)y[w]=y[2*w+1]<<16|y[2*w];for(w=g;w<2*g;w++)y[w]=0;return new a(y,0)};function W(w,g){for(;(w[g]&65535)!=w[g];)w[g+1]+=w[g]>>>16,w[g]&=65535,g++}function J(w,g){this.g=w,this.h=g}function Z(w,g){if(C(g))throw Error("division by zero");if(C(w))return new J(m,m);if(M(w))return g=Z(k(w),g),new J(k(g.g),k(g.h));if(M(g))return g=Z(w,k(g)),new J(k(g.g),g.h);if(w.g.length>30){if(M(w)||M(g))throw Error("slowDivide_ only works with positive integers.");for(var y=I,v=g;v.l(w)<=0;)y=ut(y),v=ut(v);var T=lt(y,1),R=lt(v,1);for(v=lt(v,2),y=lt(y,2);!C(v);){var _=R.add(v);_.l(w)<=0&&(T=T.add(y),R=_),v=lt(v,1),y=lt(y,1)}return g=z(w,T.j(g)),new J(T,g)}for(T=m;w.l(g)>=0;){for(y=Math.max(1,Math.floor(w.m()/g.m())),v=Math.ceil(Math.log(y)/Math.LN2),v=v<=48?1:Math.pow(2,v-48),R=f(y),_=R.j(g);M(_)||_.l(w)>0;)y-=v,R=f(y),_=R.j(g);C(R)&&(R=I),T=T.add(R),w=z(w,_)}return new J(T,w)}n.B=function(w){return Z(this,w).h},n.and=function(w){const g=Math.max(this.g.length,w.g.length),y=[];for(let v=0;v<g;v++)y[v]=this.i(v)&w.i(v);return new a(y,this.h&w.h)},n.or=function(w){const g=Math.max(this.g.length,w.g.length),y=[];for(let v=0;v<g;v++)y[v]=this.i(v)|w.i(v);return new a(y,this.h|w.h)},n.xor=function(w){const g=Math.max(this.g.length,w.g.length),y=[];for(let v=0;v<g;v++)y[v]=this.i(v)^w.i(v);return new a(y,this.h^w.h)};function ut(w){const g=w.g.length+1,y=[];for(let v=0;v<g;v++)y[v]=w.i(v)<<1|w.i(v-1)>>>31;return new a(y,w.h)}function lt(w,g){const y=g>>5;g%=32;const v=w.g.length-y,T=[];for(let R=0;R<v;R++)T[R]=g>0?w.i(R+y)>>>g|w.i(R+y+1)<<32-g:w.i(R+y);return new a(T,w.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,Cc=r,a.prototype.add=a.prototype.add,a.prototype.multiply=a.prototype.j,a.prototype.modulo=a.prototype.B,a.prototype.compare=a.prototype.l,a.prototype.toNumber=a.prototype.m,a.prototype.toString=a.prototype.toString,a.prototype.getBits=a.prototype.i,a.fromNumber=f,a.fromString=p,be=a}).apply(typeof _u<"u"?_u:typeof self<"u"?self:typeof window<"u"?window:{});var ss=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var xc,nr,Nc,fs,Gi,Dc,kc,Oc;(function(){var n,t=Object.defineProperty;function e(i){i=[typeof globalThis=="object"&&globalThis,i,typeof window=="object"&&window,typeof self=="object"&&self,typeof ss=="object"&&ss];for(var u=0;u<i.length;++u){var l=i[u];if(l&&l.Math==Math)return l}throw Error("Cannot find global object")}var r=e(this);function s(i,u){if(u)t:{var l=r;i=i.split(".");for(var d=0;d<i.length-1;d++){var A=i[d];if(!(A in l))break t;l=l[A]}i=i[i.length-1],d=l[i],u=u(d),u!=d&&u!=null&&t(l,i,{configurable:!0,writable:!0,value:u})}}s("Symbol.dispose",function(i){return i||Symbol("Symbol.dispose")}),s("Array.prototype.values",function(i){return i||function(){return this[Symbol.iterator]()}}),s("Object.entries",function(i){return i||function(u){var l=[],d;for(d in u)Object.prototype.hasOwnProperty.call(u,d)&&l.push([d,u[d]]);return l}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},a=this||self;function c(i){var u=typeof i;return u=="object"&&i!=null||u=="function"}function h(i,u,l){return i.call.apply(i.bind,arguments)}function f(i,u,l){return f=h,f.apply(null,arguments)}function p(i,u){var l=Array.prototype.slice.call(arguments,1);return function(){var d=l.slice();return d.push.apply(d,arguments),i.apply(this,d)}}function m(i,u){function l(){}l.prototype=u.prototype,i.Z=u.prototype,i.prototype=new l,i.prototype.constructor=i,i.Ob=function(d,A,V){for(var D=Array(arguments.length-2),G=2;G<arguments.length;G++)D[G-2]=arguments[G];return u.prototype[A].apply(d,D)}}var I=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?i=>i&&AsyncContext.Snapshot.wrap(i):i=>i;function b(i){const u=i.length;if(u>0){const l=Array(u);for(let d=0;d<u;d++)l[d]=i[d];return l}return[]}function C(i,u){for(let d=1;d<arguments.length;d++){const A=arguments[d];var l=typeof A;if(l=l!="object"?l:A?Array.isArray(A)?"array":l:"null",l=="array"||l=="object"&&typeof A.length=="number"){l=i.length||0;const V=A.length||0;i.length=l+V;for(let D=0;D<V;D++)i[l+D]=A[D]}else i.push(A)}}class M{constructor(u,l){this.i=u,this.j=l,this.h=0,this.g=null}get(){let u;return this.h>0?(this.h--,u=this.g,this.g=u.next,u.next=null):u=this.i(),u}}function k(i){a.setTimeout(()=>{throw i},0)}function z(){var i=w;let u=null;return i.g&&(u=i.g,i.g=i.g.next,i.g||(i.h=null),u.next=null),u}class W{constructor(){this.h=this.g=null}add(u,l){const d=J.get();d.set(u,l),this.h?this.h.next=d:this.g=d,this.h=d}}var J=new M(()=>new Z,i=>i.reset());class Z{constructor(){this.next=this.g=this.h=null}set(u,l){this.h=u,this.g=l,this.next=null}reset(){this.next=this.g=this.h=null}}let ut,lt=!1,w=new W,g=()=>{const i=Promise.resolve(void 0);ut=()=>{i.then(y)}};function y(){for(var i;i=z();){try{i.h.call(i.g)}catch(l){k(l)}var u=J;u.j(i),u.h<100&&(u.h++,i.next=u.g,u.g=i)}lt=!1}function v(){this.u=this.u,this.C=this.C}v.prototype.u=!1,v.prototype.dispose=function(){this.u||(this.u=!0,this.N())},v.prototype[Symbol.dispose]=function(){this.dispose()},v.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function T(i,u){this.type=i,this.g=this.target=u,this.defaultPrevented=!1}T.prototype.h=function(){this.defaultPrevented=!0};var R=function(){if(!a.addEventListener||!Object.defineProperty)return!1;var i=!1,u=Object.defineProperty({},"passive",{get:function(){i=!0}});try{const l=()=>{};a.addEventListener("test",l,u),a.removeEventListener("test",l,u)}catch{}return i}();function _(i){return/^[\s\xa0]*$/.test(i)}function Dt(i,u){T.call(this,i?i.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,i&&this.init(i,u)}m(Dt,T),Dt.prototype.init=function(i,u){const l=this.type=i.type,d=i.changedTouches&&i.changedTouches.length?i.changedTouches[0]:null;this.target=i.target||i.srcElement,this.g=u,u=i.relatedTarget,u||(l=="mouseover"?u=i.fromElement:l=="mouseout"&&(u=i.toElement)),this.relatedTarget=u,d?(this.clientX=d.clientX!==void 0?d.clientX:d.pageX,this.clientY=d.clientY!==void 0?d.clientY:d.pageY,this.screenX=d.screenX||0,this.screenY=d.screenY||0):(this.clientX=i.clientX!==void 0?i.clientX:i.pageX,this.clientY=i.clientY!==void 0?i.clientY:i.pageY,this.screenX=i.screenX||0,this.screenY=i.screenY||0),this.button=i.button,this.key=i.key||"",this.ctrlKey=i.ctrlKey,this.altKey=i.altKey,this.shiftKey=i.shiftKey,this.metaKey=i.metaKey,this.pointerId=i.pointerId||0,this.pointerType=i.pointerType,this.state=i.state,this.i=i,i.defaultPrevented&&Dt.Z.h.call(this)},Dt.prototype.h=function(){Dt.Z.h.call(this);const i=this.i;i.preventDefault?i.preventDefault():i.returnValue=!1};var je="closure_listenable_"+(Math.random()*1e6|0),Fh=0;function Bh(i,u,l,d,A){this.listener=i,this.proxy=null,this.src=u,this.type=l,this.capture=!!d,this.ha=A,this.key=++Fh,this.da=this.fa=!1}function $r(i){i.da=!0,i.listener=null,i.proxy=null,i.src=null,i.ha=null}function zr(i,u,l){for(const d in i)u.call(l,i[d],d,i)}function jh(i,u){for(const l in i)u.call(void 0,i[l],l,i)}function ca(i){const u={};for(const l in i)u[l]=i[l];return u}const la="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ha(i,u){let l,d;for(let A=1;A<arguments.length;A++){d=arguments[A];for(l in d)i[l]=d[l];for(let V=0;V<la.length;V++)l=la[V],Object.prototype.hasOwnProperty.call(d,l)&&(i[l]=d[l])}}function Gr(i){this.src=i,this.g={},this.h=0}Gr.prototype.add=function(i,u,l,d,A){const V=i.toString();i=this.g[V],i||(i=this.g[V]=[],this.h++);const D=ui(i,u,d,A);return D>-1?(u=i[D],l||(u.fa=!1)):(u=new Bh(u,this.src,V,!!d,A),u.fa=l,i.push(u)),u};function ai(i,u){const l=u.type;if(l in i.g){var d=i.g[l],A=Array.prototype.indexOf.call(d,u,void 0),V;(V=A>=0)&&Array.prototype.splice.call(d,A,1),V&&($r(u),i.g[l].length==0&&(delete i.g[l],i.h--))}}function ui(i,u,l,d){for(let A=0;A<i.length;++A){const V=i[A];if(!V.da&&V.listener==u&&V.capture==!!l&&V.ha==d)return A}return-1}var ci="closure_lm_"+(Math.random()*1e6|0),li={};function fa(i,u,l,d,A){if(Array.isArray(u)){for(let V=0;V<u.length;V++)fa(i,u[V],l,d,A);return null}return l=ma(l),i&&i[je]?i.J(u,l,c(d)?!!d.capture:!1,A):qh(i,u,l,!1,d,A)}function qh(i,u,l,d,A,V){if(!u)throw Error("Invalid event type");const D=c(A)?!!A.capture:!!A;let G=fi(i);if(G||(i[ci]=G=new Gr(i)),l=G.add(u,l,d,D,V),l.proxy)return l;if(d=$h(),l.proxy=d,d.src=i,d.listener=l,i.addEventListener)R||(A=D),A===void 0&&(A=!1),i.addEventListener(u.toString(),d,A);else if(i.attachEvent)i.attachEvent(pa(u.toString()),d);else if(i.addListener&&i.removeListener)i.addListener(d);else throw Error("addEventListener and attachEvent are unavailable.");return l}function $h(){function i(l){return u.call(i.src,i.listener,l)}const u=zh;return i}function da(i,u,l,d,A){if(Array.isArray(u))for(var V=0;V<u.length;V++)da(i,u[V],l,d,A);else d=c(d)?!!d.capture:!!d,l=ma(l),i&&i[je]?(i=i.i,V=String(u).toString(),V in i.g&&(u=i.g[V],l=ui(u,l,d,A),l>-1&&($r(u[l]),Array.prototype.splice.call(u,l,1),u.length==0&&(delete i.g[V],i.h--)))):i&&(i=fi(i))&&(u=i.g[u.toString()],i=-1,u&&(i=ui(u,l,d,A)),(l=i>-1?u[i]:null)&&hi(l))}function hi(i){if(typeof i!="number"&&i&&!i.da){var u=i.src;if(u&&u[je])ai(u.i,i);else{var l=i.type,d=i.proxy;u.removeEventListener?u.removeEventListener(l,d,i.capture):u.detachEvent?u.detachEvent(pa(l),d):u.addListener&&u.removeListener&&u.removeListener(d),(l=fi(u))?(ai(l,i),l.h==0&&(l.src=null,u[ci]=null)):$r(i)}}}function pa(i){return i in li?li[i]:li[i]="on"+i}function zh(i,u){if(i.da)i=!0;else{u=new Dt(u,this);const l=i.listener,d=i.ha||i.src;i.fa&&hi(i),i=l.call(d,u)}return i}function fi(i){return i=i[ci],i instanceof Gr?i:null}var di="__closure_events_fn_"+(Math.random()*1e9>>>0);function ma(i){return typeof i=="function"?i:(i[di]||(i[di]=function(u){return i.handleEvent(u)}),i[di])}function At(){v.call(this),this.i=new Gr(this),this.M=this,this.G=null}m(At,v),At.prototype[je]=!0,At.prototype.removeEventListener=function(i,u,l,d){da(this,i,u,l,d)};function St(i,u){var l,d=i.G;if(d)for(l=[];d;d=d.G)l.push(d);if(i=i.M,d=u.type||u,typeof u=="string")u=new T(u,i);else if(u instanceof T)u.target=u.target||i;else{var A=u;u=new T(d,i),ha(u,A)}A=!0;let V,D;if(l)for(D=l.length-1;D>=0;D--)V=u.g=l[D],A=Hr(V,d,!0,u)&&A;if(V=u.g=i,A=Hr(V,d,!0,u)&&A,A=Hr(V,d,!1,u)&&A,l)for(D=0;D<l.length;D++)V=u.g=l[D],A=Hr(V,d,!1,u)&&A}At.prototype.N=function(){if(At.Z.N.call(this),this.i){var i=this.i;for(const u in i.g){const l=i.g[u];for(let d=0;d<l.length;d++)$r(l[d]);delete i.g[u],i.h--}}this.G=null},At.prototype.J=function(i,u,l,d){return this.i.add(String(i),u,!1,l,d)},At.prototype.K=function(i,u,l,d){return this.i.add(String(i),u,!0,l,d)};function Hr(i,u,l,d){if(u=i.i.g[String(u)],!u)return!0;u=u.concat();let A=!0;for(let V=0;V<u.length;++V){const D=u[V];if(D&&!D.da&&D.capture==l){const G=D.listener,gt=D.ha||D.src;D.fa&&ai(i.i,D),A=G.call(gt,d)!==!1&&A}}return A&&!d.defaultPrevented}function Gh(i,u){if(typeof i!="function")if(i&&typeof i.handleEvent=="function")i=f(i.handleEvent,i);else throw Error("Invalid listener argument");return Number(u)>2147483647?-1:a.setTimeout(i,u||0)}function ga(i){i.g=Gh(()=>{i.g=null,i.i&&(i.i=!1,ga(i))},i.l);const u=i.h;i.h=null,i.m.apply(null,u)}class Hh extends v{constructor(u,l){super(),this.m=u,this.l=l,this.h=null,this.i=!1,this.g=null}j(u){this.h=arguments,this.g?this.i=!0:ga(this)}N(){super.N(),this.g&&(a.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Mn(i){v.call(this),this.h=i,this.g={}}m(Mn,v);var _a=[];function ya(i){zr(i.g,function(u,l){this.g.hasOwnProperty(l)&&hi(u)},i),i.g={}}Mn.prototype.N=function(){Mn.Z.N.call(this),ya(this)},Mn.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var pi=a.JSON.stringify,Wh=a.JSON.parse,Qh=class{stringify(i){return a.JSON.stringify(i,void 0)}parse(i){return a.JSON.parse(i,void 0)}};function Ea(){}function Ta(){}var Un={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function mi(){T.call(this,"d")}m(mi,T);function gi(){T.call(this,"c")}m(gi,T);var qe={},wa=null;function Wr(){return wa=wa||new At}qe.Ia="serverreachability";function va(i){T.call(this,qe.Ia,i)}m(va,T);function Fn(i){const u=Wr();St(u,new va(u))}qe.STAT_EVENT="statevent";function Ia(i,u){T.call(this,qe.STAT_EVENT,i),this.stat=u}m(Ia,T);function Ct(i){const u=Wr();St(u,new Ia(u,i))}qe.Ja="timingevent";function Aa(i,u){T.call(this,qe.Ja,i),this.size=u}m(Aa,T);function Bn(i,u){if(typeof i!="function")throw Error("Fn must not be null and must be a function");return a.setTimeout(function(){i()},u)}function jn(){this.g=!0}jn.prototype.ua=function(){this.g=!1};function Kh(i,u,l,d,A,V){i.info(function(){if(i.g)if(V){var D="",G=V.split("&");for(let tt=0;tt<G.length;tt++){var gt=G[tt].split("=");if(gt.length>1){const Et=gt[0];gt=gt[1];const ee=Et.split("_");D=ee.length>=2&&ee[1]=="type"?D+(Et+"="+gt+"&"):D+(Et+"=redacted&")}}}else D=null;else D=V;return"XMLHTTP REQ ("+d+") [attempt "+A+"]: "+u+`
`+l+`
`+D})}function Xh(i,u,l,d,A,V,D){i.info(function(){return"XMLHTTP RESP ("+d+") [ attempt "+A+"]: "+u+`
`+l+`
`+V+" "+D})}function dn(i,u,l,d){i.info(function(){return"XMLHTTP TEXT ("+u+"): "+Yh(i,l)+(d?" "+d:"")})}function Jh(i,u){i.info(function(){return"TIMEOUT: "+u})}jn.prototype.info=function(){};function Yh(i,u){if(!i.g)return u;if(!u)return null;try{const V=JSON.parse(u);if(V){for(i=0;i<V.length;i++)if(Array.isArray(V[i])){var l=V[i];if(!(l.length<2)){var d=l[1];if(Array.isArray(d)&&!(d.length<1)){var A=d[0];if(A!="noop"&&A!="stop"&&A!="close")for(let D=1;D<d.length;D++)d[D]=""}}}}return pi(V)}catch{return u}}var Qr={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Ra={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Va;function _i(){}m(_i,Ea),_i.prototype.g=function(){return new XMLHttpRequest},Va=new _i;function qn(i){return encodeURIComponent(String(i))}function Zh(i){var u=1;i=i.split(":");const l=[];for(;u>0&&i.length;)l.push(i.shift()),u--;return i.length&&l.push(i.join(":")),l}function Te(i,u,l,d){this.j=i,this.i=u,this.l=l,this.S=d||1,this.V=new Mn(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Pa}function Pa(){this.i=null,this.g="",this.h=!1}var ba={},yi={};function Ei(i,u,l){i.M=1,i.A=Xr(te(u)),i.u=l,i.R=!0,Sa(i,null)}function Sa(i,u){i.F=Date.now(),Kr(i),i.B=te(i.A);var l=i.B,d=i.S;Array.isArray(d)||(d=[String(d)]),qa(l.i,"t",d),i.C=0,l=i.j.L,i.h=new Pa,i.g=ou(i.j,l?u:null,!i.u),i.P>0&&(i.O=new Hh(f(i.Y,i,i.g),i.P)),u=i.V,l=i.g,d=i.ba;var A="readystatechange";Array.isArray(A)||(A&&(_a[0]=A.toString()),A=_a);for(let V=0;V<A.length;V++){const D=fa(l,A[V],d||u.handleEvent,!1,u.h||u);if(!D)break;u.g[D.key]=D}u=i.J?ca(i.J):{},i.u?(i.v||(i.v="POST"),u["Content-Type"]="application/x-www-form-urlencoded",i.g.ea(i.B,i.v,i.u,u)):(i.v="GET",i.g.ea(i.B,i.v,null,u)),Fn(),Kh(i.i,i.v,i.B,i.l,i.S,i.u)}Te.prototype.ba=function(i){i=i.target;const u=this.O;u&&Ie(i)==3?u.j():this.Y(i)},Te.prototype.Y=function(i){try{if(i==this.g)t:{const G=Ie(this.g),gt=this.g.ya(),tt=this.g.ca();if(!(G<3)&&(G!=3||this.g&&(this.h.h||this.g.la()||Ka(this.g)))){this.K||G!=4||gt==7||(gt==8||tt<=0?Fn(3):Fn(2)),Ti(this);var u=this.g.ca();this.X=u;var l=tf(this);if(this.o=u==200,Xh(this.i,this.v,this.B,this.l,this.S,G,u),this.o){if(this.U&&!this.L){e:{if(this.g){var d,A=this.g;if((d=A.g?A.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!_(d)){var V=d;break e}}V=null}if(i=V)dn(this.i,this.l,i,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,wi(this,i);else{this.o=!1,this.m=3,Ct(12),$e(this),$n(this);break t}}if(this.R){i=!0;let Et;for(;!this.K&&this.C<l.length;)if(Et=ef(this,l),Et==yi){G==4&&(this.m=4,Ct(14),i=!1),dn(this.i,this.l,null,"[Incomplete Response]");break}else if(Et==ba){this.m=4,Ct(15),dn(this.i,this.l,l,"[Invalid Chunk]"),i=!1;break}else dn(this.i,this.l,Et,null),wi(this,Et);if(Ca(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),G!=4||l.length!=0||this.h.h||(this.m=1,Ct(16),i=!1),this.o=this.o&&i,!i)dn(this.i,this.l,l,"[Invalid Chunked Response]"),$e(this),$n(this);else if(l.length>0&&!this.W){this.W=!0;var D=this.j;D.g==this&&D.aa&&!D.P&&(D.j.info("Great, no buffering proxy detected. Bytes received: "+l.length),Si(D),D.P=!0,Ct(11))}}else dn(this.i,this.l,l,null),wi(this,l);G==4&&$e(this),this.o&&!this.K&&(G==4?nu(this.j,this):(this.o=!1,Kr(this)))}else gf(this.g),u==400&&l.indexOf("Unknown SID")>0?(this.m=3,Ct(12)):(this.m=0,Ct(13)),$e(this),$n(this)}}}catch{}finally{}};function tf(i){if(!Ca(i))return i.g.la();const u=Ka(i.g);if(u==="")return"";let l="";const d=u.length,A=Ie(i.g)==4;if(!i.h.i){if(typeof TextDecoder>"u")return $e(i),$n(i),"";i.h.i=new a.TextDecoder}for(let V=0;V<d;V++)i.h.h=!0,l+=i.h.i.decode(u[V],{stream:!(A&&V==d-1)});return u.length=0,i.h.g+=l,i.C=0,i.h.g}function Ca(i){return i.g?i.v=="GET"&&i.M!=2&&i.j.Aa:!1}function ef(i,u){var l=i.C,d=u.indexOf(`
`,l);return d==-1?yi:(l=Number(u.substring(l,d)),isNaN(l)?ba:(d+=1,d+l>u.length?yi:(u=u.slice(d,d+l),i.C=d+l,u)))}Te.prototype.cancel=function(){this.K=!0,$e(this)};function Kr(i){i.T=Date.now()+i.H,xa(i,i.H)}function xa(i,u){if(i.D!=null)throw Error("WatchDog timer not null");i.D=Bn(f(i.aa,i),u)}function Ti(i){i.D&&(a.clearTimeout(i.D),i.D=null)}Te.prototype.aa=function(){this.D=null;const i=Date.now();i-this.T>=0?(Jh(this.i,this.B),this.M!=2&&(Fn(),Ct(17)),$e(this),this.m=2,$n(this)):xa(this,this.T-i)};function $n(i){i.j.I==0||i.K||nu(i.j,i)}function $e(i){Ti(i);var u=i.O;u&&typeof u.dispose=="function"&&u.dispose(),i.O=null,ya(i.V),i.g&&(u=i.g,i.g=null,u.abort(),u.dispose())}function wi(i,u){try{var l=i.j;if(l.I!=0&&(l.g==i||vi(l.h,i))){if(!i.L&&vi(l.h,i)&&l.I==3){try{var d=l.Ba.g.parse(u)}catch{d=null}if(Array.isArray(d)&&d.length==3){var A=d;if(A[0]==0){t:if(!l.v){if(l.g)if(l.g.F+3e3<i.F)es(l),Zr(l);else break t;bi(l),Ct(18)}}else l.xa=A[1],0<l.xa-l.K&&A[2]<37500&&l.F&&l.A==0&&!l.C&&(l.C=Bn(f(l.Va,l),6e3));ka(l.h)<=1&&l.ta&&(l.ta=void 0)}else Ge(l,11)}else if((i.L||l.g==i)&&es(l),!_(u))for(A=l.Ba.g.parse(u),u=0;u<A.length;u++){let tt=A[u];const Et=tt[0];if(!(Et<=l.K))if(l.K=Et,tt=tt[1],l.I==2)if(tt[0]=="c"){l.M=tt[1],l.ba=tt[2];const ee=tt[3];ee!=null&&(l.ka=ee,l.j.info("VER="+l.ka));const He=tt[4];He!=null&&(l.za=He,l.j.info("SVER="+l.za));const Ae=tt[5];Ae!=null&&typeof Ae=="number"&&Ae>0&&(d=1.5*Ae,l.O=d,l.j.info("backChannelRequestTimeoutMs_="+d)),d=l;const Re=i.g;if(Re){const rs=Re.g?Re.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(rs){var V=d.h;V.g||rs.indexOf("spdy")==-1&&rs.indexOf("quic")==-1&&rs.indexOf("h2")==-1||(V.j=V.l,V.g=new Set,V.h&&(Ii(V,V.h),V.h=null))}if(d.G){const Ci=Re.g?Re.g.getResponseHeader("X-HTTP-Session-Id"):null;Ci&&(d.wa=Ci,et(d.J,d.G,Ci))}}l.I=3,l.l&&l.l.ra(),l.aa&&(l.T=Date.now()-i.F,l.j.info("Handshake RTT: "+l.T+"ms")),d=l;var D=i;if(d.na=iu(d,d.L?d.ba:null,d.W),D.L){Oa(d.h,D);var G=D,gt=d.O;gt&&(G.H=gt),G.D&&(Ti(G),Kr(G)),d.g=D}else tu(d);l.i.length>0&&ts(l)}else tt[0]!="stop"&&tt[0]!="close"||Ge(l,7);else l.I==3&&(tt[0]=="stop"||tt[0]=="close"?tt[0]=="stop"?Ge(l,7):Pi(l):tt[0]!="noop"&&l.l&&l.l.qa(tt),l.A=0)}}Fn(4)}catch{}}var nf=class{constructor(i,u){this.g=i,this.map=u}};function Na(i){this.l=i||10,a.PerformanceNavigationTiming?(i=a.performance.getEntriesByType("navigation"),i=i.length>0&&(i[0].nextHopProtocol=="hq"||i[0].nextHopProtocol=="h2")):i=!!(a.chrome&&a.chrome.loadTimes&&a.chrome.loadTimes()&&a.chrome.loadTimes().wasFetchedViaSpdy),this.j=i?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Da(i){return i.h?!0:i.g?i.g.size>=i.j:!1}function ka(i){return i.h?1:i.g?i.g.size:0}function vi(i,u){return i.h?i.h==u:i.g?i.g.has(u):!1}function Ii(i,u){i.g?i.g.add(u):i.h=u}function Oa(i,u){i.h&&i.h==u?i.h=null:i.g&&i.g.has(u)&&i.g.delete(u)}Na.prototype.cancel=function(){if(this.i=La(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const i of this.g.values())i.cancel();this.g.clear()}};function La(i){if(i.h!=null)return i.i.concat(i.h.G);if(i.g!=null&&i.g.size!==0){let u=i.i;for(const l of i.g.values())u=u.concat(l.G);return u}return b(i.i)}var Ma=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function rf(i,u){if(i){i=i.split("&");for(let l=0;l<i.length;l++){const d=i[l].indexOf("=");let A,V=null;d>=0?(A=i[l].substring(0,d),V=i[l].substring(d+1)):A=i[l],u(A,V?decodeURIComponent(V.replace(/\+/g," ")):"")}}}function we(i){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let u;i instanceof we?(this.l=i.l,zn(this,i.j),this.o=i.o,this.g=i.g,Gn(this,i.u),this.h=i.h,Ai(this,$a(i.i)),this.m=i.m):i&&(u=String(i).match(Ma))?(this.l=!1,zn(this,u[1]||"",!0),this.o=Hn(u[2]||""),this.g=Hn(u[3]||"",!0),Gn(this,u[4]),this.h=Hn(u[5]||"",!0),Ai(this,u[6]||"",!0),this.m=Hn(u[7]||"")):(this.l=!1,this.i=new Qn(null,this.l))}we.prototype.toString=function(){const i=[];var u=this.j;u&&i.push(Wn(u,Ua,!0),":");var l=this.g;return(l||u=="file")&&(i.push("//"),(u=this.o)&&i.push(Wn(u,Ua,!0),"@"),i.push(qn(l).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),l=this.u,l!=null&&i.push(":",String(l))),(l=this.h)&&(this.g&&l.charAt(0)!="/"&&i.push("/"),i.push(Wn(l,l.charAt(0)=="/"?af:of,!0))),(l=this.i.toString())&&i.push("?",l),(l=this.m)&&i.push("#",Wn(l,cf)),i.join("")},we.prototype.resolve=function(i){const u=te(this);let l=!!i.j;l?zn(u,i.j):l=!!i.o,l?u.o=i.o:l=!!i.g,l?u.g=i.g:l=i.u!=null;var d=i.h;if(l)Gn(u,i.u);else if(l=!!i.h){if(d.charAt(0)!="/")if(this.g&&!this.h)d="/"+d;else{var A=u.h.lastIndexOf("/");A!=-1&&(d=u.h.slice(0,A+1)+d)}if(A=d,A==".."||A==".")d="";else if(A.indexOf("./")!=-1||A.indexOf("/.")!=-1){d=A.lastIndexOf("/",0)==0,A=A.split("/");const V=[];for(let D=0;D<A.length;){const G=A[D++];G=="."?d&&D==A.length&&V.push(""):G==".."?((V.length>1||V.length==1&&V[0]!="")&&V.pop(),d&&D==A.length&&V.push("")):(V.push(G),d=!0)}d=V.join("/")}else d=A}return l?u.h=d:l=i.i.toString()!=="",l?Ai(u,$a(i.i)):l=!!i.m,l&&(u.m=i.m),u};function te(i){return new we(i)}function zn(i,u,l){i.j=l?Hn(u,!0):u,i.j&&(i.j=i.j.replace(/:$/,""))}function Gn(i,u){if(u){if(u=Number(u),isNaN(u)||u<0)throw Error("Bad port number "+u);i.u=u}else i.u=null}function Ai(i,u,l){u instanceof Qn?(i.i=u,lf(i.i,i.l)):(l||(u=Wn(u,uf)),i.i=new Qn(u,i.l))}function et(i,u,l){i.i.set(u,l)}function Xr(i){return et(i,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),i}function Hn(i,u){return i?u?decodeURI(i.replace(/%25/g,"%2525")):decodeURIComponent(i):""}function Wn(i,u,l){return typeof i=="string"?(i=encodeURI(i).replace(u,sf),l&&(i=i.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),i):null}function sf(i){return i=i.charCodeAt(0),"%"+(i>>4&15).toString(16)+(i&15).toString(16)}var Ua=/[#\/\?@]/g,of=/[#\?:]/g,af=/[#\?]/g,uf=/[#\?@]/g,cf=/#/g;function Qn(i,u){this.h=this.g=null,this.i=i||null,this.j=!!u}function ze(i){i.g||(i.g=new Map,i.h=0,i.i&&rf(i.i,function(u,l){i.add(decodeURIComponent(u.replace(/\+/g," ")),l)}))}n=Qn.prototype,n.add=function(i,u){ze(this),this.i=null,i=pn(this,i);let l=this.g.get(i);return l||this.g.set(i,l=[]),l.push(u),this.h+=1,this};function Fa(i,u){ze(i),u=pn(i,u),i.g.has(u)&&(i.i=null,i.h-=i.g.get(u).length,i.g.delete(u))}function Ba(i,u){return ze(i),u=pn(i,u),i.g.has(u)}n.forEach=function(i,u){ze(this),this.g.forEach(function(l,d){l.forEach(function(A){i.call(u,A,d,this)},this)},this)};function ja(i,u){ze(i);let l=[];if(typeof u=="string")Ba(i,u)&&(l=l.concat(i.g.get(pn(i,u))));else for(i=Array.from(i.g.values()),u=0;u<i.length;u++)l=l.concat(i[u]);return l}n.set=function(i,u){return ze(this),this.i=null,i=pn(this,i),Ba(this,i)&&(this.h-=this.g.get(i).length),this.g.set(i,[u]),this.h+=1,this},n.get=function(i,u){return i?(i=ja(this,i),i.length>0?String(i[0]):u):u};function qa(i,u,l){Fa(i,u),l.length>0&&(i.i=null,i.g.set(pn(i,u),b(l)),i.h+=l.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const i=[],u=Array.from(this.g.keys());for(let d=0;d<u.length;d++){var l=u[d];const A=qn(l);l=ja(this,l);for(let V=0;V<l.length;V++){let D=A;l[V]!==""&&(D+="="+qn(l[V])),i.push(D)}}return this.i=i.join("&")};function $a(i){const u=new Qn;return u.i=i.i,i.g&&(u.g=new Map(i.g),u.h=i.h),u}function pn(i,u){return u=String(u),i.j&&(u=u.toLowerCase()),u}function lf(i,u){u&&!i.j&&(ze(i),i.i=null,i.g.forEach(function(l,d){const A=d.toLowerCase();d!=A&&(Fa(this,d),qa(this,A,l))},i)),i.j=u}function hf(i,u){const l=new jn;if(a.Image){const d=new Image;d.onload=p(ve,l,"TestLoadImage: loaded",!0,u,d),d.onerror=p(ve,l,"TestLoadImage: error",!1,u,d),d.onabort=p(ve,l,"TestLoadImage: abort",!1,u,d),d.ontimeout=p(ve,l,"TestLoadImage: timeout",!1,u,d),a.setTimeout(function(){d.ontimeout&&d.ontimeout()},1e4),d.src=i}else u(!1)}function ff(i,u){const l=new jn,d=new AbortController,A=setTimeout(()=>{d.abort(),ve(l,"TestPingServer: timeout",!1,u)},1e4);fetch(i,{signal:d.signal}).then(V=>{clearTimeout(A),V.ok?ve(l,"TestPingServer: ok",!0,u):ve(l,"TestPingServer: server error",!1,u)}).catch(()=>{clearTimeout(A),ve(l,"TestPingServer: error",!1,u)})}function ve(i,u,l,d,A){try{A&&(A.onload=null,A.onerror=null,A.onabort=null,A.ontimeout=null),d(l)}catch{}}function df(){this.g=new Qh}function Ri(i){this.i=i.Sb||null,this.h=i.ab||!1}m(Ri,Ea),Ri.prototype.g=function(){return new Jr(this.i,this.h)};function Jr(i,u){At.call(this),this.H=i,this.o=u,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}m(Jr,At),n=Jr.prototype,n.open=function(i,u){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=i,this.D=u,this.readyState=1,Xn(this)},n.send=function(i){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const u={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};i&&(u.body=i),(this.H||a).fetch(new Request(this.D,u)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Kn(this)),this.readyState=0},n.Pa=function(i){if(this.g&&(this.l=i,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=i.headers,this.readyState=2,Xn(this)),this.g&&(this.readyState=3,Xn(this),this.g)))if(this.responseType==="arraybuffer")i.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof a.ReadableStream<"u"&&"body"in i){if(this.j=i.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;za(this)}else i.text().then(this.Oa.bind(this),this.ga.bind(this))};function za(i){i.j.read().then(i.Ma.bind(i)).catch(i.ga.bind(i))}n.Ma=function(i){if(this.g){if(this.o&&i.value)this.response.push(i.value);else if(!this.o){var u=i.value?i.value:new Uint8Array(0);(u=this.B.decode(u,{stream:!i.done}))&&(this.response=this.responseText+=u)}i.done?Kn(this):Xn(this),this.readyState==3&&za(this)}},n.Oa=function(i){this.g&&(this.response=this.responseText=i,Kn(this))},n.Na=function(i){this.g&&(this.response=i,Kn(this))},n.ga=function(){this.g&&Kn(this)};function Kn(i){i.readyState=4,i.l=null,i.j=null,i.B=null,Xn(i)}n.setRequestHeader=function(i,u){this.A.append(i,u)},n.getResponseHeader=function(i){return this.h&&this.h.get(i.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const i=[],u=this.h.entries();for(var l=u.next();!l.done;)l=l.value,i.push(l[0]+": "+l[1]),l=u.next();return i.join(`\r
`)};function Xn(i){i.onreadystatechange&&i.onreadystatechange.call(i)}Object.defineProperty(Jr.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(i){this.m=i?"include":"same-origin"}});function Ga(i){let u="";return zr(i,function(l,d){u+=d,u+=":",u+=l,u+=`\r
`}),u}function Vi(i,u,l){t:{for(d in l){var d=!1;break t}d=!0}d||(l=Ga(l),typeof i=="string"?l!=null&&qn(l):et(i,u,l))}function it(i){At.call(this),this.headers=new Map,this.L=i||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}m(it,At);var pf=/^https?$/i,mf=["POST","PUT"];n=it.prototype,n.Fa=function(i){this.H=i},n.ea=function(i,u,l,d){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+i);u=u?u.toUpperCase():"GET",this.D=i,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Va.g(),this.g.onreadystatechange=I(f(this.Ca,this));try{this.B=!0,this.g.open(u,String(i),!0),this.B=!1}catch(V){Ha(this,V);return}if(i=l||"",l=new Map(this.headers),d)if(Object.getPrototypeOf(d)===Object.prototype)for(var A in d)l.set(A,d[A]);else if(typeof d.keys=="function"&&typeof d.get=="function")for(const V of d.keys())l.set(V,d.get(V));else throw Error("Unknown input type for opt_headers: "+String(d));d=Array.from(l.keys()).find(V=>V.toLowerCase()=="content-type"),A=a.FormData&&i instanceof a.FormData,!(Array.prototype.indexOf.call(mf,u,void 0)>=0)||d||A||l.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[V,D]of l)this.g.setRequestHeader(V,D);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(i),this.v=!1}catch(V){Ha(this,V)}};function Ha(i,u){i.h=!1,i.g&&(i.j=!0,i.g.abort(),i.j=!1),i.l=u,i.o=5,Wa(i),Yr(i)}function Wa(i){i.A||(i.A=!0,St(i,"complete"),St(i,"error"))}n.abort=function(i){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=i||7,St(this,"complete"),St(this,"abort"),Yr(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Yr(this,!0)),it.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?Qa(this):this.Xa())},n.Xa=function(){Qa(this)};function Qa(i){if(i.h&&typeof o<"u"){if(i.v&&Ie(i)==4)setTimeout(i.Ca.bind(i),0);else if(St(i,"readystatechange"),Ie(i)==4){i.h=!1;try{const V=i.ca();t:switch(V){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var u=!0;break t;default:u=!1}var l;if(!(l=u)){var d;if(d=V===0){let D=String(i.D).match(Ma)[1]||null;!D&&a.self&&a.self.location&&(D=a.self.location.protocol.slice(0,-1)),d=!pf.test(D?D.toLowerCase():"")}l=d}if(l)St(i,"complete"),St(i,"success");else{i.o=6;try{var A=Ie(i)>2?i.g.statusText:""}catch{A=""}i.l=A+" ["+i.ca()+"]",Wa(i)}}finally{Yr(i)}}}}function Yr(i,u){if(i.g){i.m&&(clearTimeout(i.m),i.m=null);const l=i.g;i.g=null,u||St(i,"ready");try{l.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function Ie(i){return i.g?i.g.readyState:0}n.ca=function(){try{return Ie(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(i){if(this.g){var u=this.g.responseText;return i&&u.indexOf(i)==0&&(u=u.substring(i.length)),Wh(u)}};function Ka(i){try{if(!i.g)return null;if("response"in i.g)return i.g.response;switch(i.F){case"":case"text":return i.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in i.g)return i.g.mozResponseArrayBuffer}return null}catch{return null}}function gf(i){const u={};i=(i.g&&Ie(i)>=2&&i.g.getAllResponseHeaders()||"").split(`\r
`);for(let d=0;d<i.length;d++){if(_(i[d]))continue;var l=Zh(i[d]);const A=l[0];if(l=l[1],typeof l!="string")continue;l=l.trim();const V=u[A]||[];u[A]=V,V.push(l)}jh(u,function(d){return d.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function Jn(i,u,l){return l&&l.internalChannelParams&&l.internalChannelParams[i]||u}function Xa(i){this.za=0,this.i=[],this.j=new jn,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=Jn("failFast",!1,i),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=Jn("baseRetryDelayMs",5e3,i),this.Za=Jn("retryDelaySeedMs",1e4,i),this.Ta=Jn("forwardChannelMaxRetries",2,i),this.va=Jn("forwardChannelRequestTimeoutMs",2e4,i),this.ma=i&&i.xmlHttpFactory||void 0,this.Ua=i&&i.Rb||void 0,this.Aa=i&&i.useFetchStreams||!1,this.O=void 0,this.L=i&&i.supportsCrossDomainXhr||!1,this.M="",this.h=new Na(i&&i.concurrentRequestLimit),this.Ba=new df,this.S=i&&i.fastHandshake||!1,this.R=i&&i.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=i&&i.Pb||!1,i&&i.ua&&this.j.ua(),i&&i.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&i&&i.detectBufferingProxy||!1,this.ia=void 0,i&&i.longPollingTimeout&&i.longPollingTimeout>0&&(this.ia=i.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=Xa.prototype,n.ka=8,n.I=1,n.connect=function(i,u,l,d){Ct(0),this.W=i,this.H=u||{},l&&d!==void 0&&(this.H.OSID=l,this.H.OAID=d),this.F=this.X,this.J=iu(this,null,this.W),ts(this)};function Pi(i){if(Ja(i),i.I==3){var u=i.V++,l=te(i.J);if(et(l,"SID",i.M),et(l,"RID",u),et(l,"TYPE","terminate"),Yn(i,l),u=new Te(i,i.j,u),u.M=2,u.A=Xr(te(l)),l=!1,a.navigator&&a.navigator.sendBeacon)try{l=a.navigator.sendBeacon(u.A.toString(),"")}catch{}!l&&a.Image&&(new Image().src=u.A,l=!0),l||(u.g=ou(u.j,null),u.g.ea(u.A)),u.F=Date.now(),Kr(u)}su(i)}function Zr(i){i.g&&(Si(i),i.g.cancel(),i.g=null)}function Ja(i){Zr(i),i.v&&(a.clearTimeout(i.v),i.v=null),es(i),i.h.cancel(),i.m&&(typeof i.m=="number"&&a.clearTimeout(i.m),i.m=null)}function ts(i){if(!Da(i.h)&&!i.m){i.m=!0;var u=i.Ea;ut||g(),lt||(ut(),lt=!0),w.add(u,i),i.D=0}}function _f(i,u){return ka(i.h)>=i.h.j-(i.m?1:0)?!1:i.m?(i.i=u.G.concat(i.i),!0):i.I==1||i.I==2||i.D>=(i.Sa?0:i.Ta)?!1:(i.m=Bn(f(i.Ea,i,u),ru(i,i.D)),i.D++,!0)}n.Ea=function(i){if(this.m)if(this.m=null,this.I==1){if(!i){this.V=Math.floor(Math.random()*1e5),i=this.V++;const A=new Te(this,this.j,i);let V=this.o;if(this.U&&(V?(V=ca(V),ha(V,this.U)):V=this.U),this.u!==null||this.R||(A.J=V,V=null),this.S)t:{for(var u=0,l=0;l<this.i.length;l++){e:{var d=this.i[l];if("__data__"in d.map&&(d=d.map.__data__,typeof d=="string")){d=d.length;break e}d=void 0}if(d===void 0)break;if(u+=d,u>4096){u=l;break t}if(u===4096||l===this.i.length-1){u=l+1;break t}}u=1e3}else u=1e3;u=Za(this,A,u),l=te(this.J),et(l,"RID",i),et(l,"CVER",22),this.G&&et(l,"X-HTTP-Session-Id",this.G),Yn(this,l),V&&(this.R?u="headers="+qn(Ga(V))+"&"+u:this.u&&Vi(l,this.u,V)),Ii(this.h,A),this.Ra&&et(l,"TYPE","init"),this.S?(et(l,"$req",u),et(l,"SID","null"),A.U=!0,Ei(A,l,null)):Ei(A,l,u),this.I=2}}else this.I==3&&(i?Ya(this,i):this.i.length==0||Da(this.h)||Ya(this))};function Ya(i,u){var l;u?l=u.l:l=i.V++;const d=te(i.J);et(d,"SID",i.M),et(d,"RID",l),et(d,"AID",i.K),Yn(i,d),i.u&&i.o&&Vi(d,i.u,i.o),l=new Te(i,i.j,l,i.D+1),i.u===null&&(l.J=i.o),u&&(i.i=u.G.concat(i.i)),u=Za(i,l,1e3),l.H=Math.round(i.va*.5)+Math.round(i.va*.5*Math.random()),Ii(i.h,l),Ei(l,d,u)}function Yn(i,u){i.H&&zr(i.H,function(l,d){et(u,d,l)}),i.l&&zr({},function(l,d){et(u,d,l)})}function Za(i,u,l){l=Math.min(i.i.length,l);const d=i.l?f(i.l.Ka,i.l,i):null;t:{var A=i.i;let G=-1;for(;;){const gt=["count="+l];G==-1?l>0?(G=A[0].g,gt.push("ofs="+G)):G=0:gt.push("ofs="+G);let tt=!0;for(let Et=0;Et<l;Et++){var V=A[Et].g;const ee=A[Et].map;if(V-=G,V<0)G=Math.max(0,A[Et].g-100),tt=!1;else try{V="req"+V+"_"||"";try{var D=ee instanceof Map?ee:Object.entries(ee);for(const[He,Ae]of D){let Re=Ae;c(Ae)&&(Re=pi(Ae)),gt.push(V+He+"="+encodeURIComponent(Re))}}catch(He){throw gt.push(V+"type="+encodeURIComponent("_badmap")),He}}catch{d&&d(ee)}}if(tt){D=gt.join("&");break t}}D=void 0}return i=i.i.splice(0,l),u.G=i,D}function tu(i){if(!i.g&&!i.v){i.Y=1;var u=i.Da;ut||g(),lt||(ut(),lt=!0),w.add(u,i),i.A=0}}function bi(i){return i.g||i.v||i.A>=3?!1:(i.Y++,i.v=Bn(f(i.Da,i),ru(i,i.A)),i.A++,!0)}n.Da=function(){if(this.v=null,eu(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var i=4*this.T;this.j.info("BP detection timer enabled: "+i),this.B=Bn(f(this.Wa,this),i)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Ct(10),Zr(this),eu(this))};function Si(i){i.B!=null&&(a.clearTimeout(i.B),i.B=null)}function eu(i){i.g=new Te(i,i.j,"rpc",i.Y),i.u===null&&(i.g.J=i.o),i.g.P=0;var u=te(i.na);et(u,"RID","rpc"),et(u,"SID",i.M),et(u,"AID",i.K),et(u,"CI",i.F?"0":"1"),!i.F&&i.ia&&et(u,"TO",i.ia),et(u,"TYPE","xmlhttp"),Yn(i,u),i.u&&i.o&&Vi(u,i.u,i.o),i.O&&(i.g.H=i.O);var l=i.g;i=i.ba,l.M=1,l.A=Xr(te(u)),l.u=null,l.R=!0,Sa(l,i)}n.Va=function(){this.C!=null&&(this.C=null,Zr(this),bi(this),Ct(19))};function es(i){i.C!=null&&(a.clearTimeout(i.C),i.C=null)}function nu(i,u){var l=null;if(i.g==u){es(i),Si(i),i.g=null;var d=2}else if(vi(i.h,u))l=u.G,Oa(i.h,u),d=1;else return;if(i.I!=0){if(u.o)if(d==1){l=u.u?u.u.length:0,u=Date.now()-u.F;var A=i.D;d=Wr(),St(d,new Aa(d,l)),ts(i)}else tu(i);else if(A=u.m,A==3||A==0&&u.X>0||!(d==1&&_f(i,u)||d==2&&bi(i)))switch(l&&l.length>0&&(u=i.h,u.i=u.i.concat(l)),A){case 1:Ge(i,5);break;case 4:Ge(i,10);break;case 3:Ge(i,6);break;default:Ge(i,2)}}}function ru(i,u){let l=i.Qa+Math.floor(Math.random()*i.Za);return i.isActive()||(l*=2),l*u}function Ge(i,u){if(i.j.info("Error code "+u),u==2){var l=f(i.bb,i),d=i.Ua;const A=!d;d=new we(d||"//www.google.com/images/cleardot.gif"),a.location&&a.location.protocol=="http"||zn(d,"https"),Xr(d),A?hf(d.toString(),l):ff(d.toString(),l)}else Ct(2);i.I=0,i.l&&i.l.pa(u),su(i),Ja(i)}n.bb=function(i){i?(this.j.info("Successfully pinged google.com"),Ct(2)):(this.j.info("Failed to ping google.com"),Ct(1))};function su(i){if(i.I=0,i.ja=[],i.l){const u=La(i.h);(u.length!=0||i.i.length!=0)&&(C(i.ja,u),C(i.ja,i.i),i.h.i.length=0,b(i.i),i.i.length=0),i.l.oa()}}function iu(i,u,l){var d=l instanceof we?te(l):new we(l);if(d.g!="")u&&(d.g=u+"."+d.g),Gn(d,d.u);else{var A=a.location;d=A.protocol,u=u?u+"."+A.hostname:A.hostname,A=+A.port;const V=new we(null);d&&zn(V,d),u&&(V.g=u),A&&Gn(V,A),l&&(V.h=l),d=V}return l=i.G,u=i.wa,l&&u&&et(d,l,u),et(d,"VER",i.ka),Yn(i,d),d}function ou(i,u,l){if(u&&!i.L)throw Error("Can't create secondary domain capable XhrIo object.");return u=i.Aa&&!i.ma?new it(new Ri({ab:l})):new it(i.ma),u.Fa(i.L),u}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function au(){}n=au.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function ns(){}ns.prototype.g=function(i,u){return new Bt(i,u)};function Bt(i,u){At.call(this),this.g=new Xa(u),this.l=i,this.h=u&&u.messageUrlParams||null,i=u&&u.messageHeaders||null,u&&u.clientProtocolHeaderRequired&&(i?i["X-Client-Protocol"]="webchannel":i={"X-Client-Protocol":"webchannel"}),this.g.o=i,i=u&&u.initMessageHeaders||null,u&&u.messageContentType&&(i?i["X-WebChannel-Content-Type"]=u.messageContentType:i={"X-WebChannel-Content-Type":u.messageContentType}),u&&u.sa&&(i?i["X-WebChannel-Client-Profile"]=u.sa:i={"X-WebChannel-Client-Profile":u.sa}),this.g.U=i,(i=u&&u.Qb)&&!_(i)&&(this.g.u=i),this.A=u&&u.supportsCrossDomainXhr||!1,this.v=u&&u.sendRawJson||!1,(u=u&&u.httpSessionIdParam)&&!_(u)&&(this.g.G=u,i=this.h,i!==null&&u in i&&(i=this.h,u in i&&delete i[u])),this.j=new mn(this)}m(Bt,At),Bt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},Bt.prototype.close=function(){Pi(this.g)},Bt.prototype.o=function(i){var u=this.g;if(typeof i=="string"){var l={};l.__data__=i,i=l}else this.v&&(l={},l.__data__=pi(i),i=l);u.i.push(new nf(u.Ya++,i)),u.I==3&&ts(u)},Bt.prototype.N=function(){this.g.l=null,delete this.j,Pi(this.g),delete this.g,Bt.Z.N.call(this)};function uu(i){mi.call(this),i.__headers__&&(this.headers=i.__headers__,this.statusCode=i.__status__,delete i.__headers__,delete i.__status__);var u=i.__sm__;if(u){t:{for(const l in u){i=l;break t}i=void 0}(this.i=i)&&(i=this.i,u=u!==null&&i in u?u[i]:void 0),this.data=u}else this.data=i}m(uu,mi);function cu(){gi.call(this),this.status=1}m(cu,gi);function mn(i){this.g=i}m(mn,au),mn.prototype.ra=function(){St(this.g,"a")},mn.prototype.qa=function(i){St(this.g,new uu(i))},mn.prototype.pa=function(i){St(this.g,new cu)},mn.prototype.oa=function(){St(this.g,"b")},ns.prototype.createWebChannel=ns.prototype.g,Bt.prototype.send=Bt.prototype.o,Bt.prototype.open=Bt.prototype.m,Bt.prototype.close=Bt.prototype.close,Oc=function(){return new ns},kc=function(){return Wr()},Dc=qe,Gi={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Qr.NO_ERROR=0,Qr.TIMEOUT=8,Qr.HTTP_ERROR=6,fs=Qr,Ra.COMPLETE="complete",Nc=Ra,Ta.EventType=Un,Un.OPEN="a",Un.CLOSE="b",Un.ERROR="c",Un.MESSAGE="d",At.prototype.listen=At.prototype.J,nr=Ta,it.prototype.listenOnce=it.prototype.K,it.prototype.getLastError=it.prototype.Ha,it.prototype.getLastErrorCode=it.prototype.ya,it.prototype.getStatus=it.prototype.ca,it.prototype.getResponseJson=it.prototype.La,it.prototype.getResponseText=it.prototype.la,it.prototype.send=it.prototype.ea,it.prototype.setWithCredentials=it.prototype.Fa,xc=it}).apply(typeof ss<"u"?ss:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Sn="12.17.0";function Ld(n){Sn=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nn=new Ic("@firebase/firestore");function gn(){return nn.logLevel}function O(n,...t){if(nn.logLevel<=X.DEBUG){const e=t.map(ho);nn.debug(`Firestore (${Sn}): ${n}`,...e)}}function ye(n,...t){if(nn.logLevel<=X.ERROR){const e=t.map(ho);nn.error(`Firestore (${Sn}): ${n}`,...e)}}function Zt(n,...t){if(nn.logLevel<=X.WARN){const e=t.map(ho);nn.warn(`Firestore (${Sn}): ${n}`,...e)}}function ho(n){if(typeof n=="string")return n;try{return function(e){return JSON.stringify(e)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function B(n,t,e){let r="Unexpected state";typeof t=="string"?r=t:e=t,Lc(n,r,e)}function Lc(n,t,e){let r=`FIRESTORE (${Sn}) INTERNAL ASSERTION FAILED: ${t} (ID: ${n.toString(16)})`;if(e!==void 0)try{r+=" CONTEXT: "+JSON.stringify(e)}catch{r+=" CONTEXT: "+e}throw ye(r),new Error(r)}function U(n,t,e,r){let s="Unexpected state";typeof e=="string"?s=e:r=e,n||Lc(t,s,r)}function $(n,t){return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Md(n){const t=typeof self<"u"&&(self.crypto||self.msCrypto),e=new Uint8Array(n);if(t&&typeof t.getRandomValues=="function")t.getRandomValues(e);else for(let r=0;r<n;r++)e[r]=Math.floor(256*Math.random());return e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo{static newId(){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",e=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const s=Md(40);for(let o=0;o<s.length;++o)r.length<20&&s[o]<e&&(r+=t.charAt(s[o]%62))}return r}}function Q(n,t){return n<t?-1:n>t?1:0}function Hi(n,t){const e=Math.min(n.length,t.length);for(let r=0;r<e;r++){const s=n.charAt(r),o=t.charAt(r);if(s!==o)return Di(s)===Di(o)?Q(s,o):Di(s)?1:-1}return Q(n.length,t.length)}const Ud=55296,Fd=57343;function Di(n){const t=n.charCodeAt(0);return t>=Ud&&t<=Fd}function In(n,t,e){return n.length===t.length&&n.every((r,s)=>e(r,t[s]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rt{constructor(t,e){this.comparator=t,this.root=e||vt.EMPTY}insert(t,e){return new rt(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,vt.BLACK,null,null))}remove(t){return new rt(this.comparator,this.root.remove(t,this.comparator).copy(null,null,vt.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const r=this.comparator(t,e.key);if(r===0)return e.value;r<0?e=e.left:r>0&&(e=e.right)}return null}indexOf(t){let e=0,r=this.root;for(;!r.isEmpty();){const s=this.comparator(t,r.key);if(s===0)return e+r.left.size;s<0?r=r.left:(e+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal((e,r)=>(t(e,r),!1))}toString(){const t=[];return this.inorderTraversal((e,r)=>(t.push(`${e}:${r}`),!1)),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new is(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new is(this.root,t,this.comparator,!1)}getReverseIterator(){return new is(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new is(this.root,t,this.comparator,!0)}}class is{constructor(t,e,r,s){this.isReverse=s,this.nodeStack=[];let o=1;for(;!t.isEmpty();)if(o=e?r(t.key,e):1,e&&s&&(o*=-1),o<0)t=this.isReverse?t.left:t.right;else{if(o===0){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class vt{constructor(t,e,r,s,o){this.key=t,this.value=e,this.color=r??vt.RED,this.left=s??vt.EMPTY,this.right=o??vt.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,r,s,o){return new vt(t??this.key,e??this.value,r??this.color,s??this.left,o??this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,r){let s=this;const o=r(t,s.key);return s=o<0?s.copy(null,null,null,s.left.insert(t,e,r),null):o===0?s.copy(null,e,null,null,null):s.copy(null,null,null,null,s.right.insert(t,e,r)),s.fixUp()}removeMin(){if(this.left.isEmpty())return vt.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let r,s=this;if(e(t,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(t,e),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),e(t,s.key)===0){if(s.right.isEmpty())return vt.EMPTY;r=s.right.min(),s=s.copy(r.key,r.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(t,e))}return s.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,vt.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,vt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw B(43730,{key:this.key,value:this.value});if(this.right.isRed())throw B(14113,{key:this.key,value:this.value});const t=this.left.check();if(t!==this.right.check())throw B(27949);return t+(this.isRed()?0:1)}}vt.EMPTY=null,vt.RED=!0,vt.BLACK=!1;vt.EMPTY=new class{constructor(){this.size=0}get key(){throw B(57766)}get value(){throw B(16141)}get color(){throw B(16727)}get left(){throw B(29726)}get right(){throw B(36894)}copy(t,e,r,s,o){return this}insert(t,e,r){return new vt(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dt{constructor(t){this.comparator=t,this.data=new rt(this.comparator)}has(t){return this.data.get(t)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal((e,r)=>(t(e),!1))}forEachInRange(t,e){const r=this.data.getIteratorFrom(t[0]);for(;r.hasNext();){const s=r.getNext();if(this.comparator(s.key,t[1])>=0)return;e(s.key)}}forEachWhile(t,e){let r;for(r=e!==void 0?this.data.getIteratorFrom(e):this.data.getIterator();r.hasNext();)if(!t(r.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new yu(this.data.getIterator())}getIteratorFrom(t){return new yu(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach(r=>{e=e.add(r)}),e}isEqual(t){if(!(t instanceof dt)||this.size!==t.size)return!1;const e=this.data.getIterator(),r=t.data.getIterator();for(;e.hasNext();){const s=e.getNext().key,o=r.getNext().key;if(this.comparator(s,o)!==0)return!1}return!0}toArray(){const t=[];return this.forEach(e=>{t.push(e)}),t}toString(){const t=[];return this.forEach(e=>t.push(e)),"SortedSet("+t.toString()+")"}copy(t){const e=new dt(this.comparator);return e.data=t,e}}class yu{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const x={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class L extends an{constructor(t,e){super(t,e),this.code=t,this.message=e,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const re="__name__";class ne{constructor(t,e,r){e===void 0?e=0:e>t.length&&B(637,{offset:e,range:t.length}),r===void 0?r=t.length-e:r>t.length-e&&B(1746,{length:r,range:t.length-e}),this.segments=t,this.offset=e,this.len=r}get length(){return this.len}isEqual(t){return ne.comparator(this,t)===0}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof ne?t.forEach(r=>{e.push(r)}):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=t===void 0?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return this.length===0}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,r=this.limit();e<r;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const r=Math.min(t.length,e.length);for(let s=0;s<r;s++){const o=ne.compareSegments(t.get(s),e.get(s));if(o!==0)return o}return Q(t.length,e.length)}static compareSegments(t,e){const r=ne.isNumericId(t),s=ne.isNumericId(e);return r&&!s?-1:!r&&s?1:r&&s?ne.extractNumericId(t).compare(ne.extractNumericId(e)):Hi(t,e)}static isNumericId(t){return t.startsWith("__id")&&t.endsWith("__")}static extractNumericId(t){return be.fromString(t.substring(4,t.length-2))}}class Y extends ne{construct(t,e,r){return new Y(t,e,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...t){const e=[];for(const r of t){if(r.indexOf("//")>=0)throw new L(x.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);e.push(...r.split("/").filter(s=>s.length>0))}return new Y(e)}static emptyPath(){return new Y([])}}const Bd=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let Gt=class _n extends ne{construct(t,e,r){return new _n(t,e,r)}static isValidIdentifier(t){return Bd.test(t)}canonicalString(){return this.toArray().map(t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),_n.isValidIdentifier(t)||(t="`"+t+"`"),t)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===re}static keyField(){return new _n([re])}static fromServerFormat(t){const e=[];let r="",s=0;const o=()=>{if(r.length===0)throw new L(x.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(r),r=""};let a=!1;for(;s<t.length;){const c=t[s];if(c==="\\"){if(s+1===t.length)throw new L(x.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const h=t[s+1];if(h!=="\\"&&h!=="."&&h!=="`")throw new L(x.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);r+=h,s+=2}else c==="`"?(a=!a,s++):c!=="."||a?(r+=c,s++):(o(),s++)}if(o(),a)throw new L(x.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new _n(e)}static emptyPath(){return new _n([])}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kt{constructor(t){this.fields=t,t.sort(Gt.comparator)}static empty(){return new Kt([])}unionWith(t){let e=new dt(Gt.comparator);for(const r of this.fields)e=e.add(r);for(const r of t)e=e.add(r);return new Kt(e.toArray())}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return In(this.fields,t.fields,(e,r)=>e.isEqual(r))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ws(n){let t=0;for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t++;return t}function un(n,t){for(const e in n)Object.prototype.hasOwnProperty.call(n,e)&&t(e,n[e])}function jd(n,t){const e=[];for(const r in n)Object.prototype.hasOwnProperty.call(n,r)&&e.push(t(n[r],r,n));return e}function Mc(n){for(const t in n)if(Object.prototype.hasOwnProperty.call(n,t))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class F{constructor(t){this.path=t}static fromPath(t){return new F(Y.fromString(t))}static fromName(t){return new F(Y.fromString(t).popFirst(5))}static empty(){return new F(Y.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(t){return t!==null&&Y.comparator(this.path,t.path)===0}toString(){return this.path.toString()}static comparator(t,e){return Y.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new F(new Y(t.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uc(n,t,e){if(!e)throw new L(x.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${t}.`)}function qd(n,t,e,r){if(t===!0&&r===!0)throw new L(x.INVALID_ARGUMENT,`${n} and ${e} cannot be used together.`)}function Eu(n){if(!F.isDocumentKey(n))throw new L(x.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Tu(n){if(F.isDocumentKey(n))throw new L(x.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Dr(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function po(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const t=function(r){return r.constructor?r.constructor.name:null}(n);return t?`a custom ${t} object`:"an object"}}return typeof n=="function"?"a function":B(12329,{type:typeof n})}function Jt(n,t){if("_delegate"in n&&(n=n._delegate),!(n instanceof t)){if(t.name===n.constructor.name)throw new L(x.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const e=po(n);throw new L(x.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${e}`)}}return n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ft(n,t){const e={typeString:n};return t&&(e.value=t),e}function kr(n,t){if(!Dr(n))throw new L(x.INVALID_ARGUMENT,"JSON must be an object");let e;for(const r in t)if(t[r]){const s=t[r].typeString,o="value"in t[r]?{value:t[r].value}:void 0;if(!(r in n)){e=`JSON missing required field: '${r}'`;break}const a=n[r];if(s&&typeof a!==s){e=`JSON field '${r}' must be a ${s}.`;break}if(o!==void 0&&a!==o.value){e=`Expected '${r}' field to equal '${o.value}'`;break}}if(e)throw new L(x.INVALID_ARGUMENT,e);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wu=-62135596800,vu=1e6;class nt{static now(){return nt.fromMillis(Date.now())}static fromDate(t){return nt.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),r=Math.floor((t-1e3*e)*vu);return new nt(e,r)}constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new L(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new L(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<wu)throw new L(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new L(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/vu}_compareTo(t){return this.seconds===t.seconds?Q(this.nanoseconds,t.nanoseconds):Q(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:nt._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(t){if(kr(t,nt._jsonSchema))return new nt(t.seconds,t.nanoseconds)}valueOf(){const t=this.seconds-wu;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}nt._jsonSchemaVersion="firestore/timestamp/1.0",nt._jsonSchema={type:ft("string",nt._jsonSchemaVersion),seconds:ft("number"),nanoseconds:ft("number")};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pt{constructor(t){this.binaryString=t}static fromBase64String(t){const e=function(s){try{return atob(s)}catch(o){throw typeof DOMException<"u"&&o instanceof DOMException?new Fc("Invalid base64 string: "+o):o}}(t);return new pt(e)}static fromUint8Array(t){const e=function(s){let o="";for(let a=0;a<s.length;++a)o+=String.fromCharCode(s[a]);return o}(t);return new pt(e)}[Symbol.iterator](){let t=0;return{next:()=>t<this.binaryString.length?{value:this.binaryString.charCodeAt(t++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(e){return btoa(e)}(this.binaryString)}toUint8Array(){return function(e){const r=new Uint8Array(e.length);for(let s=0;s<e.length;s++)r[s]=e.charCodeAt(s);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return Q(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}pt.EMPTY_BYTE_STRING=new pt("");const $d=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Ne(n){if(U(!!n,39018),typeof n=="string"){let t=0;const e=$d.exec(n);if(U(!!e,46558,{timestamp:n}),e[1]){let s=e[1];s=(s+"000000000").substr(0,9),t=Number(s)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:t}}return{seconds:st(n.seconds),nanos:st(n.nanos)}}function st(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function De(n){return typeof n=="string"?pt.fromBase64String(n):pt.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bc="server_timestamp",jc="__type__",qc="__previous_value__",$c="__local_write_time__";function Fs(n){var e,r;return((r=(((e=n==null?void 0:n.mapValue)==null?void 0:e.fields)||{})[jc])==null?void 0:r.stringValue)===Bc}function Or(n){const t=n.mapValue.fields[qc];return Fs(t)?Or(t):t}function An(n){const t=Ne(n.mapValue.fields[$c].timestampValue);return new nt(t.seconds,t.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zd{constructor(t,e,r,s,o,a,c,h,f,p,m,I,b){this.databaseId=t,this.appId=e,this.persistenceKey=r,this.host=s,this.ssl=o,this.forceLongPolling=a,this.autoDetectLongPolling=c,this.longPollingOptions=h,this.useFetchStreams=f,this.isUsingEmulator=p,this.apiKey=m,this._customHeaders=I,this.grpcFlowControlWindow=b}}const vs="(default)";class _r{constructor(t,e){this.projectId=t,this.database=e||vs}static empty(){return new _r("","")}get isDefaultDatabase(){return this.database===vs}isEqual(t){return t instanceof _r&&t.projectId===this.projectId&&t.database===this.database}}function Gd(n,t){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new L(x.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new _r(n.options.projectId,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mo=-1;function Bs(n){return n==null}function yr(n){return n===0&&1/n==-1/0}function Hd(n){return typeof n=="number"&&Number.isInteger(n)&&!yr(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}function Wd(n){return typeof n=="string"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zc="__type__",Qd="__max__",os={mapValue:{}},Gc="__vector__",Er="value",Rn={nullValue:"NULL_VALUE"},Mt={booleanValue:!0},wt={booleanValue:!1};function mt(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?Fs(n)?4:Kd(n)?9007199254740991:Is(n)?10:11:B(28295,{value:n})}function Qt(n,t,e){if(n===t)return!0;const r=mt(n);if(r!==mt(t))return!1;switch(r){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===t.booleanValue;case 4:return An(n).isEqual(An(t));case 3:return function(o,a){if(typeof o.timestampValue=="string"&&typeof a.timestampValue=="string"&&o.timestampValue.length===a.timestampValue.length)return o.timestampValue===a.timestampValue;const c=Ne(o.timestampValue),h=Ne(a.timestampValue);return c.seconds===h.seconds&&c.nanos===h.nanos}(n,t);case 5:return n.stringValue===t.stringValue;case 6:return function(o,a){return De(o.bytesValue).isEqual(De(a.bytesValue))}(n,t);case 7:return n.referenceValue===t.referenceValue;case 8:return function(o,a){return st(o.geoPointValue.latitude)===st(a.geoPointValue.latitude)&&st(o.geoPointValue.longitude)===st(a.geoPointValue.longitude)}(n,t);case 2:return function(o,a,c){if("integerValue"in o&&"integerValue"in a)return st(o.integerValue)===st(a.integerValue);let h,f;if("doubleValue"in o&&"doubleValue"in a)h=st(o.doubleValue),f=st(a.doubleValue);else{if(!(c!=null&&c.t))return!1;h=st(o.integerValue??o.doubleValue),f=st(a.integerValue??a.doubleValue)}return h===f?!!(c!=null&&c.i)||yr(h)===yr(f):!!(c===void 0||c.o)&&isNaN(h)&&isNaN(f)}(n,t,e);case 9:return In(n.arrayValue.values||[],t.arrayValue.values||[],(s,o)=>Qt(s,o,e));case 10:case 11:return function(o,a,c){const h=o.mapValue.fields||{},f=a.mapValue.fields||{};if(ws(h)!==ws(f))return!1;for(const p in h)if(h.hasOwnProperty(p)&&(f[p]===void 0||!Qt(h[p],f[p],c)))return!1;return!0}(n,t,e);default:return B(52216,{left:n})}}function Tr(n,t){return(n.values||[]).find(e=>Qt(e,t))!==void 0}function Ut(n,t){if(n===t)return 0;const e=mt(n),r=mt(t);if(e!==r)return Q(e,r);switch(e){case 0:case 9007199254740991:return 0;case 1:return Q(n.booleanValue,t.booleanValue);case 2:return function(o,a){const c=st(o.integerValue||o.doubleValue),h=st(a.integerValue||a.doubleValue);return c<h?-1:c>h?1:c===h?0:isNaN(c)?isNaN(h)?0:-1:1}(n,t);case 3:return Iu(n.timestampValue,t.timestampValue);case 4:return Iu(An(n),An(t));case 5:return Hi(n.stringValue,t.stringValue);case 6:return function(o,a){const c=De(o),h=De(a);return c.compareTo(h)}(n.bytesValue,t.bytesValue);case 7:return function(o,a){const c=o.split("/"),h=a.split("/");for(let f=0;f<c.length&&f<h.length;f++){const p=Q(c[f],h[f]);if(p!==0)return p}return Q(c.length,h.length)}(n.referenceValue,t.referenceValue);case 8:return function(o,a){const c=Q(st(o.latitude),st(a.latitude));return c!==0?c:Q(st(o.longitude),st(a.longitude))}(n.geoPointValue,t.geoPointValue);case 9:return Au(n.arrayValue,t.arrayValue);case 10:return function(o,a){var I,b,C,M;const c=o.fields||{},h=a.fields||{},f=(I=c[Er])==null?void 0:I.arrayValue,p=(b=h[Er])==null?void 0:b.arrayValue,m=Q(((C=f==null?void 0:f.values)==null?void 0:C.length)||0,((M=p==null?void 0:p.values)==null?void 0:M.length)||0);return m!==0?m:Au(f,p)}(n.mapValue,t.mapValue);case 11:return function(o,a){if(o===os.mapValue&&a===os.mapValue)return 0;if(o===os.mapValue)return 1;if(a===os.mapValue)return-1;const c=o.fields||{},h=Object.keys(c),f=a.fields||{},p=Object.keys(f);h.sort(),p.sort();for(let m=0;m<h.length&&m<p.length;++m){const I=Hi(h[m],p[m]);if(I!==0)return I;const b=Ut(c[h[m]],f[p[m]]);if(b!==0)return b}return Q(h.length,p.length)}(n.mapValue,t.mapValue);default:throw B(23264,{u:e})}}function Iu(n,t){if(typeof n=="string"&&typeof t=="string"&&n.length===t.length)return Q(n,t);const e=Ne(n),r=Ne(t),s=Q(e.seconds,r.seconds);return s!==0?s:Q(e.nanos,r.nanos)}function Au(n,t){const e=n.values||[],r=t.values||[];for(let s=0;s<e.length&&s<r.length;++s){const o=Ut(e[s],r[s]);if(o!==void 0&&o!==0)return o}return Q(e.length,r.length)}function Vn(n){return Wi(n)}function Wi(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(e){const r=Ne(e);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(e){return De(e).toBase64()}(n.bytesValue):"referenceValue"in n?function(e){return F.fromName(e).toString()}(n.referenceValue):"geoPointValue"in n?function(e){return`geo(${e.latitude},${e.longitude})`}(n.geoPointValue):"arrayValue"in n?function(e){let r="[",s=!0;for(const o of e.values||[])s?s=!1:r+=",",r+=Wi(o);return r+"]"}(n.arrayValue):"mapValue"in n?function(e){const r=Object.keys(e.fields||{}).sort();let s="{",o=!0;for(const a of r)o?o=!1:s+=",",s+=`${a}:${Wi(e.fields[a])}`;return s+"}"}(n.mapValue):B(61005,{value:n})}function ds(n){switch(mt(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const t=Or(n);return t?16+ds(t):16;case 5:return 2*n.stringValue.length;case 6:return De(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((s,o)=>s+ds(o),0)}(n.arrayValue);case 10:case 11:return function(r){let s=0;return un(r.fields,(o,a)=>{s+=o.length+ds(a)}),s}(n.mapValue);default:throw B(13486,{value:n})}}function se(n){return!!n&&"integerValue"in n}function Ke(n){return!!n&&"doubleValue"in n}function ke(n){return se(n)||Ke(n)}function Pn(n){return!!n&&"arrayValue"in n}function $t(n){return!!n&&"nullValue"in n}function Ft(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function Je(n){return!!n&&"mapValue"in n}function Is(n){var e,r;return((r=(((e=n==null?void 0:n.mapValue)==null?void 0:e.fields)||{})[zc])==null?void 0:r.stringValue)===Gc}function Qi(n){var t,e;return(e=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[Er])==null?void 0:e.arrayValue}function or(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const t={mapValue:{fields:{}}};return un(n.mapValue.fields,(e,r)=>t.mapValue.fields[e]=or(r)),t}if(n.arrayValue){const t={arrayValue:{values:[]}};for(let e=0;e<(n.arrayValue.values||[]).length;++e)t.arrayValue.values[e]=or(n.arrayValue.values[e]);return t}return{...n}}function Kd(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===Qd}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qt{constructor(t){this.value=t}static empty(){return new qt({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let r=0;r<t.length-1;++r)if(e=(e.mapValue.fields||{})[t.get(r)],!Je(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=or(e)}setAll(t){let e=Gt.emptyPath(),r={},s=[];t.forEach((a,c)=>{if(!e.isImmediateParentOf(c)){const h=this.getFieldsMap(e);this.applyChanges(h,r,s),r={},s=[],e=c.popLast()}a?r[c.lastSegment()]=or(a):s.push(c.lastSegment())});const o=this.getFieldsMap(e);this.applyChanges(o,r,s)}delete(t){const e=this.field(t.popLast());Je(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return Qt(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let r=0;r<t.length;++r){let s=e.mapValue.fields[t.get(r)];Je(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},e.mapValue.fields[t.get(r)]=s),e=s}return e.mapValue.fields}applyChanges(t,e,r){un(e,(s,o)=>t[s]=o);for(const s of r)delete t[s]}clone(){return new qt(or(this.value))}}function Hc(n){const t=[];return un(n.fields,(e,r)=>{const s=new Gt([e]);if(Je(r)){const o=Hc(r.mapValue).fields;if(o.length===0)t.push(s);else for(const a of o)t.push(s.child(a))}else t.push(s)}),new Kt(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function js(n,t){if(n.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:yr(t)?"-0":t}}function go(n){return{integerValue:""+n}}function _o(n,t,e){return Hd(t)?go(t):js(n,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{constructor(){this._=void 0}}function Xd(n,t,e){return n instanceof wr?function(s,o){const a={fields:{[jc]:{stringValue:Bc},[$c]:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return o&&Fs(o)&&(o=Or(o)),o&&(a.fields[qc]=o),{mapValue:a}}(e,t):n instanceof vr?Qc(n,t):n instanceof Ir?Kc(n,t):n instanceof Ar?function(s,o){const a=Wc(s,o),c=Vs(a)+Vs(s.l);return se(a)&&se(s.l)?go(c):js(s.serializer,c)}(n,t):n instanceof As?function(s,o){return Ru(s,o,Math.min)}(n,t):n instanceof Rs?function(s,o){return Ru(s,o,Math.max)}(n,t):void 0}function Jd(n,t,e){return n instanceof vr?Qc(n,t):n instanceof Ir?Kc(n,t):e}function Wc(n,t){return n instanceof Ar?ke(t)?t:{integerValue:0}:null}class wr extends qs{}class vr extends qs{constructor(t){super(),this.elements=t}}function Qc(n,t){const e=Xc(t);for(const r of n.elements)e.some(s=>Qt(s,r))||e.push(r);return{arrayValue:{values:e}}}class Ir extends qs{constructor(t){super(),this.elements=t}}function Kc(n,t){let e=Xc(t);for(const r of n.elements)e=e.filter(s=>!Qt(s,r));return{arrayValue:{values:e}}}class yo extends qs{constructor(t,e){super(),this.serializer=t,this.l=e}}class Ar extends yo{}class As extends yo{}class Rs extends yo{}function Ru(n,t,e){if(!ke(t))return n.l;const r=e(Vs(t),Vs(n.l));return se(t)&&se(n.l)?go(r):js(n.serializer,r)}function Vs(n){return st(n.integerValue||n.doubleValue)}function Xc(n){return Pn(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yd{constructor(t,e){this.field=t,this.transform=e}}function Zd(n,t){return n.field.isEqual(t.field)&&function(r,s){return r instanceof vr&&s instanceof vr||r instanceof Ir&&s instanceof Ir?In(r.elements,s.elements,Qt):r instanceof Ar&&s instanceof Ar||r instanceof As&&s instanceof As||r instanceof Rs&&s instanceof Rs?Qt(r.l,s.l):r instanceof wr&&s instanceof wr}(n.transform,t.transform)}class tp{constructor(t,e){this.version=t,this.transformResults=e}}class ie{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new ie}static exists(t){return new ie(void 0,t)}static updateTime(t){return new ie(t)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}function ps(n,t){return n.updateTime!==void 0?t.isFoundDocument()&&t.version.isEqual(n.updateTime):n.exists===void 0||n.exists===t.isFoundDocument()}class $s{}function Jc(n,t){if(!n.hasLocalMutations||t&&t.fields.length===0)return null;if(t===null)return n.isNoDocument()?new Eo(n.key,ie.none()):new Lr(n.key,n.data,ie.none());{const e=n.data,r=qt.empty();let s=new dt(Gt.comparator);for(let o of t.fields)if(!s.has(o)){let a=e.field(o);a===null&&o.length>1&&(o=o.popLast(),a=e.field(o)),a===null?r.delete(o):r.set(o,a),s=s.add(o)}return new cn(n.key,r,new Kt(s.toArray()),ie.none())}}function ep(n,t,e){n instanceof Lr?function(s,o,a){const c=s.value.clone(),h=Pu(s.fieldTransforms,o,a.transformResults);c.setAll(h),o.convertToFoundDocument(a.version,c).setHasCommittedMutations()}(n,t,e):n instanceof cn?function(s,o,a){if(!ps(s.precondition,o))return void o.convertToUnknownDocument(a.version);const c=Pu(s.fieldTransforms,o,a.transformResults),h=o.data;h.setAll(Yc(s)),h.setAll(c),o.convertToFoundDocument(a.version,h).setHasCommittedMutations()}(n,t,e):function(s,o,a){o.convertToNoDocument(a.version).setHasCommittedMutations()}(0,t,e)}function ar(n,t,e,r){return n instanceof Lr?function(o,a,c,h){if(!ps(o.precondition,a))return c;const f=o.value.clone(),p=bu(o.fieldTransforms,h,a);return f.setAll(p),a.convertToFoundDocument(a.version,f).setHasLocalMutations(),null}(n,t,e,r):n instanceof cn?function(o,a,c,h){if(!ps(o.precondition,a))return c;const f=bu(o.fieldTransforms,h,a),p=a.data;return p.setAll(Yc(o)),p.setAll(f),a.convertToFoundDocument(a.version,p).setHasLocalMutations(),c===null?null:c.unionWith(o.fieldMask.fields).unionWith(o.fieldTransforms.map(m=>m.field))}(n,t,e,r):function(o,a,c){return ps(o.precondition,a)?(a.convertToNoDocument(a.version).setHasLocalMutations(),null):c}(n,t,e)}function np(n,t){let e=null;for(const r of n.fieldTransforms){const s=t.data.field(r.field),o=Wc(r.transform,s||null);o!=null&&(e===null&&(e=qt.empty()),e.set(r.field,o))}return e||null}function Vu(n,t){return n.type===t.type&&!!n.key.isEqual(t.key)&&!!n.precondition.isEqual(t.precondition)&&!!function(r,s){return r===void 0&&s===void 0||!(!r||!s)&&In(r,s,(o,a)=>Zd(o,a))}(n.fieldTransforms,t.fieldTransforms)&&(n.type===0?n.value.isEqual(t.value):n.type!==1||n.data.isEqual(t.data)&&n.fieldMask.isEqual(t.fieldMask))}class Lr extends $s{constructor(t,e,r,s=[]){super(),this.key=t,this.value=e,this.precondition=r,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class cn extends $s{constructor(t,e,r,s,o=[]){super(),this.key=t,this.data=e,this.fieldMask=r,this.precondition=s,this.fieldTransforms=o,this.type=1}getFieldMask(){return this.fieldMask}}function Yc(n){const t=new Map;return n.fieldMask.fields.forEach(e=>{if(!e.isEmpty()){const r=n.data.field(e);t.set(e,r)}}),t}function Pu(n,t,e){const r=new Map;U(n.length===e.length,32656,{h:e.length,T:n.length});for(let s=0;s<e.length;s++){const o=n[s],a=o.transform,c=t.data.field(o.field);r.set(o.field,Jd(a,c,e[s]))}return r}function bu(n,t,e){const r=new Map;for(const s of n){const o=s.transform,a=e.data.field(s.field);r.set(s.field,Xd(o,a,t))}return r}class Eo extends $s{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class rp extends $s{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps{constructor(t,e){this.position=t,this.inclusive=e}}function Su(n,t,e){let r=0;for(let s=0;s<n.position.length;s++){const o=t[s],a=n.position[s];if(o.field.isKeyField()?r=F.comparator(F.fromName(a.referenceValue),e.key):r=Ut(a,e.data.field(o.field)),o.dir==="desc"&&(r*=-1),r!==0)break}return r}function Cu(n,t){if(n===null)return t===null;if(t===null||n.inclusive!==t.inclusive||n.position.length!==t.position.length)return!1;for(let e=0;e<n.position.length;e++)if(!Qt(n.position[e],t.position[e]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zc{}class _t extends Zc{constructor(t,e,r){super(),this.field=t,this.op=e,this.value=r}static create(t,e,r){return t.isKeyField()?e==="in"||e==="not-in"?this.createKeyFieldInFilter(t,e,r):new ip(t,e,r):e==="array-contains"?new up(t,r):e==="in"?new cp(t,r):e==="not-in"?new lp(t,r):e==="array-contains-any"?new hp(t,r):new _t(t,e,r)}static createKeyFieldInFilter(t,e,r){return e==="in"?new op(t,r):new ap(t,r)}matches(t){const e=t.data.field(this.field);return this.op==="!="?e!==null&&e.nullValue===void 0&&this.matchesComparison(Ut(e,this.value)):e!==null&&mt(this.value)===mt(e)&&this.matchesComparison(Ut(e,this.value))}matchesComparison(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return t===0;case"!=":return t!==0;case">":return t>0;case">=":return t>=0;default:return B(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class ce extends Zc{constructor(t,e){super(),this.filters=t,this.op=e,this.P=null}static create(t,e){return new ce(t,e)}matches(t){return tl(this)?this.filters.find(e=>!e.matches(t))===void 0:this.filters.find(e=>e.matches(t))!==void 0}getFlattenedFilters(){return this.P!==null||(this.P=this.filters.reduce((t,e)=>t.concat(e.getFlattenedFilters()),[])),this.P}getFilters(){return Object.assign([],this.filters)}}function tl(n){return n.op==="and"}function el(n){return sp(n)&&tl(n)}function sp(n){for(const t of n.filters)if(t instanceof ce)return!1;return!0}function Ki(n){if(n instanceof _t)return n.field.canonicalString()+n.op.toString()+Vn(n.value);if(el(n))return n.filters.map(t=>Ki(t)).join(",");{const t=n.filters.map(e=>Ki(e)).join(",");return`${n.op}(${t})`}}function nl(n,t){return n instanceof _t?function(r,s){return s instanceof _t&&r.op===s.op&&r.field.isEqual(s.field)&&Qt(r.value,s.value)}(n,t):n instanceof ce?function(r,s){return s instanceof ce&&r.op===s.op&&r.filters.length===s.filters.length?r.filters.reduce((o,a,c)=>o&&nl(a,s.filters[c]),!0):!1}(n,t):void B(19439)}function rl(n){return n instanceof _t?function(e){return`${e.field.canonicalString()} ${e.op} ${Vn(e.value)}`}(n):n instanceof ce?function(e){return e.op.toString()+" {"+e.getFilters().map(rl).join(" ,")+"}"}(n):"Filter"}class ip extends _t{constructor(t,e,r){super(t,e,r),this.key=F.fromName(r.referenceValue)}matches(t){const e=F.comparator(t.key,this.key);return this.matchesComparison(e)}}class op extends _t{constructor(t,e){super(t,"in",e),this.keys=sl("in",e)}matches(t){return this.keys.some(e=>e.isEqual(t.key))}}class ap extends _t{constructor(t,e){super(t,"not-in",e),this.keys=sl("not-in",e)}matches(t){return!this.keys.some(e=>e.isEqual(t.key))}}function sl(n,t){var e;return(((e=t.arrayValue)==null?void 0:e.values)||[]).map(r=>F.fromName(r.referenceValue))}class up extends _t{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return Pn(e)&&Tr(e.arrayValue,this.value)}}class cp extends _t{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return e!==null&&Tr(this.value.arrayValue,e)}}class lp extends _t{constructor(t,e){super(t,"not-in",e)}matches(t){if(Tr(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return e!==null&&e.nullValue===void 0&&!Tr(this.value.arrayValue,e)}}class hp extends _t{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!Pn(e)||!e.arrayValue.values)&&e.arrayValue.values.some(r=>Tr(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bs{constructor(t,e="asc"){this.field=t,this.dir=e}}function fp(n,t){return n.dir===t.dir&&n.field.isEqual(t.field)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{static fromTimestamp(t){return new q(t)}static min(){return new q(new nt(0,0))}static max(){return new q(new nt(253402300799,999999999))}constructor(t){this.timestamp=t}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pt{constructor(t,e,r,s,o,a,c){this.key=t,this.documentType=e,this.version=r,this.readTime=s,this.createTime=o,this.data=a,this.documentState=c}static newInvalidDocument(t){return new Pt(t,0,q.min(),q.min(),q.min(),qt.empty(),0)}static newFoundDocument(t,e,r,s){return new Pt(t,1,e,q.min(),r,s,0)}static newNoDocument(t,e){return new Pt(t,2,e,q.min(),q.min(),qt.empty(),0)}static newUnknownDocument(t,e){return new Pt(t,3,e,q.min(),q.min(),qt.empty(),2)}convertToFoundDocument(t,e){return!this.createTime.isEqual(q.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=t),this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=qt.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=qt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=q.min(),this}setReadTime(t){return this.readTime=t,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(t){return t instanceof Pt&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}mutableCopy(){return new Pt(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr=-1;function dp(n,t){const e=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,s=q.fromTimestamp(r===1e9?new nt(e+1,0):new nt(e,r));return new Oe(s,F.empty(),t)}function pp(n){return new Oe(n.readTime,n.key,Rr)}class Oe{constructor(t,e,r){this.readTime=t,this.documentKey=e,this.largestBatchId=r}static min(){return new Oe(q.min(),F.empty(),Rr)}static max(){return new Oe(q.max(),F.empty(),Rr)}}function mp(n,t){let e=n.readTime.compareTo(t.readTime);return e!==0?e:(e=F.comparator(n.documentKey,t.documentKey),e!==0?e:Q(n.largestBatchId,t.largestBatchId))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gp{constructor(t,e=null,r=[],s=[],o=null,a=null,c=null){this.path=t,this.collectionGroup=e,this.orderBy=r,this.filters=s,this.limit=o,this.startAt=a,this.endAt=c,this.R=null}}function xu(n,t=null,e=[],r=[],s=null,o=null,a=null){return new gp(n,t,e,r,s,o,a)}function il(n){const t=$(n);if(t.R===null){let e=t.path.canonicalString();t.collectionGroup!==null&&(e+="|cg:"+t.collectionGroup),e+="|f:",e+=t.filters.map(r=>Ki(r)).join(","),e+="|ob:",e+=t.orderBy.map(r=>function(o){return o.field.canonicalString()+o.dir}(r)).join(","),Bs(t.limit)||(e+="|l:",e+=t.limit),t.startAt&&(e+="|lb:",e+=t.startAt.inclusive?"b:":"a:",e+=t.startAt.position.map(r=>Vn(r)).join(",")),t.endAt&&(e+="|ub:",e+=t.endAt.inclusive?"a:":"b:",e+=t.endAt.position.map(r=>Vn(r)).join(",")),t.R=e}return t.R}function ol(n,t){if(n.limit!==t.limit||n.orderBy.length!==t.orderBy.length)return!1;for(let e=0;e<n.orderBy.length;e++)if(!fp(n.orderBy[e],t.orderBy[e]))return!1;if(n.filters.length!==t.filters.length)return!1;for(let e=0;e<n.filters.length;e++)if(!nl(n.filters[e],t.filters[e]))return!1;return n.collectionGroup===t.collectionGroup&&!!n.path.isEqual(t.path)&&!!Cu(n.startAt,t.startAt)&&Cu(n.endAt,t.endAt)}function Qe(n){return!!n.isCorePipeline}function al(n){return!!n.path&&F.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zs{constructor(t,e=null,r=[],s=[],o=null,a="F",c=null,h=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=r,this.filters=s,this.limit=o,this.limitType=a,this.startAt=c,this.endAt=h,this.I=null,this.A=null,this.V=null,this.startAt,this.endAt}}function _p(n,t,e,r,s,o,a,c){return new zs(n,t,e,r,s,o,a,c)}function Gs(n){return new zs(n)}function Nu(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function yp(n){return F.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Ep(n){return n.collectionGroup!==null}function ur(n){const t=$(n);if(t.I===null){t.I=[];const e=new Set;for(const o of t.explicitOrderBy)t.I.push(o),e.add(o.field.canonicalString());const r=t.explicitOrderBy.length>0?t.explicitOrderBy[t.explicitOrderBy.length-1].dir:"asc";(function(a){let c=new dt(Gt.comparator);return a.filters.forEach(h=>{h.getFlattenedFilters().forEach(f=>{f.isInequality()&&(c=c.add(f.field))})}),c})(t).forEach(o=>{e.has(o.canonicalString())||o.isKeyField()||t.I.push(new bs(o,r))}),e.has(Gt.keyField().canonicalString())||t.I.push(new bs(Gt.keyField(),r))}return t.I}function oe(n){const t=$(n);return t.A||(t.A=Tp(t,ur(n))),t.A}function Tp(n,t){if(n.limitType==="F")return xu(n.path,n.collectionGroup,t,n.filters,n.limit,n.startAt,n.endAt);{t=t.map(s=>{const o=s.dir==="desc"?"asc":"desc";return new bs(s.field,o)});const e=n.endAt?new Ps(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new Ps(n.startAt.position,n.startAt.inclusive):null;return xu(n.path,n.collectionGroup,t,n.filters,n.limit,e,r)}}function Xi(n,t,e){return new zs(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),t,e,n.startAt,n.endAt)}function wp(n,t){return ol(oe(n),oe(t))&&n.limitType===t.limitType}function cr(n){return`Query(target=${function(e){let r=e.path.canonicalString();return e.collectionGroup!==null&&(r+=" collectionGroup="+e.collectionGroup),e.filters.length>0&&(r+=`, filters: [${e.filters.map(s=>rl(s)).join(", ")}]`),Bs(e.limit)||(r+=", limit: "+e.limit),e.orderBy.length>0&&(r+=`, orderBy: [${e.orderBy.map(s=>function(a){return`${a.field.canonicalString()} (${a.dir})`}(s)).join(", ")}]`),e.startAt&&(r+=", startAt: ",r+=e.startAt.inclusive?"b:":"a:",r+=e.startAt.position.map(s=>Vn(s)).join(",")),e.endAt&&(r+=", endAt: ",r+=e.endAt.inclusive?"a:":"b:",r+=e.endAt.position.map(s=>Vn(s)).join(",")),`Target(${r})`}(oe(n))}; limitType=${n.limitType})`}function Hs(n,t){return t.isFoundDocument()&&function(r,s){const o=s.key.path;return r.collectionGroup!==null?s.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(o):F.isDocumentKey(r.path)?r.path.isEqual(o):r.path.isImmediateParentOf(o)}(n,t)&&function(r,s){for(const o of ur(r))if(!o.field.isKeyField()&&s.data.field(o.field)===null)return!1;return!0}(n,t)&&function(r,s){for(const o of r.filters)if(!o.matches(s))return!1;return!0}(n,t)&&function(r,s){return!(r.startAt&&!function(a,c,h){const f=Su(a,c,h);return a.inclusive?f<=0:f<0}(r.startAt,ur(r),s)||r.endAt&&!function(a,c,h){const f=Su(a,c,h);return a.inclusive?f>=0:f>0}(r.endAt,ur(r),s))}(n,t)}function To(n){return(t,e)=>{let r=!1;for(const s of ur(n)){const o=vp(s,t,e);if(o!==0)return o;r=r||s.field.isKeyField()}return 0}}function vp(n,t,e){const r=n.field.isKeyField()?F.comparator(t.key,e.key):function(o,a,c){const h=a.data.field(o),f=c.data.field(o);return h!==null&&f!==null?Ut(h,f):B(42886)}(n.field,t,e);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return B(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ip{constructor(t,e){this.count=t,this.unchangedNames=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ht,K;function Ap(n){switch(n){case x.OK:return B(64938);case x.CANCELLED:case x.UNKNOWN:case x.DEADLINE_EXCEEDED:case x.RESOURCE_EXHAUSTED:case x.INTERNAL:case x.UNAVAILABLE:case x.UNAUTHENTICATED:return!1;case x.INVALID_ARGUMENT:case x.NOT_FOUND:case x.ALREADY_EXISTS:case x.PERMISSION_DENIED:case x.FAILED_PRECONDITION:case x.ABORTED:case x.OUT_OF_RANGE:case x.UNIMPLEMENTED:case x.DATA_LOSS:return!0;default:return B(15467,{code:n})}}function ul(n){if(n===void 0)return ye("GRPC error has no .code"),x.UNKNOWN;switch(n){case ht.OK:return x.OK;case ht.CANCELLED:return x.CANCELLED;case ht.UNKNOWN:return x.UNKNOWN;case ht.DEADLINE_EXCEEDED:return x.DEADLINE_EXCEEDED;case ht.RESOURCE_EXHAUSTED:return x.RESOURCE_EXHAUSTED;case ht.INTERNAL:return x.INTERNAL;case ht.UNAVAILABLE:return x.UNAVAILABLE;case ht.UNAUTHENTICATED:return x.UNAUTHENTICATED;case ht.INVALID_ARGUMENT:return x.INVALID_ARGUMENT;case ht.NOT_FOUND:return x.NOT_FOUND;case ht.ALREADY_EXISTS:return x.ALREADY_EXISTS;case ht.PERMISSION_DENIED:return x.PERMISSION_DENIED;case ht.FAILED_PRECONDITION:return x.FAILED_PRECONDITION;case ht.ABORTED:return x.ABORTED;case ht.OUT_OF_RANGE:return x.OUT_OF_RANGE;case ht.UNIMPLEMENTED:return x.UNIMPLEMENTED;case ht.DATA_LOSS:return x.DATA_LOSS;default:return B(39323,{code:n})}}(K=ht||(ht={}))[K.OK=0]="OK",K[K.CANCELLED=1]="CANCELLED",K[K.UNKNOWN=2]="UNKNOWN",K[K.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",K[K.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",K[K.NOT_FOUND=5]="NOT_FOUND",K[K.ALREADY_EXISTS=6]="ALREADY_EXISTS",K[K.PERMISSION_DENIED=7]="PERMISSION_DENIED",K[K.UNAUTHENTICATED=16]="UNAUTHENTICATED",K[K.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",K[K.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",K[K.ABORTED=10]="ABORTED",K[K.OUT_OF_RANGE=11]="OUT_OF_RANGE",K[K.UNIMPLEMENTED=12]="UNIMPLEMENTED",K[K.INTERNAL=13]="INTERNAL",K[K.UNAVAILABLE=14]="UNAVAILABLE",K[K.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(t,e){this.mapKeyFn=t,this.equalsFn=e,this.inner={},this.innerSize=0}get(t){const e=this.mapKeyFn(t),r=this.inner[e];if(r!==void 0){for(const[s,o]of r)if(this.equalsFn(s,t))return o}}has(t){return this.get(t)!==void 0}set(t,e){const r=this.mapKeyFn(t),s=this.inner[r];if(s===void 0)return this.inner[r]=[[t,e]],void this.innerSize++;for(let o=0;o<s.length;o++)if(this.equalsFn(s[o][0],t))return void(s[o]=[t,e]);s.push([t,e]),this.innerSize++}delete(t){const e=this.mapKeyFn(t),r=this.inner[e];if(r===void 0)return!1;for(let s=0;s<r.length;s++)if(this.equalsFn(r[s][0],t))return r.length===1?delete this.inner[e]:r.splice(s,1),this.innerSize--,!0;return!1}forEach(t){un(this.inner,(e,r)=>{for(const[s,o]of r)t(s,o)})}isEmpty(){return Mc(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rp=new rt(F.comparator);function Ot(){return Rp}const cl=new rt(F.comparator);function yn(...n){let t=cl;for(const e of n)t=t.insert(e.key,e);return t}function ll(n){let t=cl;return n.forEach((e,r)=>t=t.insert(e,r.overlayedDocument)),t}function Ve(){return lr()}function hl(){return lr()}function lr(){return new ln(n=>n.toString(),(n,t)=>n.isEqual(t))}const Vp=new rt(F.comparator),Pp=new dt(F.comparator);function H(...n){let t=Pp;for(const e of n)t=t.add(e);return t}const bp=new dt(Q);function Sp(){return bp}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cp(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xp=new be([4294967295,4294967295],0);function Du(n){const t=Cp().encode(n),e=new Cc;return e.update(t),new Uint8Array(e.digest())}function ku(n){const t=new DataView(n.buffer),e=t.getUint32(0,!0),r=t.getUint32(4,!0),s=t.getUint32(8,!0),o=t.getUint32(12,!0);return[new be([e,r],0),new be([s,o],0)]}class wo{constructor(t,e,r){if(this.bitmap=t,this.padding=e,this.hashCount=r,e<0||e>=8)throw new rr(`Invalid padding: ${e}`);if(r<0)throw new rr(`Invalid hash count: ${r}`);if(t.length>0&&this.hashCount===0)throw new rr(`Invalid hash count: ${r}`);if(t.length===0&&e!==0)throw new rr(`Invalid padding when bitmap length is 0: ${e}`);this.m=8*t.length-e,this.p=be.fromNumber(this.m)}v(t,e,r){let s=t.add(e.multiply(be.fromNumber(r)));return s.compare(xp)===1&&(s=new be([s.getBits(0),s.getBits(1)],0)),s.modulo(this.p).toNumber()}S(t){return!!(this.bitmap[Math.floor(t/8)]&1<<t%8)}mightContain(t){if(this.m===0)return!1;const e=Du(t),[r,s]=ku(e);for(let o=0;o<this.hashCount;o++){const a=this.v(r,s,o);if(!this.S(a))return!1}return!0}static create(t,e,r){const s=t%8==0?0:8-t%8,o=new Uint8Array(Math.ceil(t/8)),a=new wo(o,s,e);return r.forEach(c=>a.insert(c)),a}insert(t){if(this.m===0)return;const e=Du(t),[r,s]=ku(e);for(let o=0;o<this.hashCount;o++){const a=this.v(r,s,o);this.D(a)}}D(t){const e=Math.floor(t/8),r=t%8;this.bitmap[e]|=1<<r}}class rr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr{constructor(t,e,r,s,o,a){this.snapshotVersion=t,this.targetChanges=e,this.targetMismatches=r,this.documentUpdates=s,this.augmentedDocumentUpdates=o,this.resolvedLimboDocuments=a}static createSynthesizedRemoteEventForCurrentChange(t,e,r){const s=new Map;return s.set(t,Ur.createSynthesizedTargetChangeForCurrentChange(t,e,r)),new Mr(q.min(),s,new rt(Q),Ot(),Ot(),H())}}class Ur{constructor(t,e,r,s,o){this.resumeToken=t,this.current=e,this.addedDocuments=r,this.modifiedDocuments=s,this.removedDocuments=o}static createSynthesizedTargetChangeForCurrentChange(t,e,r){return new Ur(r,e,H(),H(),H())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ms{constructor(t,e,r,s){this.C=t,this.removedTargetIds=e,this.key=r,this.F=s}}class fl{constructor(t,e){this.targetId=t,this.O=e}}class dl{constructor(t,e,r=pt.EMPTY_BYTE_STRING,s=null){this.state=t,this.targetIds=e,this.resumeToken=r,this.cause=s}}class Ou{constructor(t){this.targetId=t,this.M=0,this.N=Lu(),this.L=pt.EMPTY_BYTE_STRING,this.B=!1,this.U=!0}get current(){return this.B}get resumeToken(){return this.L}get k(){return this.M!==0}get q(){return this.U}$(t){t.approximateByteSize()>0&&(this.U=!0,this.L=t)}K(){let t=H(),e=H(),r=H();return this.N.forEach((s,o)=>{switch(o){case 0:t=t.add(s);break;case 2:e=e.add(s);break;case 1:r=r.add(s);break;default:B(38017,{changeType:o})}}),new Ur(this.L,this.B,t,e,r)}W(){this.U=!1,this.N=Lu()}G(t,e){this.U=!0,this.N=this.N.insert(t,e)}j(t){this.U=!0,this.N=this.N.remove(t)}H(){this.M+=1}J(){this.M-=1,U(this.M>=0,3241,{M:this.M,targetId:this.targetId})}Y(){this.U=!0,this.B=!0}}const Zn="WatchChangeAggregator";class Np{constructor(t){this.Z=t,this.X=new Map,this.ee=Ot(),this.te=as(),this.ne=Ot(),this.re=as(),this.ie=new rt(Q)}se(t){for(const e of t.C)t.F&&t.F.isFoundDocument()?this._e(e,t.F):this.oe(e,t.key,t.F);for(const e of t.removedTargetIds)this.oe(e,t.key,t.F)}ae(t){this.forEachTarget(t,e=>{const r=this.X.get(e);if(r)switch(t.state){case 0:this.ue(e)&&r.$(t.resumeToken);break;case 1:r.J(),r.k||r.W(),r.$(t.resumeToken);break;case 2:r.J(),r.k||this.removeTarget(e);break;case 3:this.ue(e)&&(r.Y(),r.$(t.resumeToken));break;case 4:this.ue(e)&&(this.ce(e),r.$(t.resumeToken));break;default:B(56790,{state:t.state})}else O(Zn,`handleTargetChange received targetChange for untracked target ID (${e}) with state (${t.state})`)})}forEachTarget(t,e){t.targetIds.length>0?t.targetIds.forEach(e):this.X.forEach((r,s)=>{this.ue(s)&&e(s)})}le(t){var e;return Qe(t)?t.getPipelineSourceType()==="documents"&&((e=t.getPipelineDocuments())==null?void 0:e.length)===1:al(t)}Ee(t){const e=t.targetId,r=t.O.count,s=this.he(e);if(s){const o=s.target;if(this.le(o))if(r===0){const a=new F(Qe(o)?Y.fromString(o.getPipelineDocuments()[0]):o.path);this.oe(e,a,Pt.newNoDocument(a,q.min()))}else U(r===1,20013,"Single document existence filter with count: "+r);else{const a=this.Te(e);if(a!==r){const c=this.Pe(t),h=c?this.Re(c,t,a):1;if(h!==0){this.ce(e);const f=h===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.ie=this.ie.insert(e,f)}}}}}Pe(t){const e=t.O.unchangedNames;if(!e||!e.bits)return null;const{bits:{bitmap:r="",padding:s=0},hashCount:o=0}=e;let a,c;try{a=De(r).toUint8Array()}catch(h){if(h instanceof Fc)return Zt("Decoding the base64 bloom filter in existence filter failed ("+h.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw h}try{c=new wo(a,s,o)}catch(h){return Zt(h instanceof rr?"BloomFilter error: ":"Applying bloom filter failed: ",h),null}return c.m===0?null:c}Re(t,e,r){return e.O.count===r-this.Ve(t,e.targetId)?0:2}Ve(t,e){const r=this.Z.getRemoteKeysForTarget(e);let s=0;return r.forEach(o=>{const a=this.Z.Ae(),c=`projects/${a.projectId}/databases/${a.database}/documents/${o.path.canonicalString()}`;t.mightContain(c)||(this.oe(e,o,null),s++)}),s}de(t){const e=new Map;this.X.forEach((o,a)=>{const c=this.he(a);if(c){if(o.current&&this.le(c.target)){const h=Qe(c.target)?Y.fromString(c.target.getPipelineDocuments()[0]):c.target.path,f=new F(h);this.fe(f).has(a)||this.me(a,f)||this.oe(a,f,Pt.newNoDocument(f,t))}o.q&&(e.set(a,o.K()),o.W())}});let r=H();this.re.forEach((o,a)=>{let c=!0;a.forEachWhile(h=>{const f=this.he(h);return!f||f.purpose==="TargetPurposeLimboResolution"||(c=!1,!1)}),c&&(r=r.add(o))}),this.ee.forEach((o,a)=>a.setReadTime(t)),this.ne.forEach((o,a)=>a.setReadTime(t));const s=new Mr(t,e,this.ie,this.ee,this.ne,r);return this.ee=Ot(),this.te=as(),this.ne=Ot(),this.re=as(),this.ie=new rt(Q),s}_e(t,e){const r=this.X.get(t);if(!r||!this.ue(t))return void O(Zn,`addDocumentToTarget received document for unknown inactive target (${t})`);const s=this.me(t,e.key)?2:0;r.G(e.key,s),Qe(this.he(t).target)&&this.he(t).target.getPipelineFlavor()!=="exact"?this.ne=this.ne.insert(e.key,e):this.ee=this.ee.insert(e.key,e),this.te=this.te.insert(e.key,this.fe(e.key).add(t)),this.re=this.re.insert(e.key,this.pe(e.key).add(t))}oe(t,e,r){const s=this.X.get(t);s&&this.ue(t)?(this.me(t,e)?s.G(e,1):s.j(e),this.re=this.re.insert(e,this.pe(e).delete(t)),this.re=this.re.insert(e,this.pe(e).add(t)),r&&(Qe(this.he(t).target)&&this.he(t).target.getPipelineFlavor()!=="exact"?this.ne=this.ne.insert(e,r):this.ee=this.ee.insert(e,r))):O(Zn,`removeDocumentFromTarget received document for unknown or inactive target (${t})`)}removeTarget(t){this.X.delete(t)}Te(t){const e=this.X.get(t);if(!e)return 0;const r=e.K();return this.Z.getRemoteKeysForTarget(t).size+r.addedDocuments.size-r.removedDocuments.size}H(t){let e=this.X.get(t);e||(O(Zn,`recordPendingTargetRequest set up tracking for target ID ${t}`),e=new Ou(t),this.X.set(t,e)),e.H()}pe(t){let e=this.re.get(t);return e||(e=new dt(Q),this.re=this.re.insert(t,e)),e}fe(t){let e=this.te.get(t);return e||(e=new dt(Q),this.te=this.te.insert(t,e)),e}ue(t){const e=this.he(t)!==null;return e||O(Zn,"Detected inactive target",t),e}he(t){const e=this.X.get(t);return e===void 0||e.k?null:this.Z.ge(t)}ce(t){this.X.set(t,new Ou(t)),this.Z.getRemoteKeysForTarget(t).forEach(e=>{this.oe(t,e,null)})}me(t,e){return this.Z.getRemoteKeysForTarget(t).has(e)}}function as(){return new rt(F.comparator)}function Lu(){return new rt(F.comparator)}const Dp={asc:"ASCENDING",desc:"DESCENDING"},kp={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Op={and:"AND",or:"OR"};class Lp{constructor(t,e){this.databaseId=t,this.useProto3Json=e}}function Ji(n,t){return n.useProto3Json||Bs(t)?t:{value:t}}function Ss(n,t){return n.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function vo(n){const t=Ne(n);return new nt(t.seconds,t.nanos)}function pl(n,t){return n.useProto3Json?t.toBase64():t.toUint8Array()}function gs(n,t){return Ss(n,t.toTimestamp())}function ae(n){return U(!!n,49232),q.fromTimestamp(vo(n))}function Io(n,t){return Yi(n,t).canonicalString()}function Yi(n,t){const e=function(s){return new Y(["projects",s.projectId,"databases",s.database])}(n).child("documents");return t===void 0?e:e.child(t)}function ml(n){const t=Y.fromString(n);return U(Tl(t),10190,{key:t.toString()}),t}function Cs(n,t){return Io(n.databaseId,t.path)}function ki(n,t){const e=ml(t);if(e.get(1)!==n.databaseId.projectId)throw new L(x.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+e.get(1)+" vs "+n.databaseId.projectId);if(e.get(3)!==n.databaseId.database)throw new L(x.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+e.get(3)+" vs "+n.databaseId.database);return new F(_l(e))}function gl(n,t){return Io(n.databaseId,t)}function Mp(n){const t=ml(n);return t.length===4?Y.emptyPath():_l(t)}function Zi(n){return new Y(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function _l(n){return U(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function Mu(n,t,e){return{name:Cs(n,t),fields:e.value.mapValue.fields}}function Up(n,t){let e;if("targetChange"in t){t.targetChange;const r=function(f){return f==="NO_CHANGE"?0:f==="ADD"?1:f==="REMOVE"?2:f==="CURRENT"?3:f==="RESET"?4:B(39313,{state:f})}(t.targetChange.targetChangeType||"NO_CHANGE"),s=t.targetChange.targetIds||[],o=function(f,p){return f.useProto3Json?(U(p===void 0||typeof p=="string",58123),pt.fromBase64String(p||"")):(U(p===void 0||p instanceof Buffer||p instanceof Uint8Array,16193),pt.fromUint8Array(p||new Uint8Array))}(n,t.targetChange.resumeToken),a=t.targetChange.cause,c=a&&function(f){const p=f.code===void 0?x.UNKNOWN:ul(f.code);return new L(p,f.message||"")}(a);e=new dl(r,s,o,c||null)}else if("documentChange"in t){t.documentChange;const r=t.documentChange;r.document,r.document.name,r.document.updateTime;const s=ki(n,r.document.name),o=ae(r.document.updateTime),a=r.document.createTime?ae(r.document.createTime):q.min(),c=new qt({mapValue:{fields:r.document.fields}}),h=Pt.newFoundDocument(s,o,a,c),f=r.targetIds||[],p=r.removedTargetIds||[];e=new ms(f,p,h.key,h)}else if("documentDelete"in t){t.documentDelete;const r=t.documentDelete;r.document;const s=ki(n,r.document),o=r.readTime?ae(r.readTime):q.min(),a=Pt.newNoDocument(s,o),c=r.removedTargetIds||[];e=new ms([],c,a.key,a)}else if("documentRemove"in t){t.documentRemove;const r=t.documentRemove;r.document;const s=ki(n,r.document),o=r.removedTargetIds||[];e=new ms([],o,s,null)}else{if(!("filter"in t))return B(11601,{ye:t});{t.filter;const r=t.filter;r.targetId;const{count:s=0,unchangedNames:o}=r,a=new Ip(s,o),c=r.targetId;e=new fl(c,a)}}return e}function Fp(n,t){let e;if(t instanceof Lr)e={update:Mu(n,t.key,t.value)};else if(t instanceof Eo)e={delete:Cs(n,t.key)};else if(t instanceof cn)e={update:Mu(n,t.key,t.data),updateMask:Kp(t.fieldMask)};else{if(!(t instanceof rp))return B(16599,{we:t.type});e={verify:Cs(n,t.key)}}return t.fieldTransforms.length>0&&(e.updateTransforms=t.fieldTransforms.map(r=>function(o,a){const c=a.transform;if(c instanceof wr)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(c instanceof vr)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:c.elements}};if(c instanceof Ir)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:c.elements}};if(c instanceof Ar)return{fieldPath:a.field.canonicalString(),increment:c.l};if(c instanceof As)return{fieldPath:a.field.canonicalString(),minimum:c.l};if(c instanceof Rs)return{fieldPath:a.field.canonicalString(),maximum:c.l};throw B(20930,{transform:a.transform})}(0,r))),t.precondition.isNone||(e.currentDocument=function(s,o){return o.updateTime!==void 0?{updateTime:gs(s,o.updateTime)}:o.exists!==void 0?{exists:o.exists}:B(27497)}(n,t.precondition)),e}function Bp(n,t){return n&&n.length>0?(U(t!==void 0,14353),n.map(e=>function(s,o){let a=s.updateTime?ae(s.updateTime):ae(o);return a.isEqual(q.min())&&(a=ae(o)),new tp(a,s.transformResults||[])}(e,t))):[]}function jp(n,t){return{documents:[gl(n,t.path)]}}function qp(n,t){const e={structuredQuery:{}},r=t.path;let s;t.collectionGroup!==null?(s=r,e.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(s=r.popLast(),e.structuredQuery.from=[{collectionId:r.lastSegment()}]),e.parent=gl(n,s);const o=function(f){if(f.length!==0)return El(ce.create(f,"and"))}(t.filters);o&&(e.structuredQuery.where=o);const a=function(f){if(f.length!==0)return f.map(p=>function(I){return{field:En(I.field),direction:Hp(I.dir)}}(p))}(t.orderBy);a&&(e.structuredQuery.orderBy=a);const c=Ji(n,t.limit);return c!==null&&(e.structuredQuery.limit=c),t.startAt&&(e.structuredQuery.startAt=function(f){return{before:f.inclusive,values:f.position}}(t.startAt)),t.endAt&&(e.structuredQuery.endAt=function(f){return{before:!f.inclusive,values:f.position}}(t.endAt)),{be:e,parent:s}}function $p(n){let t=Mp(n.parent);const e=n.structuredQuery,r=e.from?e.from.length:0;let s=null;if(r>0){U(r===1,65062);const p=e.from[0];p.allDescendants?s=p.collectionId:t=t.child(p.collectionId)}let o=[];e.where&&(o=function(m){const I=yl(m);return I instanceof ce&&el(I)?I.getFilters():[I]}(e.where));let a=[];e.orderBy&&(a=function(m){return m.map(I=>function(C){return new bs(Tn(C.field),function(k){switch(k){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(C.direction))}(I))}(e.orderBy));let c=null;e.limit&&(c=function(m){let I;return I=typeof m=="object"?m.value:m,Bs(I)?null:I}(e.limit));let h=null;e.startAt&&(h=function(m){const I=!!m.before,b=m.values||[];return new Ps(b,I)}(e.startAt));let f=null;return e.endAt&&(f=function(m){const I=!m.before,b=m.values||[];return new Ps(b,I)}(e.endAt)),_p(t,s,a,o,c,"F",h,f)}function zp(n,t){const e=function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return B(28987,{purpose:s})}}(t.purpose);return e==null?null:{"goog-listen-tags":e}}function Gp(n,t){return{structuredPipeline:{pipeline:{stages:t.stages.map(e=>e._toProto(n))}}}}function yl(n){return n.unaryFilter!==void 0?function(e){switch(e.unaryFilter.op){case"IS_NAN":const r=Tn(e.unaryFilter.field);return _t.create(r,"==",{doubleValue:NaN});case"IS_NULL":const s=Tn(e.unaryFilter.field);return _t.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const o=Tn(e.unaryFilter.field);return _t.create(o,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const a=Tn(e.unaryFilter.field);return _t.create(a,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return B(61313);default:return B(60726)}}(n):n.fieldFilter!==void 0?function(e){return _t.create(Tn(e.fieldFilter.field),function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return B(58110);default:return B(50506)}}(e.fieldFilter.op),e.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(e){return ce.create(e.compositeFilter.filters.map(r=>yl(r)),function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return B(1026)}}(e.compositeFilter.op))}(n):B(30097,{filter:n})}function Hp(n){return Dp[n]}function Wp(n){return kp[n]}function Qp(n){return Op[n]}function En(n){return{fieldPath:n.canonicalString()}}function Tn(n){return Gt.fromServerFormat(n.fieldPath)}function El(n){return n instanceof _t?function(e){if(e.op==="=="){if(Ft(e.value))return{unaryFilter:{field:En(e.field),op:"IS_NAN"}};if($t(e.value))return{unaryFilter:{field:En(e.field),op:"IS_NULL"}}}else if(e.op==="!="){if(Ft(e.value))return{unaryFilter:{field:En(e.field),op:"IS_NOT_NAN"}};if($t(e.value))return{unaryFilter:{field:En(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:En(e.field),op:Wp(e.op),value:e.value}}}(n):n instanceof ce?function(e){const r=e.getFilters().map(s=>El(s));return r.length===1?r[0]:{compositeFilter:{op:Qp(e.op),filters:r}}}(n):B(54877,{filter:n})}function Kp(n){const t=[];return n.fields.forEach(e=>t.push(e.canonicalString())),{fieldPaths:t}}function Tl(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function wl(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}function Vr(n,t){const e={fields:{}};return t.forEach((r,s)=>{if(typeof s!="string")throw new Error(`Cannot encode map with non-string key: ${s}`);e.fields[s]=r._toProto(n)}),{mapValue:e}}function vl(n){return{stringValue:n}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ws(n){return new Lp(n,!0)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wt{constructor(t){this._byteString=t}static fromBase64String(t){try{return new Wt(pt.fromBase64String(t))}catch(e){throw new L(x.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(t){return new Wt(pt.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}toJSON(){return{type:Wt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(t){if(kr(t,Wt._jsonSchema))return Wt.fromBase64String(t.bytes)}}Wt._jsonSchemaVersion="firestore/bytes/1.0",Wt._jsonSchema={type:ft("string",Wt._jsonSchemaVersion),bytes:ft("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{constructor(...t){for(let e=0;e<t.length;++e)if(t[e].length===0)throw new L(x.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Gt(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}function Xp(){return new Ao(re)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ro{constructor(t){this._methodName=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ue{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new L(x.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new L(x.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}_compareTo(t){return Q(this._lat,t._lat)||Q(this._long,t._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:ue._jsonSchemaVersion}}static fromJSON(t){if(kr(t,ue._jsonSchema))return new ue(t.latitude,t.longitude)}}ue._jsonSchemaVersion="firestore/geoPoint/1.0",ue._jsonSchema={type:ft("string",ue._jsonSchemaVersion),latitude:ft("number"),longitude:ft("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vt{constructor(t){this.uid=t}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}Vt.UNAUTHENTICATED=new Vt(null),Vt.GOOGLE_CREDENTIALS=new Vt("google-credentials-uid"),Vt.FIRST_PARTY=new Vt("first-party-uid"),Vt.MOCK_USER=new Vt("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class me{constructor(){this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Il{constructor(t,e){this.user=e,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${t}`)}}class Jp{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable(()=>e(Vt.UNAUTHENTICATED))}shutdown(){}}class Yp{constructor(t){this.token=t,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(t,e){this.changeListener=e,t.enqueueRetryable(()=>e(this.token.user))}shutdown(){this.changeListener=null}}class Zp{constructor(t){this.Se=t,this.currentUser=Vt.UNAUTHENTICATED,this.De=0,this.forceRefresh=!1,this.auth=null}start(t,e){U(this.xe===void 0,42304);let r=this.De;const s=h=>this.De!==r?(r=this.De,e(h)):Promise.resolve();let o=new me;this.xe=()=>{this.De++,this.currentUser=this.Ce(),o.resolve(),o=new me,t.enqueueRetryable(()=>s(this.currentUser))};const a=()=>{const h=o;t.enqueueRetryable(async()=>{await h.promise,await s(this.currentUser)})},c=h=>{O("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=h,this.xe&&(this.auth.addAuthTokenListener(this.xe),a())};this.Se.onInit(h=>c(h)),setTimeout(()=>{if(!this.auth){const h=this.Se.getImmediate({optional:!0});h?c(h):(O("FirebaseAuthCredentialsProvider","Auth not yet detected"),o.resolve(),o=new me)}},0),a()}getToken(){const t=this.De,e=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(e).then(r=>this.De!==t?(O("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(U(typeof r.accessToken=="string",31837,{Fe:r}),new Il(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.xe&&this.auth.removeAuthTokenListener(this.xe),this.xe=void 0}Ce(){const t=this.auth&&this.auth.getUid();return U(t===null||typeof t=="string",2055,{Oe:t}),new Vt(t)}}class tm{constructor(t,e,r){this.Me=t,this.Ne=e,this.Le=r,this.type="FirstParty",this.user=Vt.FIRST_PARTY,this.Be=new Map}Ue(){return this.Le?this.Le():null}get headers(){this.Be.set("X-Goog-AuthUser",this.Me);const t=this.Ue();return t&&this.Be.set("Authorization",t),this.Ne&&this.Be.set("X-Goog-Iam-Authorization-Token",this.Ne),this.Be}}class em{constructor(t,e,r){this.Me=t,this.Ne=e,this.Le=r}getToken(){return Promise.resolve(new tm(this.Me,this.Ne,this.Le))}start(t,e){t.enqueueRetryable(()=>e(Vt.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Uu{constructor(t){this.value=t,this.type="AppCheck",this.headers=new Map,t&&t.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class nm{constructor(t,e){this.ke=e,this.forceRefresh=!1,this.appCheck=null,this.qe=null,this.$e=null,Rc(t)&&t.settings.appCheckToken&&(this.$e=t.settings.appCheckToken)}start(t,e){U(this.xe===void 0,3512);const r=o=>{o.error!=null&&O("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${o.error.message}`);const a=o.token!==this.qe;return this.qe=o.token,O("FirebaseAppCheckTokenProvider",`Received ${a?"new":"existing"} token.`),a?e(o.token):Promise.resolve()};this.xe=o=>{t.enqueueRetryable(()=>r(o))};const s=o=>{O("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=o,this.xe&&this.appCheck.addTokenListener(this.xe)};this.ke.onInit(o=>s(o)),setTimeout(()=>{if(!this.appCheck){const o=this.ke.getImmediate({optional:!0});o?s(o):O("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.$e)return Promise.resolve(new Uu(this.$e));const t=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(t).then(e=>e?(U(typeof e.token=="string",44558,{tokenResult:e}),this.qe=e.token,new Uu(e.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.xe&&this.appCheck.removeTokenListener(this.xe),this.xe=void 0}}function Al(n){const t={};return n.timeoutSeconds!==void 0&&(t.timeoutSeconds=n.timeoutSeconds),t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rm{Ke(t){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fu="ConnectivityMonitor";class Bu{constructor(){this.We=()=>this.Qe(),this.Ge=()=>this.ze(),this.je=[],this.He()}Ke(t){this.je.push(t)}shutdown(){window.removeEventListener("online",this.We),window.removeEventListener("offline",this.Ge)}He(){window.addEventListener("online",this.We),window.addEventListener("offline",this.Ge)}Qe(){O(Fu,"Network connectivity changed: AVAILABLE");for(const t of this.je)t(0)}ze(){O(Fu,"Network connectivity changed: UNAVAILABLE");for(const t of this.je)t(1)}static Je(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let us=null;function to(){return us===null?us=function(){return 268435456+Math.round(2147483648*Math.random())}():us++,"0x"+us.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oi="RestConnection",sm={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class im{get Ye(){return!1}constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const e=t.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.Ze=e+"://"+t.host,this.Xe=`projects/${r}/databases/${s}`,this.et=this.databaseId.database===vs?`project_id=${r}`:`project_id=${r}&database_id=${s}`}tt(t,e,r,s,o){const a=to(),c=this.nt(t,e.toUriEncodedString());O(Oi,`Sending RPC '${t}' ${a}:`,c,r);const h={"google-cloud-resource-prefix":this.Xe,"x-goog-request-params":this.et};this.rt(h,s,o);const{host:f}=new URL(c),p=Us(f);return this.it(t,c,h,r,p).then(m=>(O(Oi,`Received RPC '${t}' ${a}: `,m),m),m=>{throw Zt(Oi,`RPC '${t}' ${a} failed with error: `,m,"url: ",c,"request:",r),m})}st(t,e,r,s,o,a){return this.tt(t,e,r,s,o)}rt(t,e,r){if(t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Sn}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),e&&e.headers.forEach((s,o)=>t[o]=s),r&&r.headers.forEach((s,o)=>t[o]=s),this.databaseInfo._customHeaders)for(const s of Object.keys(this.databaseInfo._customHeaders))t[s]=this.databaseInfo._customHeaders[s]}nt(t,e){const r=sm[t];let s=`${this.Ze}/v1/${e}:${r}`;return this.databaseInfo.apiKey&&(s=`${s}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),s}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class om{constructor(t){this._t=t._t,this.ot=t.ot}ut(t){this.ct=t}lt(t){this.Et=t}ht(t){this.Tt=t}onMessage(t){this.Pt=t}close(){this.ot()}send(t){this._t(t)}Rt(){this.ct()}It(){this.Et()}At(t){this.Tt(t)}Vt(t){this.Pt(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rt="WebChannelConnection",tr=(n,t,e)=>{n.listen(t,r=>{try{e(r)}catch(s){setTimeout(()=>{throw s},0)}})};class wn extends im{constructor(t){super(t),this.dt=[],this.forceLongPolling=t.forceLongPolling,this.autoDetectLongPolling=t.autoDetectLongPolling,this.useFetchStreams=t.useFetchStreams,this.longPollingOptions=t.longPollingOptions}static ft(){if(!wn.gt){const t=kc();tr(t,Dc.STAT_EVENT,e=>{e.stat===Gi.PROXY?O(Rt,"STAT_EVENT: detected buffering proxy"):e.stat===Gi.NOPROXY&&O(Rt,"STAT_EVENT: detected no buffering proxy")}),wn.gt=!0}}it(t,e,r,s,o){const a=to();return new Promise((c,h)=>{const f=new xc;f.setWithCredentials(!0),f.listenOnce(Nc.COMPLETE,()=>{try{switch(f.getLastErrorCode()){case fs.NO_ERROR:const m=f.getResponseJson();O(Rt,`XHR for RPC '${t}' ${a} received:`,JSON.stringify(m)),c(m);break;case fs.TIMEOUT:O(Rt,`RPC '${t}' ${a} timed out`),h(new L(x.DEADLINE_EXCEEDED,"Request time out"));break;case fs.HTTP_ERROR:const I=f.getStatus();if(O(Rt,`RPC '${t}' ${a} failed with status:`,I,"response text:",f.getResponseText()),I>0){let b=f.getResponseJson();Array.isArray(b)&&(b=b[0]);const C=b==null?void 0:b.error;if(C&&C.status&&C.message){const M=function(z){const W=z.toLowerCase().replace(/_/g,"-");return Object.values(x).indexOf(W)>=0?W:x.UNKNOWN}(C.status);h(new L(M,C.message))}else h(new L(x.UNKNOWN,"Server responded with status "+f.getStatus()))}else h(new L(x.UNAVAILABLE,"Connection failed."));break;default:B(9055,{yt:t,streamId:a,wt:f.getLastErrorCode(),bt:f.getLastError()})}}finally{O(Rt,`RPC '${t}' ${a} completed.`)}});const p=JSON.stringify(s);O(Rt,`RPC '${t}' ${a} sending request:`,s),f.send(e,"POST",p,r,15)})}vt(t,e,r){const s=to(),o=[this.Ze,"/","google.firestore.v1.Firestore","/",t,"/channel"],a=this.createWebChannelTransport(),c={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},h=this.longPollingOptions.timeoutSeconds;h!==void 0&&(c.longPollingTimeout=Math.round(1e3*h)),this.useFetchStreams&&(c.useFetchStreams=!0),this.rt(c.initMessageHeaders,e,r),c.encodeInitMessageHeaders=!0;const f=o.join("");O(Rt,`Creating RPC '${t}' stream ${s}: ${f}`,c);const p=a.createWebChannel(f,c);this.St(p);let m=!1,I=!1;const b=new om({_t:C=>{I?O(Rt,`Not sending because RPC '${t}' stream ${s} is closed:`,C):(m||(O(Rt,`Opening RPC '${t}' stream ${s} transport.`),p.open(),m=!0),O(Rt,`RPC '${t}' stream ${s} sending:`,C),p.send(C))},ot:()=>p.close()});return tr(p,nr.EventType.OPEN,()=>{I||(O(Rt,`RPC '${t}' stream ${s} transport opened.`),b.Rt())}),tr(p,nr.EventType.CLOSE,()=>{I||(I=!0,O(Rt,`RPC '${t}' stream ${s} transport closed`),b.At(),this.Dt(p))}),tr(p,nr.EventType.ERROR,C=>{I||(I=!0,Zt(Rt,`RPC '${t}' stream ${s} transport errored. Name:`,C.name,"Message:",C.message),b.At(new L(x.UNAVAILABLE,"The operation could not be completed")))}),tr(p,nr.EventType.MESSAGE,C=>{var M;if(!I){const k=C.data[0];U(!!k,16349);const z=k,W=(z==null?void 0:z.error)||((M=z[0])==null?void 0:M.error);if(W){O(Rt,`RPC '${t}' stream ${s} received error:`,W);const J=W.status;let Z=function(w){const g=ht[w];if(g!==void 0)return ul(g)}(J),ut=W.message;J==="NOT_FOUND"&&ut.includes("database")&&ut.includes("does not exist")&&ut.includes(this.databaseId.database)&&Zt(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),Z===void 0&&(Z=x.INTERNAL,ut="Unknown error status: "+J+" with message "+W.message),I=!0,b.At(new L(Z,ut)),p.close()}else O(Rt,`RPC '${t}' stream ${s} received:`,k),b.Vt(k)}}),wn.ft(),setTimeout(()=>{b.It()},0),b}terminate(){this.dt.forEach(t=>t.close()),this.dt=[]}St(t){this.dt.push(t)}Dt(t){this.dt=this.dt.filter(e=>e===t)}rt(t,e,r){super.rt(t,e,r),this.databaseInfo.apiKey&&(t["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Oc()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function am(n){return new wn(n)}wn.gt=!1;class Rl{constructor(t,e,r=1e3,s=1.5,o=6e4){this.xt=t,this.timerId=e,this.Ct=r,this.Ft=s,this.Ot=o,this.Mt=0,this.Nt=null,this.Lt=Date.now(),this.reset()}reset(){this.Mt=0}Bt(){this.Mt=this.Ot}Ut(t){this.cancel();const e=Math.floor(this.Mt+this.kt()),r=Math.max(0,Date.now()-this.Lt),s=Math.max(0,e-r);s>0&&O("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.Mt} ms, delay with jitter: ${e} ms, last attempt: ${r} ms ago)`),this.Nt=this.xt.enqueueAfterDelay(this.timerId,s,()=>(this.Lt=Date.now(),t())),this.Mt*=this.Ft,this.Mt<this.Ct&&(this.Mt=this.Ct),this.Mt>this.Ot&&(this.Mt=this.Ot)}qt(){this.Nt!==null&&(this.Nt.skipDelay(),this.Nt=null)}cancel(){this.Nt!==null&&(this.Nt.cancel(),this.Nt=null)}kt(){return(Math.random()-.5)*this.Mt}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ju="PersistentStream";class Vl{constructor(t,e,r,s,o,a,c,h){this.xt=t,this.$t=r,this.Kt=s,this.connection=o,this.authCredentialsProvider=a,this.appCheckCredentialsProvider=c,this.listener=h,this.state=0,this.Wt=0,this.Qt=null,this.Gt=null,this.stream=null,this.zt=0,this.jt=new Rl(t,e)}Ht(){return this.state===1||this.state===5||this.Jt()}Jt(){return this.state===2||this.state===3}start(){this.zt=0,this.state!==4?this.auth():this.Yt()}async stop(){this.Ht()&&await this.close(0)}Zt(){this.state=0,this.jt.reset()}Xt(){this.Jt()&&this.Qt===null&&(this.Qt=this.xt.enqueueAfterDelay(this.$t,6e4,()=>this.en()))}tn(t){this.nn(),this.stream.send(t)}async en(){if(this.Jt())return this.close(0)}nn(){this.Qt&&(this.Qt.cancel(),this.Qt=null)}rn(){this.Gt&&(this.Gt.cancel(),this.Gt=null)}async close(t,e){this.nn(),this.rn(),this.jt.cancel(),this.Wt++,t!==4?this.jt.reset():e&&e.code===x.RESOURCE_EXHAUSTED?(ye(e.toString()),ye("Using maximum backoff delay to prevent overloading the backend."),this.jt.Bt()):e&&e.code===x.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.sn(),this.stream.close(),this.stream=null),this.state=t,await this.listener.ht(e)}sn(){}auth(){this.state=1;const t=this._n(this.Wt),e=this.Wt;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,s])=>{this.Wt===e&&this.an(r,s)},r=>{t(()=>{const s=new L(x.UNKNOWN,"Fetching auth token failed: "+r.message);return this.un(s)})})}an(t,e){const r=this._n(this.Wt);this.stream=this.cn(t,e),this.stream.ut(()=>{r(()=>this.listener.ut())}),this.stream.lt(()=>{r(()=>(this.state=2,this.Gt=this.xt.enqueueAfterDelay(this.Kt,1e4,()=>(this.Jt()&&(this.state=3),Promise.resolve())),this.listener.lt()))}),this.stream.ht(s=>{r(()=>this.un(s))}),this.stream.onMessage(s=>{r(()=>++this.zt==1?this.En(s):this.onNext(s))})}Yt(){this.state=5,this.jt.Ut(async()=>{this.state=0,this.start()})}un(t){return O(ju,`close with error: ${t}`),this.stream=null,this.close(4,t)}_n(t){return e=>{this.xt.enqueueAndForget(()=>this.Wt===t?e():(O(ju,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class um extends Vl{constructor(t,e,r,s,o,a){super(t,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",e,r,s,a),this.serializer=o}cn(t,e){return this.connection.vt("Listen",t,e)}En(t){return this.onNext(t)}onNext(t){this.jt.reset();const e=Up(this.serializer,t),r=function(o){if(!("targetChange"in o))return q.min();const a=o.targetChange;return a.targetIds&&a.targetIds.length?q.min():a.readTime?ae(a.readTime):q.min()}(t);return this.listener.hn(e,r)}Tn(t){const e={};e.database=Zi(this.serializer),e.addTarget=function(o,a){let c;const h=a.target;if(c=Qe(h)?{pipelineQuery:Gp(o,h)}:al(h)?{documents:jp(o,h)}:{query:qp(o,h).be},c.targetId=a.targetId,a.resumeToken.approximateByteSize()>0){c.resumeToken=pl(o,a.resumeToken);const f=Ji(o,a.expectedCount);f!==null&&(c.expectedCount=f)}else if(a.snapshotVersion.compareTo(q.min())>0){c.readTime=Ss(o,a.snapshotVersion.toTimestamp());const f=Ji(o,a.expectedCount);f!==null&&(c.expectedCount=f)}return c}(this.serializer,t);const r=zp(this.serializer,t);r&&(e.labels=r),this.tn(e)}Pn(t){const e={};e.database=Zi(this.serializer),e.removeTarget=t,this.tn(e)}}class cm extends Vl{constructor(t,e,r,s,o,a){super(t,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",e,r,s,a),this.serializer=o}get Rn(){return this.zt>0}start(){this.lastStreamToken=void 0,super.start()}sn(){this.Rn&&this.In([])}cn(t,e){return this.connection.vt("Write",t,e)}En(t){return U(!!t.streamToken,31322),this.lastStreamToken=t.streamToken,U(!t.writeResults||t.writeResults.length===0,55816),this.listener.An()}onNext(t){U(!!t.streamToken,12678),this.lastStreamToken=t.streamToken,this.jt.reset();const e=Bp(t.writeResults,t.commitTime),r=ae(t.commitTime);return this.listener.Vn(r,e)}dn(){const t={};t.database=Zi(this.serializer),this.tn(t)}In(t){const e={streamToken:this.lastStreamToken,writes:t.map(r=>Fp(this.serializer,r))};this.tn(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lm{}class hm extends lm{constructor(t,e,r,s){super(),this.authCredentials=t,this.appCheckCredentials=e,this.connection=r,this.serializer=s,this.fn=!1}mn(){if(this.fn)throw new L(x.FAILED_PRECONDITION,"The client has already been terminated.")}tt(t,e,r,s){return this.mn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection.tt(t,Yi(e,r),s,o,a)).catch(o=>{throw o.name==="FirebaseError"?(o.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new L(x.UNKNOWN,o.toString())})}st(t,e,r,s,o){return this.mn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([a,c])=>this.connection.st(t,Yi(e,r),s,a,c,o)).catch(a=>{throw a.name==="FirebaseError"?(a.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new L(x.UNKNOWN,a.toString())})}terminate(){this.fn=!0,this.connection.terminate()}}function fm(n,t,e,r){return new hm(n,t,e,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dm="ComponentProvider",qu=new Map;function pm(n,t,e,r,s){return new zd(n,t,e,s.host,s.ssl,s.experimentalForceLongPolling,s.experimentalAutoDetectLongPolling,Al(s.experimentalLongPollingOptions),s.useFetchStreams,s.isUsingEmulator,r,s._customHeaders,s.grpcFlowControlWindow)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $u={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Pl=41943040;class kt{static withCacheSize(t){return new kt(t,kt.DEFAULT_COLLECTION_PERCENTILE,kt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(t,e,r){this.cacheSizeCollectionThreshold=t,this.percentileToCollect=e,this.maximumSequenceNumbersToCollect=r}}kt.DEFAULT_COLLECTION_PERCENTILE=10,kt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,kt.DEFAULT=new kt(Pl,kt.DEFAULT_COLLECTION_PERCENTILE,kt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),kt.DISABLED=new kt(-1,0,0);/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qs{constructor(t,e){this.previousValue=t,e&&(e.sequenceNumberHandler=r=>this.pn(r),this.gn=r=>e.writeSequenceNumber(r))}pn(t){return this.previousValue=Math.max(t,this.previousValue),this.previousValue}next(){const t=++this.previousValue;return this.gn&&this.gn(t),t}}Qs.yn=-1;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mm="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class gm{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(t){this.onCommittedListeners.push(t)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(t=>t())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cn(n){if(n.code!==x.FAILED_PRECONDITION||n.message!==mm)throw n;O("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class S{constructor(t){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,t(e=>{this.isDone=!0,this.result=e,this.nextCallback&&this.nextCallback(e)},e=>{this.isDone=!0,this.error=e,this.catchCallback&&this.catchCallback(e)})}catch(t){return this.next(void 0,t)}next(t,e){return this.callbackAttached&&B(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(e,this.error):this.wrapSuccess(t,this.result):new S((r,s)=>{this.nextCallback=o=>{this.wrapSuccess(t,o).next(r,s)},this.catchCallback=o=>{this.wrapFailure(e,o).next(r,s)}})}toPromise(){return new Promise((t,e)=>{this.next(t,e)})}wrapUserFunction(t){try{const e=t();return e instanceof S?e:S.resolve(e)}catch(e){return S.reject(e)}}wrapSuccess(t,e){return t?this.wrapUserFunction(()=>t(e)):S.resolve(e)}wrapFailure(t,e){return t?this.wrapUserFunction(()=>t(e)):S.reject(e)}static resolve(t){return new S((e,r)=>{e(t)})}static reject(t){return new S((e,r)=>{r(t)})}static waitFor(t){return new S((e,r)=>{let s=0,o=0,a=!1;t.forEach(c=>{++s,c.next(()=>{++o,a&&o===s&&e()},h=>r(h))}),a=!0,o===s&&e()})}static or(t){let e=S.resolve(!1);for(const r of t)e=e.next(s=>s?S.resolve(s):r());return e}static forEach(t,e){const r=[];return t.forEach((s,o)=>{r.push(e.call(this,s,o))}),this.waitFor(r)}static mapArray(t,e){return new S((r,s)=>{const o=t.length,a=new Array(o);let c=0;for(let h=0;h<o;h++){const f=h;e(t[f]).next(p=>{a[f]=p,++c,c===o&&r(a)},p=>s(p))}})}static doWhile(t,e){return new S((r,s)=>{const o=()=>{t()===!0?e().next(()=>{o()},s):r()};o()})}}function _m(n){const t=n.match(/Android ([\d.]+)/i),e=t?t[1].split(".").slice(0,2).join("."):"-1";return Number(e)}function xn(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zu="LruGarbageCollector",ym=1048576;function Gu([n,t],[e,r]){const s=Q(n,e);return s===0?Q(t,r):s}class Em{constructor(t){this.Jn=t,this.buffer=new dt(Gu),this.Yn=0}Zn(){return++this.Yn}Xn(t){const e=[t,this.Zn()];if(this.buffer.size<this.Jn)this.buffer=this.buffer.add(e);else{const r=this.buffer.last();Gu(e,r)<0&&(this.buffer=this.buffer.delete(r).add(e))}}get maxValue(){return this.buffer.last()[0]}}class Tm{constructor(t,e,r){this.garbageCollector=t,this.asyncQueue=e,this.localStore=r,this.er=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.tr(6e4)}stop(){this.er&&(this.er.cancel(),this.er=null)}get started(){return this.er!==null}tr(t){O(zu,`Garbage collection scheduled in ${t}ms`),this.er=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",t,async()=>{this.er=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(e){xn(e)?O(zu,"Ignoring IndexedDB error during garbage collection: ",e):await Cn(e)}await this.tr(3e5)})}}class wm{constructor(t,e){this.nr=t,this.params=e}calculateTargetCount(t,e){return this.nr.rr(t).next(r=>Math.floor(e/100*r))}nthSequenceNumber(t,e){if(e===0)return S.resolve(Qs.yn);const r=new Em(e);return this.nr.forEachTarget(t,s=>r.Xn(s.sequenceNumber)).next(()=>this.nr.ir(t,s=>r.Xn(s))).next(()=>r.maxValue)}removeTargets(t,e,r){return this.nr.removeTargets(t,e,r)}removeOrphanedDocuments(t,e){return this.nr.removeOrphanedDocuments(t,e)}collect(t,e){return this.params.cacheSizeCollectionThreshold===-1?(O("LruGarbageCollector","Garbage collection skipped; disabled"),S.resolve($u)):this.getCacheSize(t).next(r=>r<this.params.cacheSizeCollectionThreshold?(O("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),$u):this.sr(t,e))}getCacheSize(t){return this.nr.getCacheSize(t)}sr(t,e){let r,s,o,a,c,h,f;const p=Date.now();return this.calculateTargetCount(t,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(O("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),s=this.params.maximumSequenceNumbersToCollect):s=m,a=Date.now(),this.nthSequenceNumber(t,s))).next(m=>(r=m,c=Date.now(),this.removeTargets(t,r,e))).next(m=>(o=m,h=Date.now(),this.removeOrphanedDocuments(t,r))).next(m=>(f=Date.now(),gn()<=X.DEBUG&&O("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${a-p}ms
	Determined least recently used ${s} in `+(c-a)+`ms
	Removed ${o} targets in `+(h-c)+`ms
	Removed ${m} documents in `+(f-h)+`ms
Total Duration: ${f-p}ms`),S.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:o,documentsRemoved:m})))}}function vm(n,t){return new wm(n,t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bl="firestore.googleapis.com",Hu=!0;class Wu{constructor(t){if(t.host===void 0){if(t.ssl!==void 0)throw new L(x.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=bl,this.ssl=Hu}else this.host=t.host,this.ssl=t.ssl??Hu;if(this.isUsingEmulator=t.emulatorOptions!==void 0,this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,this.localCache=t.localCache,t._customHeaders&&(this._customHeaders={...t._customHeaders}),t.cacheSizeBytes===void 0)this.cacheSizeBytes=Pl;else{if(t.cacheSizeBytes!==-1&&t.cacheSizeBytes<ym)throw new L(x.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}if(qd("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:t.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Al(t.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new L(x.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!t.useFetchStreams,t.grpcFlowControlWindow!==void 0){if(typeof t.grpcFlowControlWindow!="number"||t.grpcFlowControlWindow<=0||t.grpcFlowControlWindow>2147483647||!Number.isInteger(t.grpcFlowControlWindow))throw new L(x.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=t.grpcFlowControlWindow}}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&function(r,s){return r.timeoutSeconds===s.timeoutSeconds}(this.experimentalLongPollingOptions,t.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams&&this.grpcFlowControlWindow===t.grpcFlowControlWindow&&function(r,s){if(r===s)return!0;if(!r||!s)return!1;const o=Object.keys(r),a=Object.keys(s);if(o.length!==a.length)return!1;for(const c of o)if(r[c]!==s[c])return!1;return!0}(this._customHeaders,t._customHeaders)}}let Ks=class{constructor(t,e,r,s){this._authCredentials=t,this._appCheckCredentials=e,this._databaseId=r,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Wu({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new L(x.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(t){if(this._settingsFrozen)throw new L(x.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Wu(t),this._emulatorOptions=t.emulatorOptions||{},t.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new Jp;switch(r.type){case"firstParty":return new em(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new L(x.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(t.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(e){const r=qu.get(e);r&&(O(dm,"Removing Datastore"),qu.delete(e),r.terminate())}(this),Promise.resolve()}};function Im(n,t,e,r={}){var f;n=Jt(n,Ks);const s=Us(t),o=n._getSettings(),a={...o,emulatorOptions:n._getEmulatorOptions()},c=`${t}:${e}`;s&&vc(`https://${c}`),o.host!==bl&&o.host!==c&&Zt("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const h={...o,host:c,ssl:s,emulatorOptions:r};if(!Ts(h,a)&&(n._setSettings(h),r.mockUserToken)){let p,m;if(typeof r.mockUserToken=="string")p=r.mockUserToken,m=Vt.MOCK_USER;else{p=Tc(r.mockUserToken,(f=n._app)==null?void 0:f.options.projectId);const I=r.mockUserToken.sub||r.mockUserToken.user_id;if(!I)throw new L(x.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new Vt(I)}n._authCredentials=new Yp(new Il(p,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fr{constructor(t,e,r){this.converter=e,this._query=r,this.type="query",this.firestore=t}withConverter(t){return new Fr(this.firestore,t,this._query)}}class ct{constructor(t,e,r){this.converter=e,this._key=r,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Se(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new ct(this.firestore,t,this._key)}toJSON(){return{type:ct._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(t,e,r){if(kr(e,ct._jsonSchema))return new ct(t,r||null,new F(Y.fromString(e.referencePath)))}}ct._jsonSchemaVersion="firestore/documentReference/1.0",ct._jsonSchema={type:ft("string",ct._jsonSchemaVersion),referencePath:ft("string")};class Se extends Fr{constructor(t,e,r){super(t,e,Gs(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new ct(this.firestore,null,new F(t))}withConverter(t){return new Se(this.firestore,t,this._path)}}function rT(n,t,...e){if(n=Yt(n),Uc("collection","path",t),n instanceof Ks){const r=Y.fromString(t,...e);return Tu(r),new Se(n,null,r)}{if(!(n instanceof ct||n instanceof Se))throw new L(x.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(Y.fromString(t,...e));return Tu(r),new Se(n.firestore,null,r)}}function sT(n,t,...e){if(n=Yt(n),arguments.length===1&&(t=fo.newId()),Uc("doc","path",t),n instanceof Ks){const r=Y.fromString(t,...e);return Eu(r),new ct(n,null,new F(r))}{if(!(n instanceof ct||n instanceof Se))throw new L(x.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(Y.fromString(t,...e));return Eu(r),new ct(n.firestore,n instanceof Se?n.converter:null,new F(r))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lt{constructor(t){this._values=(t||[]).map(e=>e)}toArray(){return this._values.map(t=>t)}isEqual(t){return function(r,s){if(r.length!==s.length)return!1;for(let o=0;o<r.length;++o)if(r[o]!==s[o])return!1;return!0}(this._values,t._values)}toJSON(){return{type:Lt._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(t){if(kr(t,Lt._jsonSchema)){if(Array.isArray(t.vectorValues)&&t.vectorValues.every(e=>typeof e=="number"))return new Lt(t.vectorValues);throw new L(x.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}Lt._jsonSchemaVersion="firestore/vectorValue/1.0",Lt._jsonSchema={type:ft("string",Lt._jsonSchemaVersion),vectorValues:ft("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Am=/^__.*__$/;class Rm{constructor(t,e,r){this.data=t,this.fieldMask=e,this.fieldTransforms=r}toMutation(t,e){return this.fieldMask!==null?new cn(t,this.data,this.fieldMask,e,this.fieldTransforms):new Lr(t,this.data,e,this.fieldTransforms)}}function Sl(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw B(40011,{dataSource:n})}}class Vo{constructor(t,e,r,s,o,a){this.settings=t,this.databaseId=e,this.serializer=r,this.ignoreUndefinedProperties=s,o===void 0&&this.validatePath(),this.fieldTransforms=o||[],this.fieldMask=a||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(t){return new Vo({...this.settings,...t},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(t){var s;const e=(s=this.path)==null?void 0:s.child(t),r=this.contextWith({path:e,arrayElement:!1});return r.validatePathSegment(t),r}childContextForFieldPath(t){var s;const e=(s=this.path)==null?void 0:s.child(t),r=this.contextWith({path:e,arrayElement:!1});return r.validatePath(),r}childContextForArray(t){return this.contextWith({path:void 0,arrayElement:!0})}createError(t){return xs(t,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(t){return this.fieldMask.find(e=>t.isPrefixOf(e))!==void 0||this.fieldTransforms.find(e=>t.isPrefixOf(e.field))!==void 0}validatePath(){if(this.path)for(let t=0;t<this.path.length;t++)this.validatePathSegment(this.path.get(t))}validatePathSegment(t){if(t.length===0)throw this.createError("Document fields must not be empty");if(Sl(this.dataSource)&&Am.test(t))throw this.createError('Document fields cannot begin and end with "__"')}}class Vm{constructor(t,e,r){this.databaseId=t,this.ignoreUndefinedProperties=e,this.serializer=r||Ws(t)}createContext(t,e,r,s=!1){return new Vo({dataSource:t,methodName:e,targetDoc:r,path:Gt.emptyPath(),arrayElement:!1,hasConverter:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Pm(n){const t=n._freezeSettings(),e=Ws(n._databaseId);return new Vm(n._databaseId,!!t.ignoreUndefinedProperties,e)}function bm(n,t,e,r,s,o={}){const a=n.createContext(o.merge||o.mergeFields?2:0,t,e,s);Nl("Data must be an object, but it was:",a,r);const c=Cl(r,a);let h,f;if(o.merge)h=new Kt(a.fieldMask),f=a.fieldTransforms;else if(o.mergeFields){const p=[];for(const m of o.mergeFields){const I=Xs(t,m,e);if(!a.contains(I))throw new L(x.INVALID_ARGUMENT,`Field '${I}' is specified in your field mask but missing from your input data.`);xm(p,I)||p.push(I)}h=new Kt(p),f=a.fieldTransforms.filter(m=>h.covers(m.field))}else h=null,f=a.fieldTransforms;return new Rm(new qt(c),h,f)}class Po extends Ro{_toFieldTransform(t){return new Yd(t.path,new wr)}isEqual(t){return t instanceof Po}}function Pr(n,t,e){if(xl(n=Yt(n)))return Nl("Unsupported field value:",t,n),Cl(n,t);if(n instanceof Ro)return function(s,o){if(!Sl(o.dataSource))throw o.createError(`${s._methodName}() can only be used with update() and set()`);if(!o.path)throw o.createError(`${s._methodName}() is not currently supported inside arrays`);const a=s._toFieldTransform(o);a&&o.fieldTransforms.push(a)}(n,t),null;if(n===void 0&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),n instanceof Array){if(t.settings.arrayElement&&t.dataSource!==4)throw t.createError("Nested arrays are not supported");return function(s,o){const a=[];let c=0;for(const h of s){let f=Pr(h,o.childContextForArray(c));f==null&&(f={nullValue:"NULL_VALUE"}),a.push(f),c++}return{arrayValue:{values:a}}}(n,t)}return function(s,o,a){if((s=Yt(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return _o(o.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const c=nt.fromDate(s);return{timestampValue:Ss(o.serializer,c)}}if(s instanceof nt){const c=new nt(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:Ss(o.serializer,c)}}if(s instanceof ue)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof Wt)return{bytesValue:pl(o.serializer,s._byteString)};if(s instanceof ct){const c=o.databaseId,h=s.firestore._databaseId;if(!h.isEqual(c))throw o.createError(`Document reference is for database ${h.projectId}/${h.database} but should be for database ${c.projectId}/${c.database}`);return{referenceValue:Io(s.firestore._databaseId||o.databaseId,s._key.path)}}if(s instanceof Lt)return function(h,f){const p=h instanceof Lt?h.toArray():h;return{mapValue:{fields:{[zc]:{stringValue:Gc},[Er]:{arrayValue:{values:p.map(I=>{if(typeof I!="number")throw f.createError("VectorValues must only contain numeric values.");return js(f.serializer,I)})}}}}}}(s,o);if(wl(s))return s._toProto(o.serializer);throw o.createError(`Unsupported field value: ${po(s)}`)}(n,t)}function Cl(n,t){const e={};return Mc(n)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):un(n,(r,s)=>{const o=Pr(s,t.childContextForField(r));o!=null&&(e[r]=o)}),{mapValue:{fields:e}}}function xl(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof nt||n instanceof ue||n instanceof Wt||n instanceof ct||n instanceof Ro||n instanceof Lt||wl(n))}function Nl(n,t,e){if(!xl(e)||!Dr(e)){const r=po(e);throw r==="an object"?t.createError(n+" a custom object"):t.createError(n+" "+r)}}function Xs(n,t,e){if((t=Yt(t))instanceof Ao)return t._internalPath;if(typeof t=="string")return Cm(n,t);throw xs("Field path arguments must be of type string or ",n,!1,void 0,e)}const Sm=new RegExp("[~\\*/\\[\\]]");function Cm(n,t,e){if(t.search(Sm)>=0)throw xs(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,e);try{return new Ao(...t.split("."))._internalPath}catch{throw xs(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,e)}}function xs(n,t,e,r,s){const o=r&&!r.isEmpty(),a=s!==void 0;let c=`Function ${t}() called with invalid data`;e&&(c+=" (via `toFirestore()`)"),c+=". ";let h="";return(o||a)&&(h+=" (found",o&&(h+=` in field ${r}`),a&&(h+=` in document ${s}`),h+=")"),new L(x.INVALID_ARGUMENT,c+n+h)}function xm(n,t){return n.some(e=>e.isEqual(t))}function Dl(n){return typeof n._readUserData=="function"}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bt{constructor(t){this.optionDefinitions=t}_getKnownOptions(t,e){const r=qt.empty();for(const s in this.optionDefinitions)if(this.optionDefinitions.hasOwnProperty(s)){const o=this.optionDefinitions[s];if(s in t){const a=t[s];let c;o.nestedOptions&&Dr(a)?c={mapValue:{fields:new bt(o.nestedOptions).getOptionsProto(e,a)}}:a&&(c=Pr(a,e)??void 0),c&&r.set(Gt.fromServerFormat(o.serverName),c)}}return r}getOptionsProto(t,e,r){const s=this._getKnownOptions(e,t);if(r){const o=new Map(jd(r,(a,c)=>[Gt.fromServerFormat(c),a!==void 0?Pr(a,t):null]));s.setAll(o)}return s.value.mapValue.fields??{}}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nm(n){return typeof n=="object"&&n!==null&&!!("nullValue"in n&&(n.nullValue===null||n.nullValue==="NULL_VALUE")||"booleanValue"in n&&(n.booleanValue===null||typeof n.booleanValue=="boolean")||"integerValue"in n&&(n.integerValue===null||typeof n.integerValue=="number"||typeof n.integerValue=="string")||"doubleValue"in n&&(n.doubleValue===null||typeof n.doubleValue=="number")||"timestampValue"in n&&(n.timestampValue===null||function(e){return typeof e=="object"&&e!==null&&"seconds"in e&&(e.seconds===null||typeof e.seconds=="number"||typeof e.seconds=="string")&&"nanos"in e&&(e.nanos===null||typeof e.nanos=="number")}(n.timestampValue))||"stringValue"in n&&(n.stringValue===null||typeof n.stringValue=="string")||"bytesValue"in n&&(n.bytesValue===null||n.bytesValue instanceof Uint8Array)||"referenceValue"in n&&(n.referenceValue===null||typeof n.referenceValue=="string")||"geoPointValue"in n&&(n.geoPointValue===null||function(e){return typeof e=="object"&&e!==null&&"latitude"in e&&(e.latitude===null||typeof e.latitude=="number")&&"longitude"in e&&(e.longitude===null||typeof e.longitude=="number")}(n.geoPointValue))||"arrayValue"in n&&(n.arrayValue===null||function(e){return typeof e=="object"&&e!==null&&!(!("values"in e)||e.values!==null&&!Array.isArray(e.values))}(n.arrayValue))||"mapValue"in n&&(n.mapValue===null||function(e){return typeof e=="object"&&e!==null&&!(!("fields"in e)||e.fields!==null&&!Dr(e.fields))}(n.mapValue))||"fieldReferenceValue"in n&&(n.fieldReferenceValue===null||typeof n.fieldReferenceValue=="string")||"functionValue"in n&&(n.functionValue===null||function(e){return typeof e=="object"&&e!==null&&!(!("name"in e)||e.name!==null&&typeof e.name!="string"||!("args"in e)||e.args!==null&&!Array.isArray(e.args))}(n.functionValue))||"pipelineValue"in n&&(n.pipelineValue===null||function(e){return typeof e=="object"&&e!==null&&!(!("stages"in e)||e.stages!==null&&!Array.isArray(e.stages))}(n.pipelineValue)))}function iT(){return new Po("serverTimestamp")}function Dm(n){return new Lt(n)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function N(n){let t;return n instanceof hn?n:(t=Dr(n)?Um(n):n instanceof Array?Fm(n):kl(n,void 0),t)}function Li(n){if(n instanceof hn)return n;if(n instanceof Lt)return br(n);if(Array.isArray(n))return br(Dm(n));throw new Error("Unsupported value: "+typeof n)}function bo(n){return Wd(n)?_s(n):N(n)}class hn{constructor(){this._protoValueType="ProtoValue"}add(t){return new P("add",[this,N(t)],"add")}asBoolean(){if(this instanceof Le)return this;if(this instanceof Dn)return new Ll(this);if(this instanceof Nn)return new Mm(this);if(this instanceof P)return new Ol(this);throw new L("invalid-argument",`Conversion of type ${typeof this} to BooleanExpression not supported.`)}subtract(t){return new P("subtract",[this,N(t)],"subtract")}multiply(t){return new P("multiply",[this,N(t)],"multiply")}divide(t){return new P("divide",[this,N(t)],"divide")}mod(t){return new P("mod",[this,N(t)],"mod")}equal(t){return new P("equal",[this,N(t)],"equal").asBoolean()}notEqual(t){return new P("not_equal",[this,N(t)],"notEqual").asBoolean()}lessThan(t){return new P("less_than",[this,N(t)],"lessThan").asBoolean()}lessThanOrEqual(t){return new P("less_than_or_equal",[this,N(t)],"lessThanOrEqual").asBoolean()}greaterThan(t){return new P("greater_than",[this,N(t)],"greaterThan").asBoolean()}greaterThanOrEqual(t){return new P("greater_than_or_equal",[this,N(t)],"greaterThanOrEqual").asBoolean()}arrayConcat(t,...e){const r=[t,...e].map(s=>N(s));return new P("array_concat",[this,...r],"arrayConcat")}arrayContains(t){return new P("array_contains",[this,N(t)],"arrayContains").asBoolean()}arrayContainsAll(t){const e=Array.isArray(t)?new sr(t.map(N),"arrayContainsAll"):t;return new P("array_contains_all",[this,e],"arrayContainsAll").asBoolean()}arrayContainsAny(t){const e=Array.isArray(t)?new sr(t.map(N),"arrayContainsAny"):t;return new P("array_contains_any",[this,e],"arrayContainsAny").asBoolean()}arrayReverse(){return new P("array_reverse",[this])}arrayLength(){return new P("array_length",[this],"arrayLength")}equalAny(t){const e=Array.isArray(t)?new sr(t.map(N),"equalAny"):t;return new P("equal_any",[this,e],"equalAny").asBoolean()}notEqualAny(t){const e=Array.isArray(t)?new sr(t.map(N),"notEqualAny"):t;return new P("not_equal_any",[this,e],"notEqualAny").asBoolean()}exists(){return new P("exists",[this],"exists").asBoolean()}charLength(){return new P("char_length",[this],"charLength")}like(t){return new P("like",[this,N(t)],"like").asBoolean()}regexContains(t){return new P("regex_contains",[this,N(t)],"regexContains").asBoolean()}regexFind(t){return new P("regex_find",[this,N(t)],"regexFind")}regexFindAll(t){return new P("regex_find_all",[this,N(t)],"regexFindAll")}regexMatch(t){return new P("regex_match",[this,N(t)],"regexMatch").asBoolean()}stringContains(t){return new P("string_contains",[this,N(t)],"stringContains").asBoolean()}startsWith(t){return new P("starts_with",[this,N(t)],"startsWith").asBoolean()}endsWith(t){return new P("ends_with",[this,N(t)],"endsWith").asBoolean()}toLower(){return new P("to_lower",[this],"toLower")}toUpper(){return new P("to_upper",[this],"toUpper")}trim(t){const e=[this];return t&&e.push(N(t)),new P("trim",e,"trim")}ltrim(t){const e=[this];return t&&e.push(N(t)),new P("ltrim",e,"ltrim")}rtrim(t){const e=[this];return t&&e.push(N(t)),new P("rtrim",e,"rtrim")}type(){return new P("type",[this])}isType(t){return new P("is_type",[this,br(t)],"isType").asBoolean()}stringConcat(t,...e){const r=[t,...e].map(N);return new P("string_concat",[this,...r],"stringConcat")}stringIndexOf(t){return new P("string_index_of",[this,N(t)],"stringIndexOf")}stringRepeat(t){return new P("string_repeat",[this,N(t)],"stringRepeat")}stringReplaceAll(t,e){return new P("string_replace_all",[this,N(t),N(e)],"stringReplaceAll")}stringReplaceOne(t,e){return new P("string_replace_one",[this,N(t),N(e)],"stringReplaceOne")}concat(t,...e){const r=[t,...e].map(N);return new P("concat",[this,...r],"concat")}reverse(){return new P("reverse",[this],"reverse")}arrayFilter(t,e){return new P("array_filter",[this,N(t),e],"arrayFilter")}arrayTransform(t,e){return new P("array_transform",[this,N(t),e],"arrayTransform")}arrayTransformWithIndex(t,e,r){return new P("array_transform",[this,N(t),N(e),r],"arrayTransformWithIndex")}arraySlice(t,e){const r=[this,N(t)];return e!==void 0&&r.push(N(e)),new P("array_slice",r,"arraySlice")}arrayFirst(){return new P("array_first",[this],"arrayFirst")}arrayFirstN(t){return new P("array_first_n",[this,N(t)],"arrayFirstN")}arrayLast(){return new P("array_last",[this],"arrayLast")}arrayLastN(t){return new P("array_last_n",[this,N(t)],"arrayLastN")}arrayMaximum(){return new P("maximum",[this],"arrayMaximum")}arrayMaximumN(t){return new P("maximum_n",[this,N(t)],"arrayMaximumN")}arrayMinimum(){return new P("minimum",[this],"arrayMinimum")}arrayMinimumN(t){return new P("minimum_n",[this,N(t)],"arrayMinimumN")}arrayIndexOf(t){return new P("array_index_of",[this,N(t),N("first")],"arrayIndexOf")}arrayLastIndexOf(t){return new P("array_index_of",[this,N(t),N("last")],"arrayLastIndexOf")}arrayIndexOfAll(t){return new P("array_index_of_all",[this,N(t)],"arrayIndexOfAll")}byteLength(){return new P("byte_length",[this],"byteLength")}ceil(){return new P("ceil",[this])}floor(){return new P("floor",[this])}abs(){return new P("abs",[this])}exp(){return new P("exp",[this])}mapGet(t){return new P("map_get",[this,br(t)],"mapGet")}mapSet(t,e,...r){const s=[this,N(t),N(e),...r.map(N)];return new P("map_set",s,"mapSet")}mapKeys(){return new P("map_keys",[this],"mapKeys")}mapValues(){return new P("map_values",[this],"mapValues")}mapEntries(){return new P("map_entries",[this],"mapEntries")}getField(t){return new P("get_field",[this,N(t)],"get_field")}count(){return jt._create("count",[this],"count")}sum(){return jt._create("sum",[this],"sum")}average(){return jt._create("average",[this],"average")}minimum(){return jt._create("minimum",[this],"minimum")}maximum(){return jt._create("maximum",[this],"maximum")}first(){return jt._create("first",[this],"first")}last(){return jt._create("last",[this],"last")}arrayAgg(){return jt._create("array_agg",[this],"arrayAgg")}arrayAggDistinct(){return jt._create("array_agg_distinct",[this],"arrayAggDistinct")}countDistinct(){return jt._create("count_distinct",[this],"countDistinct")}logicalMaximum(t,...e){const r=[t,...e];return new P("maximum",[this,...r.map(N)],"logicalMaximum")}logicalMinimum(t,...e){const r=[t,...e];return new P("minimum",[this,...r.map(N)],"minimum")}vectorLength(){return new P("vector_length",[this],"vectorLength")}cosineDistance(t){return new P("cosine_distance",[this,Li(t)],"cosineDistance")}dotProduct(t){return new P("dot_product",[this,Li(t)],"dotProduct")}euclideanDistance(t){return new P("euclidean_distance",[this,Li(t)],"euclideanDistance")}unixMicrosToTimestamp(){return new P("unix_micros_to_timestamp",[this],"unixMicrosToTimestamp")}timestampToUnixMicros(){return new P("timestamp_to_unix_micros",[this],"timestampToUnixMicros")}unixMillisToTimestamp(){return new P("unix_millis_to_timestamp",[this],"unixMillisToTimestamp")}timestampToUnixMillis(){return new P("timestamp_to_unix_millis",[this],"timestampToUnixMillis")}unixSecondsToTimestamp(){return new P("unix_seconds_to_timestamp",[this],"unixSecondsToTimestamp")}timestampToUnixSeconds(){return new P("timestamp_to_unix_seconds",[this],"timestampToUnixSeconds")}timestampAdd(t,e){return new P("timestamp_add",[this,N(t),N(e)],"timestampAdd")}timestampSubtract(t,e){return new P("timestamp_subtract",[this,N(t),N(e)],"timestampSubtract")}timestampDiff(t,e){return new P("timestamp_diff",[this,bo(t),N(e)],"timestampDiff")}timestampExtract(t,e){const r=[this,N(t)];return e&&r.push(N(e)),new P("timestamp_extract",r,"timestampExtract")}documentId(){return new P("document_id",[this],"documentId")}parent(){return new P("parent",[this],"parent")}substring(t,e){const r=N(t);return new P("substring",e===void 0?[this,r]:[this,r,N(e)],"substring")}arrayGet(t){return new P("array_get",[this,N(t)],"arrayGet")}isError(){return new P("is_error",[this],"isError").asBoolean()}ifError(t){const e=new P("if_error",[this,N(t)],"ifError");return t instanceof Le?e.asBoolean():e}isAbsent(){return new P("is_absent",[this],"isAbsent").asBoolean()}mapRemove(t){return new P("map_remove",[this,N(t)],"mapRemove")}mapMerge(t,...e){const r=N(t),s=e.map(N);return new P("map_merge",[this,r,...s],"mapMerge")}pow(t){return new P("pow",[this,N(t)])}trunc(t){return t===void 0?new P("trunc",[this]):new P("trunc",[this,N(t)],"trunc")}round(t){return t===void 0?new P("round",[this]):new P("round",[this,N(t)],"round")}collectionId(){return new P("collection_id",[this])}length(){return new P("length",[this])}ln(){return new P("ln",[this])}sqrt(){return new P("sqrt",[this])}stringReverse(){return new P("string_reverse",[this])}ifAbsent(t){return new P("if_absent",[this,N(t)],"ifAbsent")}ifNull(t){return new P("if_null",[this,N(t)],"ifNull")}coalesce(t,...e){return new P("coalesce",[this,N(t),...e.map(N)],"coalesce")}join(t){return new P("join",[this,N(t)],"join")}log10(){return new P("log10",[this])}arraySum(){return new P("sum",[this])}split(t){return new P("split",[this,N(t)])}timestampTruncate(t,e){const r=[this,N(t)];return e&&r.push(N(e)),new P("timestamp_trunc",r)}ascending(){return Bm(this)}descending(){return jm(this)}as(t){return new Om(this,t,"as")}}class jt{constructor(t,e){this.name=t,this.params=e,this.exprType="AggregateFunction",this._protoValueType="ProtoValue"}static _create(t,e,r){const s=new jt(t,e);return s._methodName=r,s}as(t){return new km(this,t,"as")}_toProto(t){return{functionValue:{name:this.name,args:this.params.map(e=>e._toProto(t))}}}_readUserData(t){t=this._methodName?t.contextWith({methodName:this._methodName}):t,this.params.forEach(e=>e._readUserData(t))}}class km{constructor(t,e,r){this.aggregate=t,this.alias=e,this._methodName=r}_readUserData(t){this.aggregate._readUserData(t)}}class Om{constructor(t,e,r){this.expr=t,this.alias=e,this._methodName=r,this.exprType="AliasedExpression",this.selectable=!0}_readUserData(t){this.expr._readUserData(t)}}class sr extends hn{constructor(t,e){super(),this.ur=t,this._methodName=e,this.expressionType="ListOfExpressions"}_toProto(t){return{arrayValue:{values:this.ur.map(e=>e._toProto(t))}}}_readUserData(t){this.ur.forEach(e=>e._readUserData(t))}}class Nn extends hn{constructor(t,e){super(),this.fieldPath=t,this._methodName=e,this.expressionType="Field",this.selectable=!0}get _fieldPath(){return this.fieldPath}get fieldName(){return this.fieldPath.canonicalString()}get alias(){return this.fieldName}get expr(){return this}geoDistance(t){return new P("geo_distance",[this,N(t)],"geoDistance")}_toProto(t){return{fieldReferenceValue:this.fieldPath.canonicalString()}}_readUserData(t){}}function _s(n){return Lm(n,"field")}function Lm(n,t){return new Nn(typeof n=="string"?re===n?Xp()._internalPath:Xs("field",n):n._internalPath,t)}class Dn extends hn{constructor(t,e){super(),this.value=t,this._methodName=e,this.expressionType="Constant"}static _fromProto(t){const e=new Dn(t,void 0);return e._protoValue=t,e}_toProto(t){return U(this._protoValue!==void 0,237),this._protoValue}_getValue(){return this._protoValue}_readUserData(t){t=this._methodName?t.contextWith({methodName:this._methodName}):t,Nm(this._protoValue)||(this._protoValue=Pr(this.value,t))}}function br(n,t){return kl(n,"constant")}function kl(n,t){const e=new Dn(n,t);return typeof n=="boolean"?new Ll(e):e}class P extends hn{constructor(t,e,r,s){super(),this.name=t,this.params=e,this.expressionType="Function",this._optionsProto=void 0,r!==void 0&&(this._methodName=r),s!==void 0&&(this._options=s)}get _optionsUtil(){return new bt({})}_toProto(t){const e={functionValue:{name:this.name,args:this.params.map(r=>r._toProto(t))}};return this._optionsProto&&(e.functionValue.options=this._optionsProto),e}_readUserData(t){t=this._methodName?t.contextWith({methodName:this._methodName}):t,this.params.forEach(e=>e._readUserData(t)),this._options&&(this._optionsProto=this._optionsUtil.getOptionsProto(t,this._options))}}class Le extends hn{get _methodName(){return this._expr._methodName}countIf(){return jt._create("count_if",[this],"countIf")}not(){return new P("not",[this],"not").asBoolean()}conditional(t,e){return new P("conditional",[this,t,e],"conditional")}ifError(t){const e=N(t),r=new P("if_error",[this,e],"ifError");return e instanceof Le?r.asBoolean():r}_toProto(t){return this._expr._toProto(t)}_readUserData(t){this._expr._readUserData(t)}}class Ol extends Le{constructor(t){super(),this._expr=t,this.expressionType="Function"}}class Ll extends Le{constructor(t){super(),this._expr=t,this.expressionType="Constant"}_getValue(){return this._expr._getValue()}}class Mm extends Le{constructor(t){super(),this._expr=t,this.expressionType="Field"}}function Um(n,t){const e=[];for(const r in n)if(Object.prototype.hasOwnProperty.call(n,r)){const s=n[r];e.push(br(r)),e.push(N(s))}return new P("map",e,"map")}function Fm(n){return function(e,r){return new P("array",e.map(s=>N(s)),r)}(n,"array")}function Bm(n){return new Ml(bo(n),"ascending","ascending")}function jm(n){return new Ml(bo(n),"descending","descending")}class Ml{constructor(t,e,r){this.expr=t,this.direction=e,this._methodName=r,this._protoValueType="ProtoValue"}_toProto(t){return{mapValue:{fields:{direction:vl(this.direction),expression:this.expr._toProto(t)}}}}_readUserData(t){this.expr._readUserData(t)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ht{constructor(t){this.optionsProto=void 0,{rawOptions:this.rawOptions,...this.knownOptions}=t}_readUserData(t){this.optionsProto=this._optionsUtil.getOptionsProto(t,this.knownOptions,this.rawOptions)}_toProto(t){return{name:this._name,options:this.optionsProto}}}class Ul extends Ht{get _name(){return"add_fields"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.fields=t}_toProto(t){return{...super._toProto(t),args:[Vr(t,this.fields)]}}_readUserData(t){super._readUserData(t),Me(this.fields,t)}}class Fl extends Ht{get _name(){return"aggregate"}get _optionsUtil(){return new bt({})}constructor(t,e,r){super(r),this.groups=t,this.accumulators=e}_toProto(t){return{...super._toProto(t),args:[Vr(t,this.accumulators),Vr(t,this.groups)]}}_readUserData(t){super._readUserData(t),Me(this.groups,t),Me(this.accumulators,t)}}class Bl extends Ht{get _name(){return"distinct"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.groups=t}_toProto(t){return{...super._toProto(t),args:[Vr(t,this.groups)]}}_readUserData(t){super._readUserData(t),Me(this.groups,t)}}class Js extends Ht{get _name(){return"collection"}get _optionsUtil(){return new bt({forceIndex:{serverName:"force_index"}})}constructor(t,e){super(e),this.Er=t.startsWith("/")?t:"/"+t}_toProto(t){return{...super._toProto(t),args:[{referenceValue:this.Er}]}}_readUserData(t){super._readUserData(t)}}class Ys extends Ht{get _name(){return"collection_group"}get _optionsUtil(){return new bt({forceIndex:{serverName:"force_index"}})}constructor(t,e){super(e),this.collectionId=t}_toProto(t){return{...super._toProto(t),args:[{referenceValue:""},{stringValue:this.collectionId}]}}_readUserData(t){super._readUserData(t)}}class So extends Ht{get _name(){return"database"}get _optionsUtil(){return new bt({})}_toProto(t){return{...super._toProto(t)}}_readUserData(t){super._readUserData(t)}}class Co extends Ht{get _name(){return"documents"}get _optionsUtil(){return new bt({})}constructor(t,e){if(super(e),!t||t.length===0)throw new L(x.INVALID_ARGUMENT,"Empty document paths are not allowed in DocumentsSource");const r=t.map(o=>o.startsWith("/")?o:"/"+o),s=new Set(r);if(s.size!==r.length)throw new L(x.INVALID_ARGUMENT,"Duplicate document paths are not allowed in DocumentsSource");this.hr=r,this.Tr=s}_toProto(t){return{...super._toProto(t),args:this.hr.map(e=>({referenceValue:e}))}}_readUserData(t){super._readUserData(t)}}class Zs extends Ht{get _name(){return"where"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.condition=t}_toProto(t){return{...super._toProto(t),args:[this.condition._toProto(t)]}}_readUserData(t){super._readUserData(t),Me(this.condition,t)}}class rn extends Ht{get _name(){return"limit"}get _optionsUtil(){return new bt({})}constructor(t,e){U(!isNaN(t)&&t!==1/0&&t!==-1/0,34860),super(e),this.limit=t}_toProto(t){return{...super._toProto(t),args:[_o(t,this.limit)]}}}class Qu extends Ht{get _name(){return"offset"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.offset=t}_toProto(t){return{...super._toProto(t),args:[_o(t,this.offset)]}}}class qm extends Ht{get _name(){return"select"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.selections=t}_toProto(t){return{...super._toProto(t),args:[Vr(t,this.selections)]}}_readUserData(t){super._readUserData(t),Me(this.selections,t)}}class de extends Ht{get _name(){return"sort"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.orderings=t}_toProto(t){return{...super._toProto(t),args:this.orderings.map(e=>e._toProto(t))}}_readUserData(t){super._readUserData(t),Me(this.orderings,t)}}class xo extends Ht{get _name(){return"replace_with"}get _optionsUtil(){return new bt({})}constructor(t,e){super(e),this.map=t}_toProto(t){return{...super._toProto(t),args:[this.map._toProto(t),vl(xo.Pr)]}}_readUserData(t){super._readUserData(t),Me(this.map,t)}}xo.Pr="full_replace";function Me(n,t){return Dl(n)?n._readUserData(t):Array.isArray(n)?n.forEach(e=>e._readUserData(t)):n instanceof Map?n.forEach(e=>e._readUserData(t)):Object.values(n).forEach(e=>e._readUserData(t)),n}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hr{constructor(t,e,r,s){this._db=t,this.userDataReader=e,this._userDataWriter=r,this.stages=s}Ar(t,e){const r=this.userDataReader.createContext(3,t);return Dl(e)?e._readUserData(r):Array.isArray(e)?e.forEach(s=>s._readUserData(r)):e.forEach(s=>s._readUserData(r)),e}where(t){const e=this.stages.map(r=>r);return this.Ar("where",t),e.push(new Zs(t,{})),new hr(this._db,this.userDataReader,this._userDataWriter,e)}limit(t){const e=this.stages.map(r=>r);return e.push(new rn(t,{})),new hr(this._db,this.userDataReader,this._userDataWriter,e)}sort(t,...e){const r=this.stages.map(s=>s);return"orderings"in t?r.push(new de(this.Ar("sort",t.orderings),{})):r.push(new de(this.Ar("sort",[t,...e]),{})),new hr(this._db,this.userDataReader,this._userDataWriter,r)}Vr(t){return{pipeline:{stages:this.stages.map(e=>e._toProto(t))}}}}// Copyright 2024 Google LLC* @license
class E{constructor(t,e){this.type=t,this.value=e}static dr(){return new E("ERROR",void 0)}static mr(){return new E("UNSET",void 0)}static pr(){return new E("NULL",Rn)}static newValue(t){return $t(t)?new E("NULL",Rn):function(r){return!!r&&"booleanValue"in r}(t)?new E("BOOLEAN",t):se(t)?new E("INT",t):Ke(t)?new E("DOUBLE",t):function(r){return!!r&&"timestampValue"in r&&!!r.timestampValue}(t)?new E("TIMESTAMP",t):function(r){return!!r&&"stringValue"in r}(t)?new E("STRING",t):function(r){return!!r&&"bytesValue"in r}(t)?new E("BYTES",t):t.referenceValue?new E("REFERENCE",t):t.geoPointValue?new E("GEO_POINT",t):Pn(t)?new E("ARRAY",t):Is(t)?new E("VECTOR",t):Je(t)?new E("MAP",t):new E("ERROR",void 0)}gr(){return this.type==="ERROR"||this.type==="UNSET"}yr(){return this.type==="NULL"}}function fr(n){if(!n.gr())return n.value}function jl(n){return n instanceof Le?n._expr:n}function j(n){if((n=jl(n))instanceof Nn)return new $m(n);if(n instanceof Dn)return new zm(n);if(n instanceof sr)return new Gm(n);if(n instanceof P){if(n.name==="add")return new Qm(n);if(n.name==="subtract")return new Km(n);if(n.name==="multiply")return new Xm(n);if(n.name==="divide")return new Jm(n);if(n.name==="mod")return new Ym(n);if(n.name==="and")return new Zm(n);if(n.name==="equal")return new hg(n);if(n.name==="not_equal")return new fg(n);if(n.name==="less_than")return new dg(n);if(n.name==="less_than_or_equal")return new pg(n);if(n.name==="greater_than")return new mg(n);if(n.name==="greater_than_or_equal")return new gg(n);if(n.name==="array_concat")return new _g(n);if(n.name==="array_reverse")return new yg(n);if(n.name==="array_contains")return new Eg(n);if(n.name==="array_contains_all")return new Tg(n);if(n.name==="array_contains_any")return new wg(n);if(n.name==="array_length")return new vg(n);if(n.name==="array_element")return new Ig(n);if(n.name==="equal_any")return new ql(n);if(n.name==="not_equal_any")return new eg(n);if(n.name==="is_nan")return new ng(n);if(n.name==="is_not_nan")return new rg(n);if(n.name==="is_null")return new sg(n);if(n.name==="is_not_null")return new ig(n);if(n.name==="is_error")return new og(n);if(n.name==="exists")return new ag(n);if(n.name==="not")return new ti(n);if(n.name==="or")return new tg(n);if(n.name==="xor")return new No(n);if(n.name==="conditional")return new ug(n);if(n.name==="maximum")return new cg(n);if(n.name==="minimum")return new lg(n);if(n.name==="reverse")return new Ag(n);if(n.name==="replace_first")return new Rg(n);if(n.name==="replace_all")return new Vg(n);if(n.name==="char_length")return new Pg(n);if(n.name==="byte_length")return new bg(n);if(n.name==="like")return new Sg(n);if(n.name==="regex_contains")return new Cg(n);if(n.name==="regex_match")return new xg(n);if(n.name==="string_contains")return new Ng(n);if(n.name==="starts_with")return new Dg(n);if(n.name==="ends_with")return new kg(n);if(n.name==="to_lower")return new Og(n);if(n.name==="to_upper")return new Lg(n);if(n.name==="trim")return new Mg(n);if(n.name==="string_concat")return new Ug(n);if(n.name==="map_get")return new Fg(n);if(n.name==="cosine_distance")return new Bg(n);if(n.name==="dot_product")return new jg(n);if(n.name==="euclidean_distance")return new qg(n);if(n.name==="vector_length")return new $g(n);if(n.name==="unix_micros_to_timestamp")return new Qg(n);if(n.name==="timestamp_to_unix_micros")return new Jg(n);if(n.name==="unix_millis_to_timestamp")return new Kg(n);if(n.name==="timestamp_to_unix_millis")return new Yg(n);if(n.name==="unix_seconds_to_timestamp")return new Xg(n);if(n.name==="timestamp_to_unix_seconds")return new Zg(n);if(n.name==="timestamp_add")return new t_(n);if(n.name==="timestamp_subtract")return new e_(n)}throw new Error(`Unknown Expr : ${n}`)}class $m{constructor(t){this.expr=t}evaluate(t,e){if(this.expr.fieldName===re)return E.newValue({referenceValue:Cs(t.serializer,e.key)});if(this.expr.fieldName==="__update_time__")return E.newValue({timestampValue:gs(t.serializer,e.version)});if(this.expr.fieldName==="__create_time__")return E.newValue({timestampValue:gs(t.serializer,e.createTime)});const r=e.data.field(this.expr._fieldPath);return r?Fs(r)?E.newValue(function(o,a){if(o.serverTimestampBehavior==="estimate")return{timestampValue:gs(o.serializer,q.fromTimestamp(An(a)))};if(o.serverTimestampBehavior==="previous"){const c=Or(a);if(c)return c}return{nullValue:"NULL_VALUE"}}(t,r)):E.newValue(r):E.mr()}}class zm{constructor(t){this.expr=t}evaluate(t,e){return E.newValue(this.expr._getValue())}}class Gm{constructor(t){this.expr=t}evaluate(t,e){const r=this.expr.ur.map(s=>j(s).evaluate(t,e));return r.some(s=>s.gr())?E.dr():E.newValue({arrayValue:{values:r.map(s=>s.value)}})}}function It(n){return Ke(n)?Number(n.doubleValue):Number(n.integerValue)}function le(n){return BigInt(n.integerValue)}const Hm=BigInt("0x7fffffffffffffff"),Wm=-BigInt("0x8000000000000000");class Br{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length>=2,24778);const r=j(this.expr.params[0]).evaluate(t,e),s=j(this.expr.params[1]).evaluate(t,e);let o=this.wr(r,s);for(const a of this.expr.params.slice(2)){const c=j(a).evaluate(t,e);o=this.wr(o,c)}return o}wr(t,e){if(t.gr()||e.gr())return E.dr();if(t.yr()||e.yr())return E.pr();const r=t.value,s=e.value;if(!Ke(r)&&!se(r)||!Ke(s)&&!se(s))return E.dr();if(Ke(r)||Ke(s)){const o=this.br(r,s);return o?E.newValue(o):E.dr()}if(se(r)&&se(s)){const o=this.vr(r,s);return o===void 0?E.dr():typeof o=="number"?E.newValue({doubleValue:o}):o<Wm||o>Hm?E.dr():E.newValue({integerValue:`${o}`})}return E.dr()}}function Ee(n,t){return mt(n)!==mt(t)?"TYPE_MISMATCH":Ft(n)||Ft(t)?"NOT_EQ":$t(n)&&$t(t)?"EQ":$t(n)||$t(t)?"NULL":Pn(n)&&Pn(t)?function(r,s){var a,c,h;if(((a=r.values)==null?void 0:a.length)!==((c=s.values)==null?void 0:c.length))return"NOT_EQ";let o=!1;for(let f=0;f<(((h=r.values)==null?void 0:h.length)??0);f++){const p=r.values[f],m=s.values[f];switch(Ee(p,m)){case"EQ":break;case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":o=!0;break;default:B(44609,{Sr:p,Dr:m})}}return o?"NULL":"EQ"}(n.arrayValue,t.arrayValue):Is(n)&&Is(t)||Je(n)&&Je(t)?function(r,s){const o=r.fields||{},a=s.fields||{};if(ws(o)!==ws(a))return"NOT_EQ";let c=!1;for(const h in o)if(o.hasOwnProperty(h)){if(a[h]===void 0)return"NOT_EQ";switch(Ee(o[h],a[h])){case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":c=!0}}return c?"NULL":"EQ"}(n.mapValue,t.mapValue):function(r,s){return Qt(r,s,{o:!1,t:!0,i:!0})}(n,t)?"EQ":"NOT_EQ"}class Qm extends Br{vr(t,e){return le(t)+le(e)}br(t,e){return{doubleValue:It(t)+It(e)}}}class Km extends Br{constructor(t){super(t),this.expr=t}vr(t,e){return le(t)-le(e)}br(t,e){return{doubleValue:It(t)-It(e)}}}class Xm extends Br{constructor(t){super(t),this.expr=t}vr(t,e){return le(t)*le(e)}br(t,e){return{doubleValue:It(t)*It(e)}}}class Jm extends Br{constructor(t){super(t),this.expr=t}vr(t,e){const r=le(e);if(r!==BigInt(0))return le(t)/r}br(t,e){const r=It(e);return r===0?{doubleValue:yr(r)?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY}:{doubleValue:It(t)/r}}}class Ym extends Br{constructor(t){super(t),this.expr=t}vr(t,e){const r=le(e);if(r!==BigInt(0))return le(t)%r}br(t,e){const r=It(e);if(r!==0)return{doubleValue:It(t)%r}}}class Zm{constructor(t){this.expr=t}evaluate(t,e){var o;let r=!1,s=!1;for(const a of this.expr.params){const c=j(a).evaluate(t,e);switch(c.type){case"BOOLEAN":if(!((o=c.value)!=null&&o.booleanValue))return E.newValue(wt);break;case"NULL":s=!0;break;default:r=!0}}return r?E.dr():s?E.pr():E.newValue(Mt)}}class ti{constructor(t){this.expr=t}evaluate(t,e){var s;U(this.expr.params.length===1,9634);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"BOOLEAN":return E.newValue({booleanValue:!((s=r.value)!=null&&s.booleanValue)});case"NULL":return E.pr();default:return E.dr()}}}class tg{constructor(t){this.expr=t}evaluate(t,e){var o;let r=!1,s=!1;for(const a of this.expr.params){const c=j(a).evaluate(t,e);switch(c.type){case"BOOLEAN":if((o=c.value)!=null&&o.booleanValue)return E.newValue(Mt);break;case"NULL":s=!0;break;default:r=!0}}return r?E.dr():s?E.pr():E.newValue(wt)}}class No{constructor(t){this.expr=t}evaluate(t,e){var o;let r=!1,s=!1;for(const a of this.expr.params){const c=j(a).evaluate(t,e);switch(c.type){case"BOOLEAN":r=No.xor(r,!!((o=c.value)!=null&&o.booleanValue));break;case"NULL":s=!0;break;default:return E.dr()}}return s?E.pr():E.newValue({booleanValue:r})}static xor(t,e){return(t||e)&&!(t&&e)}}class ql{constructor(t){this.expr=t}evaluate(t,e){var a,c;U(this.expr.params.length===2,55094);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"NULL":r=!0;break;case"ERROR":case"UNSET":return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);switch(o.type){case"ARRAY":break;case"NULL":r=!0;break;default:return E.dr()}if(r)return E.pr();for(const h of((c=(a=o.value)==null?void 0:a.arrayValue)==null?void 0:c.values)??[])switch($t(s.value)&&$t(h)?"EQ":Ee(s.value,h)){case"EQ":return E.newValue(Mt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":r=!0;break;default:B(44608,{value:s.value,candidate:h})}return r?E.pr():E.newValue(wt)}}class eg{constructor(t){this.expr=t}evaluate(t,e){return new ti(new P("not",[new P("equal_any",this.expr.params)])).evaluate(t,e)}}class ng{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===1,23322);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"INT":return E.newValue(wt);case"DOUBLE":return E.newValue({booleanValue:isNaN(It(r.value))});case"NULL":return E.pr();default:return E.dr()}}}class rg{constructor(t){this.expr=t}evaluate(t,e){return U(this.expr.params.length===1,50406),new ti(new P("not",[new P("is_nan",this.expr.params)])).evaluate(t,e)}}class sg{constructor(t){this.expr=t}evaluate(t,e){switch(U(this.expr.params.length===1,23123),j(this.expr.params[0]).evaluate(t,e).type){case"NULL":return E.newValue(Mt);case"UNSET":case"ERROR":return E.dr();default:return E.newValue(wt)}}}class ig{constructor(t){this.expr=t}evaluate(t,e){return U(this.expr.params.length===1,23167),new ti(new P("not",[new P("is_null",this.expr.params)])).evaluate(t,e)}}class og{constructor(t){this.expr=t}evaluate(t,e){return U(this.expr.params.length===1,5228),j(this.expr.params[0]).evaluate(t,e).type==="ERROR"?E.newValue(Mt):E.newValue(wt)}}class ag{constructor(t){this.expr=t}evaluate(t,e){switch(U(this.expr.params.length===1,6877),j(this.expr.params[0]).evaluate(t,e).type){case"ERROR":return E.dr();case"UNSET":return E.newValue(wt);default:return E.newValue(Mt)}}}class ug{constructor(t){this.expr=t}evaluate(t,e){var s;U(this.expr.params.length===3,11706);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"BOOLEAN":return(s=r.value)!=null&&s.booleanValue?j(this.expr.params[1]).evaluate(t,e):j(this.expr.params[2]).evaluate(t,e);case"NULL":return j(this.expr.params[2]).evaluate(t,e);default:return E.dr()}}}class cg{constructor(t){this.expr=t}evaluate(t,e){const r=this.expr.params.map(o=>j(o).evaluate(t,e));let s;for(const o of r)switch(o.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||Ut(o.value,s.value)>0?o:s}return s===void 0?E.pr():s}}class lg{constructor(t){this.expr=t}evaluate(t,e){const r=this.expr.params.map(o=>j(o).evaluate(t,e));let s;for(const o of r)switch(o.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||Ut(o.value,s.value)<0?o:s}return s===void 0?E.pr():s}}class kn{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===2,31033,`${this.expr.name}() function should have exactly 2 params`);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"ERROR":case"UNSET":return E.dr()}const s=j(this.expr.params[1]).evaluate(t,e);switch(s.type){case"ERROR":case"UNSET":return E.dr()}return this.Cr(r,s)}}class hg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){if(t.yr()&&e.yr())return E.newValue(Mt);if(t.yr()||e.yr()||Ft(t.value)||Ft(e.value)||mt(t.value)!==mt(e.value))return E.newValue(wt);switch(Ee(t.value,e.value)){case"EQ":return E.newValue(Mt);case"NOT_EQ":return E.newValue(wt);case"NULL":return E.pr();default:B(44615,{left:t,right:e})}}}class fg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){switch(Ee(t.value,e.value)){case"EQ":return E.newValue(wt);case"NOT_EQ":case"TYPE_MISMATCH":return E.newValue(Mt);case"NULL":return E.pr();default:B(44614,{left:t,right:e})}}}class dg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){return mt(t.value)!==mt(e.value)||Ft(t.value)||Ft(e.value)?E.newValue(wt):E.newValue({booleanValue:Ut(t.value,e.value)<0})}}class pg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){return mt(t.value)!==mt(e.value)||Ft(t.value)||Ft(e.value)?E.newValue(wt):Ee(t.value,e.value)==="EQ"?E.newValue(Mt):E.newValue({booleanValue:Ut(t.value,e.value)<0})}}class mg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){return mt(t.value)!==mt(e.value)||Ft(t.value)||Ft(e.value)?E.newValue(wt):E.newValue({booleanValue:Ut(t.value,e.value)>0})}}class gg extends kn{constructor(t){super(t),this.expr=t}Cr(t,e){return mt(t.value)!==mt(e.value)||Ft(t.value)||Ft(e.value)?E.newValue(wt):Ee(t.value,e.value)==="EQ"?E.newValue(Mt):E.newValue({booleanValue:Ut(t.value,e.value)>0})}}class _g{constructor(t){this.expr=t}evaluate(t,e){throw new Error("Unimplemented")}}class yg{constructor(t){this.expr=t}evaluate(t,e){var s;U(this.expr.params.length===1,216);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"NULL":return E.pr();case"ARRAY":{const o=((s=r.value.arrayValue)==null?void 0:s.values)??[];return E.newValue({arrayValue:{values:[...o].reverse()}})}default:return E.dr()}}}class Eg{constructor(t){this.expr=t}evaluate(t,e){return U(this.expr.params.length===2,52884),new ql(new P("eq_any",[this.expr.params[1],this.expr.params[0]])).evaluate(t,e)}}class Tg{constructor(t){this.expr=t}evaluate(t,e){var h,f,p,m;U(this.expr.params.length===2,1392);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"ARRAY":break;case"NULL":r=!0;break;default:return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);switch(o.type){case"ARRAY":break;case"NULL":r=!0;break;default:return E.dr()}if(r)return E.pr();const a=((f=(h=o.value)==null?void 0:h.arrayValue)==null?void 0:f.values)??[],c=((m=(p=s.value)==null?void 0:p.arrayValue)==null?void 0:m.values)??[];for(const I of a){let b=!1;r=!1;for(const C of c){switch($t(I)&&$t(C)?"EQ":Ee(I,C)){case"EQ":b=!0;break;case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":r=!0;break;default:B(44613,{value:C,search:I})}if(b)break}if(!b)return E.newValue(wt)}return E.newValue(Mt)}}class wg{constructor(t){this.expr=t}evaluate(t,e){var h,f,p,m;U(this.expr.params.length===2,2680);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"ARRAY":break;case"NULL":r=!0;break;default:return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);switch(o.type){case"ARRAY":break;case"NULL":r=!0;break;default:return E.dr()}if(r)return E.pr();const a=((f=(h=o.value)==null?void 0:h.arrayValue)==null?void 0:f.values)??[],c=((m=(p=s.value)==null?void 0:p.arrayValue)==null?void 0:m.values)??[];for(const I of c)for(const b of a)switch($t(I)&&$t(b)?"EQ":Ee(I,b)){case"EQ":return E.newValue(Mt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":r=!0;break;default:B(60403,{value:I,search:b})}return r?E.pr():E.newValue(wt)}}class vg{constructor(t){this.expr=t}evaluate(t,e){var s,o,a;U(this.expr.params.length===1,38605);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"NULL":return E.pr();case"ARRAY":return E.newValue({integerValue:`${((a=(o=(s=r.value)==null?void 0:s.arrayValue)==null?void 0:o.values)==null?void 0:a.length)??0}`});default:return E.dr()}}}class Ig{constructor(t){this.expr=t}evaluate(t,e){throw new Error("Unimplemented")}}class Ag{constructor(t){this.expr=t}evaluate(t,e){var s,o;U(this.expr.params.length===1,1508);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"NULL":return E.pr();case"BYTES":{const a=(s=r.value)==null?void 0:s.bytesValue;if(typeof a=="string"){const c=pt.fromBase64String(a).toUint8Array();return c.reverse(),E.newValue({bytesValue:pt.fromUint8Array(c).toBase64()})}return E.newValue({bytesValue:new Uint8Array(a).reverse()})}case"STRING":{const a=(o=r.value)==null?void 0:o.stringValue,c=new Intl.__PRIVATE_Segmenter(void 0,{granularity:"grapheme"}).segment(a),h=Array.from(c,f=>f.segment).reverse();return E.newValue({stringValue:h.join("")})}default:return E.dr()}}}class Rg{constructor(t){this.expr=t}evaluate(t,e){throw new Error("Unimplemented")}}class Vg{constructor(t){this.expr=t}evaluate(t,e){throw new Error("Unimplemented")}}class Pg{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===1,19400);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"NULL":return E.pr();case"STRING":{const s=function(a){let c=0;for(let h=0;h<a.length;h++){const f=a.codePointAt(h);if(f===void 0)return;if(f<=65535)if(f>=55296&&f<=57343)if(f<=56319){const p=a.codePointAt(h+1);p!==void 0&&p>=56320&&p<=57343?(c+=1,h++):c+=1}else c+=1;else c+=1;else{if(!(f<=1114111))return;c+=1,h++}}return c}(r.value.stringValue);return s===void 0?E.dr():E.newValue({integerValue:s})}default:return E.dr()}}}class bg{constructor(t){this.expr=t}evaluate(t,e){var s,o;U(this.expr.params.length===1,8486);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"BYTES":{const a=(s=r.value)==null?void 0:s.bytesValue;return typeof a=="string"?E.newValue({integerValue:pt.fromBase64String(a).toUint8Array().length}):E.newValue({integerValue:new Uint8Array(a).length})}case"STRING":{const a=function(h){let f=0;for(let p=0;p<h.length;p++){const m=h.codePointAt(p);if(m===void 0)return;if(m>=55296&&m<=57343){if(!(m<=56319))return;{const I=h.codePointAt(p+1);if(I===void 0||!(I>=56320&&I<=57343))return;f+=4,p++}}else if(m<=127)f+=1;else if(m<=2047)f+=2;else if(m<=65535)f+=3;else{if(!(m<=1114111))return;f+=4,p++}}return f}((o=r.value)==null?void 0:o.stringValue);return a===void 0?E.dr():E.newValue({integerValue:a})}case"NULL":return E.pr();default:return E.dr()}}}class On{constructor(t){this.expr=t}evaluate(t,e){var a,c;U(this.expr.params.length===2,39773,`${this.expr.name}() function should have exactly two parameters`);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"STRING":break;case"NULL":r=!0;break;default:return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);switch(o.type){case"STRING":break;case"NULL":r=!0;break;default:return E.dr()}return r?E.pr():this.Fr((a=s.value)==null?void 0:a.stringValue,(c=o.value)==null?void 0:c.stringValue)}}class Sg extends On{Fr(t,e){try{const r=function(a){let c="";for(let h=0;h<a.length;h++){const f=a.charAt(h);switch(f){case"_":c+=".";break;case"%":c+=".*";break;case"\\":case".":case"*":case"?":case"+":case"^":case"$":case"|":case"(":case")":case"[":case"]":case"{":case"}":c+="\\"+f;break;default:c+=f}}return"^"+c+"$"}(e),s=co.compile(r);return E.newValue({booleanValue:s.matches(t)})}catch(r){return Zt(`Invalid LIKE pattern converted to regex: ${e}, returning error. Error: ${r}`),E.dr()}}}class Cg extends On{Fr(t,e){try{const r=co.compile(e);return E.newValue({booleanValue:r.test(t)})}catch{return Zt(`Invalid regex pattern found in regex_contains: ${e}, returning error`),E.dr()}}}class xg extends On{Fr(t,e){try{return E.newValue({booleanValue:co.compile(e).matches(t)})}catch{return Zt(`Invalid regex pattern found in regex_match: ${e}, returning error`),E.dr()}}}class Ng extends On{Fr(t,e){return E.newValue({booleanValue:t.includes(e)})}}class Dg extends On{Fr(t,e){return E.newValue({booleanValue:t.startsWith(e)})}}class kg extends On{Fr(t,e){return E.newValue({booleanValue:t.endsWith(e)})}}class Og{constructor(t){this.expr=t}evaluate(t,e){var s,o;U(this.expr.params.length===1,29079);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"STRING":return E.newValue({stringValue:(o=(s=r.value)==null?void 0:s.stringValue)==null?void 0:o.toLowerCase()});case"NULL":return E.pr();default:return E.dr()}}}class Lg{constructor(t){this.expr=t}evaluate(t,e){var s,o;U(this.expr.params.length===1,60487);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"STRING":return E.newValue({stringValue:(o=(s=r.value)==null?void 0:s.stringValue)==null?void 0:o.toUpperCase()});case"NULL":return E.pr();default:return E.dr()}}}class Mg{constructor(t){this.expr=t}evaluate(t,e){var s,o;U(this.expr.params.length===1,28544);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"STRING":return E.newValue({stringValue:(o=(s=r.value)==null?void 0:s.stringValue)==null?void 0:o.trim()});case"NULL":return E.pr();default:return E.dr()}}}class Ug{constructor(t){this.expr=t}evaluate(t,e){const r=this.expr.params.map(a=>j(a).evaluate(t,e));let s="",o=!1;for(const a of r)switch(a.type){case"STRING":s+=a.value.stringValue;break;case"NULL":o=!0;break;default:return E.dr()}return o?E.pr():E.newValue({stringValue:s})}}class Fg{constructor(t){this.expr=t}evaluate(t,e){var a,c,h,f;U(this.expr.params.length===2,4483);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"UNSET":return E.mr();case"MAP":break;default:return E.dr()}const s=j(this.expr.params[1]).evaluate(t,e);if(s.type!=="STRING")return E.dr();const o=(f=(c=(a=r.value)==null?void 0:a.mapValue)==null?void 0:c.fields)==null?void 0:f[(h=s.value)==null?void 0:h.stringValue];return o===void 0?E.mr():E.newValue(o)}}class Do{constructor(t){this.expr=t}evaluate(t,e){var f,p;U(this.expr.params.length===2,25231,`${this.expr.name}() function should have exactly 2 params`);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"VECTOR":break;case"NULL":r=!0;break;default:return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);switch(o.type){case"VECTOR":break;case"NULL":r=!0;break;default:return E.dr()}if(r)return E.pr();const a=Qi(s.value),c=Qi(o.value);if(a===void 0||c===void 0||((f=a.values)==null?void 0:f.length)!==((p=c.values)==null?void 0:p.length))return E.dr();const h=this.Or(a,c);return h===void 0||isNaN(h)?E.dr():E.newValue({doubleValue:h})}}class Bg extends Do{Or(t,e){const r=(t==null?void 0:t.values)??[],s=(e==null?void 0:e.values)??[];if(r.length===0)return;let o=0,a=0,c=0;for(let f=0;f<r.length;f++){if(!ke(r[f])||!ke(s[f]))return;const p=It(r[f]),m=It(s[f]);o+=p*m,a+=p*p,c+=m*m}const h=Math.sqrt(a)*Math.sqrt(c);if(h!==0)return 1-Math.max(-1,Math.min(1,o/h))}}class jg extends Do{Or(t,e){const r=(t==null?void 0:t.values)??[],s=(e==null?void 0:e.values)??[];if(r.length===0)return 0;let o=0;for(let a=0;a<r.length;a++){if(!ke(r[a])||!ke(s[a]))return;o+=It(r[a])*It(s[a])}return o}}class qg extends Do{Or(t,e){const r=(t==null?void 0:t.values)??[],s=(e==null?void 0:e.values)??[];if(r.length===0)return 0;let o=0;for(let a=0;a<r.length;a++){if(!ke(r[a])||!ke(s[a]))return;const c=It(r[a]),h=It(s[a]);o+=Math.pow(c-h,2)}return Math.sqrt(o)}}class $g{constructor(t){this.expr=t}evaluate(t,e){var s;U(this.expr.params.length===1,39044);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"VECTOR":{const o=Qi(r.value);return E.newValue({integerValue:((s=o==null?void 0:o.values)==null?void 0:s.length)??0})}case"NULL":return E.pr();default:return E.dr()}}}const Sr=BigInt(-62135596800),Cr=BigInt(253402300799),Ns=BigInt(1e3),Ce=BigInt(1e6),zg=Sr*Ns,Gg=Cr*Ns+BigInt(999),Hg=Sr*Ce,Wg=Cr*Ce+BigInt(999999);function ko(n){return n>=Hg&&n<=Wg}function $l(n){return n>=Sr&&n<=Cr}function xr(n,t){const e=BigInt(n);return!(e<Sr||e>Cr)&&!(t<0||t>=1e9)&&(e!==Sr||t===0)&&!(e===Cr&&t>999999999)}function zl(n,t){return t<0?{seconds:n-1,nanos:t+1e9}:{seconds:n,nanos:t}}function Oo(n){return BigInt(n.seconds)*Ce+BigInt(Math.trunc(n.nanoseconds/1e3))}class Lo{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===1,49262,`${this.expr.name}() function should have exactly one parameter`);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"INT":return this.toTimestamp(BigInt(r.value.integerValue));case"NULL":return E.pr();default:return E.dr()}}}class Qg extends Lo{toTimestamp(t){if(!ko(t))return E.dr();let e=Number(t/Ce),r=Number(t%Ce*BigInt(1e3));const s=zl(e,r);return e=s.seconds,r=s.nanos,xr(e,r)?E.newValue({timestampValue:{seconds:e,nanos:r}}):E.dr()}}class Kg extends Lo{toTimestamp(t){if(!function(a){return a>=zg&&a<=Gg}(t))return E.dr();let e=Number(t/Ns),r=Number(t%Ns*BigInt(1e6));const s=zl(e,r);return e=s.seconds,r=s.nanos,xr(e,r)?E.newValue({timestampValue:{seconds:e,nanos:r}}):E.dr()}}class Xg extends Lo{toTimestamp(t){if(!$l(t))return E.dr();const e=Number(t);return E.newValue({timestampValue:{seconds:e,nanos:0}})}}class Mo{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===1,1265,`${this.expr.name}() function should have exactly one parameter`);const r=j(this.expr.params[0]).evaluate(t,e);switch(r.type){case"TIMESTAMP":break;case"NULL":return E.pr();default:return E.dr()}const s=vo(r.value.timestampValue);return xr(s.seconds,s.nanoseconds)?this.Mr(s):E.dr()}}class Jg extends Mo{Mr(t){const e=Oo(t);return ko(e)?E.newValue({integerValue:`${e.toString()}`}):E.dr()}}class Yg extends Mo{Mr(t){const e=Oo(t),r=e/BigInt(1e3),s=e%BigInt(1e3);return r>BigInt(0)||s===BigInt(0)?E.newValue({integerValue:r.toString()}):E.newValue({integerValue:(r-BigInt(1)).toString()})}}class Zg extends Mo{Mr(t){const e=BigInt(t.seconds);return $l(e)?E.newValue({integerValue:e.toString()}):E.dr()}}class Gl{constructor(t){this.expr=t}evaluate(t,e){U(this.expr.params.length===3,2775,`${this.expr.name}() function should have exactly 3 parameters`);let r=!1;const s=j(this.expr.params[0]).evaluate(t,e);switch(s.type){case"TIMESTAMP":break;case"NULL":r=!0;break;default:return E.dr()}const o=j(this.expr.params[1]).evaluate(t,e);let a;switch(o.type){case"STRING":if(a=function(W){switch(W){case"microsecond":return"microsecond";case"millisecond":return"millisecond";case"second":return"second";case"minute":return"minute";case"hour":return"hour";case"day":return"day";default:return}}(o.value.stringValue),a===void 0)return E.dr();break;case"NULL":r=!0;break;default:return E.dr()}const c=j(this.expr.params[2]).evaluate(t,e);switch(c.type){case"INT":break;case"NULL":r=!0;break;default:return E.dr()}if(r)return E.pr();const h=BigInt(c.value.integerValue);let f;try{switch(a){case"microsecond":f=h;break;case"millisecond":f=h*BigInt(1e3);break;case"second":f=h*BigInt(1e6);break;case"minute":f=h*BigInt(6e7);break;case"hour":f=h*BigInt(36e8);break;case"day":f=h*BigInt(864e8);break;default:return E.dr()}if(a!=="microsecond"&&h!==BigInt(0)&&f/h!==BigInt(this.Nr(a)))return E.dr()}catch(z){return Zt(`Error during timestamp arithmetic: ${z}`),E.dr()}const p=vo(s.value.timestampValue);if(!xr(p.seconds,p.nanoseconds))return E.dr();const m=Oo(p),I=this.Lr(m,f);if(!ko(I))return E.dr();const b=Number(I/Ce),C=I%Ce,M=Number((C<0?C+Ce:C)*BigInt(1e3)),k=C<0?b-1:b;return xr(k,M)?E.newValue({timestampValue:{seconds:k,nanos:M}}):E.dr()}Nr(t){switch(t){case"millisecond":return 1e3;case"second":return 1e6;case"minute":return 6e7;case"hour":return 36e8;case"day":return 864e8;default:return 1}}}class t_ extends Gl{Lr(t,e){return t+e}}class e_ extends Gl{Lr(t,e){return t-e}}// Copyright 2024 Google LLC* @license
class Nt{constructor(t,e,r){this.serializer=t,this.stages=e,this.listenOptions=r,this.isCorePipeline=!0}getPipelineCollection(){return ei(this)}getPipelineCollectionGroup(){return Uo(this)}getPipelineCollectionId(){return n_(this)}getPipelineDocuments(){return eo(this)}getPipelineFlavor(){return function(e){let r="exact";return e.stages.forEach((s,o)=>{s._name!==Bl.name&&s._name!==Fl.name||(r="keyless"),s._name===qm.name&&r==="exact"&&(r="augmented"),s._name===Ul.name&&o<e.stages.length-1&&r==="exact"&&(r="augmented")}),r}(this)}getPipelineSourceType(){return xe(this)}}function xe(n){const t=n.stages[0];return t instanceof Js||t instanceof Ys||t instanceof So||t instanceof Co?t._name:"unknown"}function ei(n){if(xe(n)==="collection")return n.stages[0].Er}function Uo(n){if(xe(n)==="collection_group")return n.stages[0].collectionId}function n_(n){switch(xe(n)){case"collection":return Y.fromString(ei(n)).lastSegment();case"collection_group":return Uo(n);default:return}}function eo(n){if(xe(n)==="documents")return n.stages[0].hr}function Nr(n){if((n=jl(n))instanceof Nn)return`fld(${n.fieldName})`;if(n instanceof Dn)return`cst(${function(e){return e===null?"null":typeof e=="number"?e.toString():typeof e=="string"?`"${e}"`:e instanceof ct?`ref(${e.path})`:e instanceof Lt?`vec(${JSON.stringify(e)})`:JSON.stringify(e)}(n.value)})`;if(n instanceof P)return`fn(${n.name},[${n.params.map(Nr).join(",")}])`;if(n.expressionType==="ListOfExpressions")return`list([${n.ur.map(Nr).join(",")}])`;throw new Error(`Unrecognized expr ${JSON.stringify(n,null,2)}`)}function r_(n){if(n instanceof Ul)return`${n._name}(${cs(n.fields)})`;if(n instanceof Fl){let t=`${n._name}(${cs(n.accumulators)})`;return n.groups.size>0&&(t+=`grouping(${cs(n.groups)})`),t}if(n instanceof Bl)return`${n._name}(${cs(n.groups)})`;if(n instanceof Js)return`${n._name}(${n.Er})`;if(n instanceof Ys)return`${n._name}(${n.collectionId})`;if(n instanceof So)return`${n._name}()`;if(n instanceof Co)return`${n._name}(${n.hr.sort()})`;if(n instanceof Zs)return`${n._name}(${Nr(n.condition)})`;if(n instanceof rn)return`${n._name}(${n.limit})`;if(n instanceof de)return`${n._name}(${function(e){return e.map(r=>`${Nr(r.expr)}${r.direction}`).join(",")}(n.orderings)})`;throw new Error(`Unrecognized stage ${n._name}`)}function cs(n){return`${Array.from(n.entries()).sort().map(([t,e])=>`${t}=${Nr(e)}`).join(",")}`}function ge(n){return n.stages.map(t=>r_(t)).join("|")}function Hl(n,t){return ge(n)===ge(t)}function yt(n){return n instanceof Nt}function Ku(n){return yt(n)?ge(n):cr(n)}function Wl(n){return yt(n)?ge(n):function(e){return`${il(oe(e))}|lt:${e.limitType}`}(n)}function ni(n,t){return n instanceof Nt&&t instanceof Nt?Hl(n,t):!(n instanceof Nt&&!(t instanceof Nt)||!(n instanceof Nt)&&t instanceof Nt)&&wp(n,t)}function Ql(n){return Qe(n)?ge(n):il(n)}function Kl(n,t){return n instanceof Nt&&t instanceof Nt?Hl(n,t):!(n instanceof Nt&&!(t instanceof Nt)||!(n instanceof Nt)&&t instanceof Nt)&&ol(n,t)}function s_(n,t){const e=function(s){let o=!1;const a=[];for(const c of s)if(c instanceof de)if(o=!0,c.orderings.some(h=>h.expr instanceof Nn&&h.expr.fieldName===re))a.push(c);else{const h=c.orderings.map(f=>f);h.push(_s(re).ascending()),a.push(new de(h,{}))}else c instanceof rn&&(o||(a.push(new de([_s(re).ascending()],{})),o=!0)),a.push(c);return o||a.push(new de([_s(re).ascending()],{})),a}(n.stages);if(n.userDataReader){const r=n.userDataReader.createContext(3,"toCorePipeline");e.forEach(s=>s._readUserData(r))}return new Nt(n.userDataReader.serializer,e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class i_{constructor(t,e,r,s){this.batchId=t,this.localWriteTime=e,this.baseMutations=r,this.mutations=s}applyToRemoteDocument(t,e){const r=e.mutationResults;for(let s=0;s<this.mutations.length;s++){const o=this.mutations[s];o.key.isEqual(t.key)&&ep(o,t,r[s])}}applyToLocalView(t,e){for(const r of this.baseMutations)r.key.isEqual(t.key)&&(e=ar(r,t,e,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(t.key)&&(e=ar(r,t,e,this.localWriteTime));return e}applyToLocalDocumentSet(t,e){const r=hl();return this.mutations.forEach(s=>{const o=t.get(s.key),a=o.overlayedDocument;let c=this.applyToLocalView(a,o.mutatedFields);c=e.has(s.key)?null:c;const h=Jc(a,c);h!==null&&r.set(s.key,h),a.isValidDocument()||a.convertToNoDocument(q.min())}),r}keys(){return this.mutations.reduce((t,e)=>t.add(e.key),H())}isEqual(t){return this.batchId===t.batchId&&In(this.mutations,t.mutations,(e,r)=>Vu(e,r))&&In(this.baseMutations,t.baseMutations,(e,r)=>Vu(e,r))}}class Fo{constructor(t,e,r,s){this.batch=t,this.commitVersion=e,this.mutationResults=r,this.docVersions=s}static from(t,e,r){U(t.mutations.length===r.length,58842,{Br:t.mutations.length,Ur:r.length});let s=function(){return Vp}();const o=t.mutations;for(let a=0;a<o.length;a++)s=s.insert(o[a].key,r[a].version);return new Fo(t,e,r,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xl="";function o_(n){let t="";for(let e=0;e<n.length;e++)t.length>0&&(t=Xu(t)),t=a_(n.get(e),t);return Xu(t)}function a_(n,t){let e=t;const r=n.length;for(let s=0;s<r;s++){const o=n.charAt(s);switch(o){case"\0":e+="";break;case Xl:e+="";break;default:e+=o}}return e}function Xu(n){return n+Xl+""}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u_{constructor(t,e){this.largestBatchId=t,this.mutation=e}getKey(){return this.mutation.key}isEqual(t){return t!==null&&this.mutation===t.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pe{constructor(t,e,r,s,o=q.min(),a=q.min(),c=pt.EMPTY_BYTE_STRING,h=null){this.target=t,this.targetId=e,this.purpose=r,this.sequenceNumber=s,this.snapshotVersion=o,this.lastLimboFreeSnapshotVersion=a,this.resumeToken=c,this.expectedCount=h}withSequenceNumber(t){return new pe(this.target,this.targetId,this.purpose,t,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(t,e){return new pe(this.target,this.targetId,this.purpose,this.sequenceNumber,e,this.lastLimboFreeSnapshotVersion,t,null)}withExpectedCount(t){return new pe(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,t)}withLastLimboFreeSnapshotVersion(t){return new pe(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,t,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class c_{constructor(t){this.qr=t}}function l_(n){const t=$p({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Xi(t,t.limit,"L"):t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class h_{constructor(){this.Yi=new f_}addToCollectionParentIndex(t,e){return this.Yi.add(e),S.resolve()}getCollectionParents(t,e){return S.resolve(this.Yi.getEntries(e))}addFieldIndex(t,e){return S.resolve()}deleteFieldIndex(t,e){return S.resolve()}deleteAllFieldIndexes(t){return S.resolve()}createTargetIndexes(t,e){return S.resolve()}getDocumentsMatchingTarget(t,e){return S.resolve(null)}getIndexType(t,e){return S.resolve(0)}getFieldIndexes(t,e){return S.resolve([])}getNextCollectionGroupToUpdate(t){return S.resolve(null)}getMinOffset(t,e){return S.resolve(Oe.min())}getMinOffsetFromCollectionGroup(t,e){return S.resolve(Oe.min())}updateCollectionGroup(t,e,r){return S.resolve()}updateIndexEntries(t,e){return S.resolve()}}class f_{constructor(){this.index={}}add(t){const e=t.lastSegment(),r=t.popLast(),s=this.index[e]||new dt(Y.comparator),o=!s.has(r);return this.index[e]=s.add(r),o}has(t){const e=t.lastSegment(),r=t.popLast(),s=this.index[e];return s&&s.has(r)}getEntries(t){return(this.index[t]||new dt(Y.comparator)).toArray()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ue{constructor(t){this.gs=t}next(){return this.gs+=2,this.gs}static ys(){return new Ue(0)}static ws(){return new Ue(-1)}}// Copyright 2024 Google LLC* @license
function Jl(n,t){var r;let e=t;for(const s of n.stages)e=p_({serializer:n.serializer,serverTimestampBehavior:(r=n.listenOptions)==null?void 0:r.serverTimestampBehavior},s,e);return e}function ri(n,t){return Jl(n,[t]).length>0}function d_(n,t){return yt(n)?ri(n,t):Hs(n,t)}function p_(n,t,e){if(t instanceof Js)return function(s,o,a){return a.filter(c=>c.isFoundDocument()&&`/${c.key.getCollectionPath().canonicalString()}`===o.Er)}(0,t,e);if(t instanceof Zs)return function(s,o,a){return a.filter(c=>{const h=fr(j(o.condition).evaluate(s,c));return h!==void 0&&Qt(h,Mt)})}(n,t,e);if(t instanceof Ys)return function(s,o,a){return a.filter(c=>c.isFoundDocument()&&c.key.getCollectionPath().lastSegment()===o.collectionId)}(0,t,e);if(t instanceof So)return function(s,o,a){return a.filter(c=>c.isFoundDocument())}(0,0,e);if(t instanceof Co)return function(s,o,a){return a.filter(c=>c.isFoundDocument()&&o.Tr.has(c.key.path.toStringWithLeadingSlash()))}(0,t,e);if(t instanceof rn)return function(s,o,a){return a.slice(0,o.limit)}(0,t,e);if(t instanceof de)return function(s,o,a){const c=o.orderings.map(h=>({Os:j(h.expr),direction:h.direction}));return[...a].sort((h,f)=>{for(const{Os:p,direction:m}of c){const I=fr(p.evaluate(s,h)),b=fr(p.evaluate(s,f)),C=Ut(I??Rn,b??Rn);if(C!==0)return m==="ascending"?C:-C}return 0})}(n,t,e);throw new Error(`Unknown stage: ${t._name}`)}function no(n){const t=function(r){for(let s=r.stages.length-1;s>=0;s--){const o=r.stages[s];if(o instanceof de)return o.orderings}throw new Error("Pipeline must contain at least one Sort stage")}(n);return(e,r)=>{for(const s of t){const o=fr(j(s.expr).evaluate({serializer:n.serializer},e)),a=fr(j(s.expr).evaluate({serializer:n.serializer},r)),c=Ut(o||Rn,a||Rn);if(c!==0)return s.direction==="ascending"?c:-c}return 0}}function Mi(n){for(let t=n.stages.length-1;t>=0;t--){const e=n.stages[t];if(e instanceof rn)return{limit:e.limit}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class m_{constructor(){this.changes=new ln(t=>t.toString(),(t,e)=>t.isEqual(e)),this.changesApplied=!1}addEntry(t){this.assertNotApplied(),this.changes.set(t.key,t)}removeEntry(t,e){this.assertNotApplied(),this.changes.set(t,Pt.newInvalidDocument(t).setReadTime(e))}getEntry(t,e){this.assertNotApplied();const r=this.changes.get(e);return r!==void 0?S.resolve(r):this.getFromCache(t,e)}getEntries(t,e){return this.getAllFromCache(t,e)}apply(t){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(t)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class g_{constructor(t,e){this.overlayedDocument=t,this.mutatedFields=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class __{constructor(t,e,r,s){this.remoteDocumentCache=t,this.mutationQueue=e,this.documentOverlayCache=r,this.indexManager=s}getDocument(t,e){let r=null;return this.documentOverlayCache.getOverlay(t,e).next(s=>(r=s,this.remoteDocumentCache.getEntry(t,e))).next(s=>(r!==null&&ar(r.mutation,s,Kt.empty(),nt.now()),s))}getDocuments(t,e){return this.remoteDocumentCache.getEntries(t,e).next(r=>this.getLocalViewOfDocuments(t,r,H()).next(()=>r))}getLocalViewOfDocuments(t,e,r=H()){const s=Ve();return this.populateOverlays(t,s,e).next(()=>this.computeViews(t,e,s,r).next(o=>{let a=yn();return o.forEach((c,h)=>{a=a.insert(c,h.overlayedDocument)}),a}))}getOverlayedDocuments(t,e){const r=Ve();return this.populateOverlays(t,r,e).next(()=>this.computeViews(t,e,r,H()))}populateOverlays(t,e,r){const s=[];return r.forEach(o=>{e.has(o)||s.push(o)}),this.documentOverlayCache.getOverlays(t,s).next(o=>{o.forEach((a,c)=>{e.set(a,c)})})}computeViews(t,e,r,s){let o=Ot();const a=lr(),c=function(){return lr()}();return e.forEach((h,f)=>{const p=r.get(f.key);s.has(f.key)&&(p===void 0||p.mutation instanceof cn)?o=o.insert(f.key,f):p!==void 0?(a.set(f.key,p.mutation.getFieldMask()),ar(p.mutation,f,p.mutation.getFieldMask(),nt.now())):a.set(f.key,Kt.empty())}),this.recalculateAndSaveOverlays(t,o).next(h=>(h.forEach((f,p)=>a.set(f,p)),e.forEach((f,p)=>c.set(f,new g_(p,a.get(f)??null))),c))}recalculateAndSaveOverlays(t,e){const r=lr();let s=new rt((a,c)=>a-c),o=H();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(t,e).next(a=>{for(const c of a)c.keys().forEach(h=>{const f=e.get(h);if(f===null)return;let p=r.get(h)||Kt.empty();p=c.applyToLocalView(f,p),r.set(h,p);const m=(s.get(c.batchId)||H()).add(h);s=s.insert(c.batchId,m)})}).next(()=>{const a=[],c=s.getReverseIterator();for(;c.hasNext();){const h=c.getNext(),f=h.key,p=h.value,m=hl();p.forEach(I=>{if(!o.has(I)){const b=Jc(e.get(I),r.get(I));b!==null&&m.set(I,b),o=o.add(I)}}),a.push(this.documentOverlayCache.saveOverlays(t,f,m))}return S.waitFor(a)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(t,e){return this.remoteDocumentCache.getEntries(t,e).next(r=>this.recalculateAndSaveOverlays(t,r))}getDocumentsMatchingQuery(t,e,r,s){return yt(e)?this.getDocumentsMatchingPipeline(t,e,r,s):yp(e)?this.getDocumentsMatchingDocumentQuery(t,e.path):Ep(e)?this.getDocumentsMatchingCollectionGroupQuery(t,e,r,s):this.getDocumentsMatchingCollectionQuery(t,e,r,s)}getNextDocuments(t,e,r,s){return this.remoteDocumentCache.getAllFromCollectionGroup(t,e,r,s).next(o=>{const a=s-o.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(t,e,r.largestBatchId,s-o.size):S.resolve(Ve());let c=Rr,h=o;return a.next(f=>S.forEach(f,(p,m)=>(c<m.largestBatchId&&(c=m.largestBatchId),o.get(p)?S.resolve():this.remoteDocumentCache.getEntry(t,p).next(I=>{h=h.insert(p,I)}))).next(()=>this.populateOverlays(t,f,o)).next(()=>this.computeViews(t,h,f,H())).next(p=>({batchId:c,changes:ll(p)})))})}getDocumentsMatchingDocumentQuery(t,e){return this.getDocument(t,new F(e)).next(r=>{let s=yn();return r.isFoundDocument()&&(s=s.insert(r.key,r)),s})}getDocumentsMatchingCollectionGroupQuery(t,e,r,s){const o=e.collectionGroup;let a=yn();return this.indexManager.getCollectionParents(t,o).next(c=>S.forEach(c,h=>{const f=function(m,I){return new zs(I,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(e,h.child(o));return this.getDocumentsMatchingCollectionQuery(t,f,r,s).next(p=>{p.forEach((m,I)=>{a=a.insert(m,I)})})}).next(()=>a))}getDocumentsMatchingCollectionQuery(t,e,r,s){let o;return this.documentOverlayCache.getOverlaysForCollection(t,e.path,r.largestBatchId).next(a=>(o=a,this.remoteDocumentCache.getDocumentsMatchingQuery(t,e,r,o,s))).next(a=>this.retrieveMatchingLocalDocuments(o,a,c=>Hs(e,c)))}getDocumentsMatchingPipeline(t,e,r,s){if(xe(e)==="collection_group"){const o=Uo(e);let a=yn();return this.indexManager.getCollectionParents(t,o).next(c=>S.forEach(c,h=>{const f=function(m,I){const b=m.stages.map(C=>C instanceof Ys?new Js(I.canonicalString(),{}):C);return new Nt(m.serializer,b)}(e,h.child(o));return this.getDocumentsMatchingPipeline(t,f,r,s).next(p=>{p.forEach((m,I)=>{a=a.insert(m,I)})})}).next(()=>a))}{let o;return this.getOverlaysForPipeline(t,e,r.largestBatchId).next(a=>{switch(o=a,xe(e)){case"collection":return this.remoteDocumentCache.getDocumentsMatchingQuery(t,e,r,o,s);case"documents":let c=H();for(const h of eo(e))c=c.add(F.fromPath(h));return this.remoteDocumentCache.getEntries(t,c);case"database":return this.remoteDocumentCache.getAllEntries(t);default:throw new L("invalid-argument",`Invalid pipeline source to execute offline: ${ge(e)}`)}}).next(a=>this.retrieveMatchingLocalDocuments(o,a,c=>ri(e,c)))}}retrieveMatchingLocalDocuments(t,e,r){t.forEach((o,a)=>{const c=a.getKey();e.get(c)===null&&(e=e.insert(c,Pt.newInvalidDocument(c)))});let s=yn();return e.forEach((o,a)=>{const c=t.get(o);c!==void 0&&ar(c.mutation,a,Kt.empty(),nt.now()),r(a)&&(s=s.insert(o,a))}),s}getOverlaysForPipeline(t,e,r){switch(xe(e)){case"collection":return this.documentOverlayCache.getOverlaysForCollection(t,Y.fromString(ei(e)),r);case"collection_group":throw new L("invalid-argument",`Unexpected collection group pipeline: ${ge(e)}`);case"documents":return this.documentOverlayCache.getOverlays(t,eo(e).map(s=>F.fromPath(s)));case"database":return this.documentOverlayCache.getAllOverlays(t,r);default:throw new L("invalid-argument",`Failed to get overlays for pipeline: ${ge(e)}`)}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y_{constructor(t){this.serializer=t,this.Ks=new Map,this.Ws=new Map}getBundleMetadata(t,e){return S.resolve(this.Ks.get(e))}saveBundleMetadata(t,e){return this.Ks.set(e.id,function(s){return{id:s.id,version:s.version,createTime:ae(s.createTime)}}(e)),S.resolve()}getNamedQuery(t,e){return S.resolve(this.Ws.get(e))}saveNamedQuery(t,e){return this.Ws.set(e.name,function(s){return{name:s.name,query:l_(s.bundledQuery),readTime:ae(s.readTime)}}(e)),S.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class E_{constructor(){this.overlays=new rt(F.comparator),this.Qs=new Map}getOverlay(t,e){return S.resolve(this.overlays.get(e))}getOverlays(t,e){const r=Ve();return S.forEach(e,s=>this.getOverlay(t,s).next(o=>{o!==null&&r.set(s,o)})).next(()=>r)}getAllOverlays(t,e){const r=Ve();return this.overlays.forEach((s,o)=>{o.largestBatchId>e&&r.set(s,o)}),S.resolve(r)}saveOverlays(t,e,r){return r.forEach((s,o)=>{this.Yr(t,e,o)}),S.resolve()}removeOverlaysForBatchId(t,e,r){const s=this.Qs.get(r);return s!==void 0&&(s.forEach(o=>this.overlays=this.overlays.remove(o)),this.Qs.delete(r)),S.resolve()}getOverlaysForCollection(t,e,r){const s=Ve(),o=e.length+1,a=new F(e.child("")),c=this.overlays.getIteratorFrom(a);for(;c.hasNext();){const h=c.getNext().value,f=h.getKey();if(!e.isPrefixOf(f.path))break;f.path.length===o&&h.largestBatchId>r&&s.set(h.getKey(),h)}return S.resolve(s)}getOverlaysForCollectionGroup(t,e,r,s){let o=new rt((f,p)=>f-p);const a=this.overlays.getIterator();for(;a.hasNext();){const f=a.getNext().value;if(f.getKey().getCollectionGroup()===e&&f.largestBatchId>r){let p=o.get(f.largestBatchId);p===null&&(p=Ve(),o=o.insert(f.largestBatchId,p)),p.set(f.getKey(),f)}}const c=Ve(),h=o.getIterator();for(;h.hasNext()&&(h.getNext().value.forEach((f,p)=>c.set(f,p)),!(c.size()>=s)););return S.resolve(c)}Yr(t,e,r){const s=this.overlays.get(r.key);if(s!==null){const a=this.Qs.get(s.largestBatchId).delete(r.key);this.Qs.set(s.largestBatchId,a)}this.overlays=this.overlays.insert(r.key,new u_(e,r));let o=this.Qs.get(e);o===void 0&&(o=H(),this.Qs.set(e,o)),this.Qs.set(e,o.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T_{constructor(){this.sessionToken=pt.EMPTY_BYTE_STRING}getSessionToken(t){return S.resolve(this.sessionToken)}setSessionToken(t,e){return this.sessionToken=e,S.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bo{constructor(){this.Gs=new dt(Tt.zs),this.js=new dt(Tt.Hs)}isEmpty(){return this.Gs.isEmpty()}addReference(t,e){const r=new Tt(t,e);this.Gs=this.Gs.add(r),this.js=this.js.add(r)}Js(t,e){t.forEach(r=>this.addReference(r,e))}removeReference(t,e){this.Ys(new Tt(t,e))}Zs(t,e){t.forEach(r=>this.removeReference(r,e))}Xs(t){const e=new F(new Y([])),r=new Tt(e,t),s=new Tt(e,t+1),o=[];return this.js.forEachInRange([r,s],a=>{this.Ys(a),o.push(a.key)}),o}e_(){this.Gs.forEach(t=>this.Ys(t))}Ys(t){this.Gs=this.Gs.delete(t),this.js=this.js.delete(t)}t_(t){const e=new F(new Y([])),r=new Tt(e,t),s=new Tt(e,t+1);let o=H();return this.js.forEachInRange([r,s],a=>{o=o.add(a.key)}),o}containsKey(t){const e=new Tt(t,0),r=this.Gs.firstAfterOrEqual(e);return r!==null&&t.isEqual(r.key)}}class Tt{constructor(t,e){this.key=t,this.n_=e}static zs(t,e){return F.comparator(t.key,e.key)||Q(t.n_,e.n_)}static Hs(t,e){return Q(t.n_,e.n_)||F.comparator(t.key,e.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class w_{constructor(t,e){this.indexManager=t,this.referenceDelegate=e,this.mutationQueue=[],this.Qr=1,this.r_=new dt(Tt.zs)}checkEmpty(t){return S.resolve(this.mutationQueue.length===0)}addMutationBatch(t,e,r,s){const o=this.Qr;this.Qr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const a=new i_(o,e,r,s);this.mutationQueue.push(a);for(const c of s)this.r_=this.r_.add(new Tt(c.key,o)),this.indexManager.addToCollectionParentIndex(t,c.key.path.popLast());return S.resolve(a)}lookupMutationBatch(t,e){return S.resolve(this.i_(e))}getNextMutationBatchAfterBatchId(t,e){const r=e+1,s=this.s_(r),o=s<0?0:s;return S.resolve(this.mutationQueue.length>o?this.mutationQueue[o]:null)}getHighestUnacknowledgedBatchId(){return S.resolve(this.mutationQueue.length===0?mo:this.Qr-1)}getAllMutationBatches(t){return S.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(t,e){const r=new Tt(e,0),s=new Tt(e,Number.POSITIVE_INFINITY),o=[];return this.r_.forEachInRange([r,s],a=>{const c=this.i_(a.n_);o.push(c)}),S.resolve(o)}getAllMutationBatchesAffectingDocumentKeys(t,e){let r=new dt(Q);return e.forEach(s=>{const o=new Tt(s,0),a=new Tt(s,Number.POSITIVE_INFINITY);this.r_.forEachInRange([o,a],c=>{r=r.add(c.n_)})}),S.resolve(this.__(r))}getAllMutationBatchesAffectingQuery(t,e){const r=e.path,s=r.length+1;let o=r;F.isDocumentKey(o)||(o=o.child(""));const a=new Tt(new F(o),0);let c=new dt(Q);return this.r_.forEachWhile(h=>{const f=h.key.path;return!!r.isPrefixOf(f)&&(f.length===s&&(c=c.add(h.n_)),!0)},a),S.resolve(this.__(c))}__(t){const e=[];return t.forEach(r=>{const s=this.i_(r);s!==null&&e.push(s)}),e}removeMutationBatch(t,e){U(this.o_(e.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.r_;return S.forEach(e.mutations,s=>{const o=new Tt(s.key,e.batchId);return r=r.delete(o),this.referenceDelegate.markPotentiallyOrphaned(t,s.key)}).next(()=>{this.r_=r})}jr(t){}containsKey(t,e){const r=new Tt(e,0),s=this.r_.firstAfterOrEqual(r);return S.resolve(e.isEqual(s&&s.key))}performConsistencyCheck(t){return this.mutationQueue.length,S.resolve()}o_(t,e){return this.s_(t)}s_(t){return this.mutationQueue.length===0?0:t-this.mutationQueue[0].batchId}i_(t){const e=this.s_(t);return e<0||e>=this.mutationQueue.length?null:this.mutationQueue[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v_{constructor(t){this.a_=t,this.docs=function(){return new rt(F.comparator)}(),this.size=0}setIndexManager(t){this.indexManager=t}addEntry(t,e){const r=e.key,s=this.docs.get(r),o=s?s.size:0,a=this.a_(e);return this.docs=this.docs.insert(r,{document:e.mutableCopy(),size:a}),this.size+=a-o,this.indexManager.addToCollectionParentIndex(t,r.path.popLast())}removeEntry(t){const e=this.docs.get(t);e&&(this.docs=this.docs.remove(t),this.size-=e.size)}getEntry(t,e){const r=this.docs.get(e);return S.resolve(r?r.document.mutableCopy():Pt.newInvalidDocument(e))}getEntries(t,e){let r=Ot();return e.forEach(s=>{const o=this.docs.get(s);r=r.insert(s,o?o.document.mutableCopy():Pt.newInvalidDocument(s))}),S.resolve(r)}getAllEntries(t){let e=Ot();return this.docs.forEach((r,s)=>{e=e.insert(r,s.document)}),S.resolve(e)}getDocumentsMatchingQuery(t,e,r,s){let o,a;yt(e)?(o=Y.fromString(ei(e)),a=p=>ri(e,p)):(o=e.path,a=p=>Hs(e,p));let c=Ot();const h=new F(o.child("__id-9223372036854775808__")),f=this.docs.getIteratorFrom(h);for(;f.hasNext();){const{key:p,value:{document:m}}=f.getNext();if(!o.isPrefixOf(p.path))break;p.path.length>o.length+1||mp(pp(m),r)<=0||(s.has(m.key)||a(m))&&(c=c.insert(m.key,m.mutableCopy()))}return S.resolve(c)}getAllFromCollectionGroup(t,e,r,s){B(9500)}u_(t,e){return S.forEach(this.docs,r=>e(r))}newChangeBuffer(t){return new I_(this)}getSize(t){return S.resolve(this.size)}}class I_ extends m_{constructor(t){super(),this.qs=t}applyChanges(t){const e=[];return this.changes.forEach((r,s)=>{s.isValidDocument()?e.push(this.qs.addEntry(t,s)):this.qs.removeEntry(r)}),S.waitFor(e)}getFromCache(t,e){return this.qs.getEntry(t,e)}getAllFromCache(t,e){return this.qs.getEntries(t,e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A_{constructor(t){this.persistence=t,this.c_=new ln(e=>Ql(e),Kl),this.lastRemoteSnapshotVersion=q.min(),this.highestTargetId=0,this.l_=0,this.E_=new Bo,this.targetCount=0,this.h_=Ue.ys()}forEachTarget(t,e){return this.c_.forEach((r,s)=>e(s)),S.resolve()}getLastRemoteSnapshotVersion(t){return S.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(t){return S.resolve(this.l_)}allocateTargetId(t){return this.highestTargetId=this.h_.next(),S.resolve(this.highestTargetId)}setTargetsMetadata(t,e,r){return r&&(this.lastRemoteSnapshotVersion=r),e>this.l_&&(this.l_=e),S.resolve()}Ss(t){this.c_.set(t.target,t);const e=t.targetId;e>this.highestTargetId&&(this.h_=new Ue(e),this.highestTargetId=e),t.sequenceNumber>this.l_&&(this.l_=t.sequenceNumber)}addTargetData(t,e){return this.Ss(e),this.targetCount+=1,S.resolve()}updateTargetData(t,e){return this.Ss(e),S.resolve()}removeTargetData(t,e){return this.c_.delete(e.target),this.E_.Xs(e.targetId),this.targetCount-=1,S.resolve()}removeTargets(t,e,r){let s=0;const o=[];return this.c_.forEach((a,c)=>{c.sequenceNumber<=e&&r.get(c.targetId)===null&&(this.c_.delete(a),o.push(this.removeMatchingKeysForTargetId(t,c.targetId)),s++)}),S.waitFor(o).next(()=>s)}getTargetCount(t){return S.resolve(this.targetCount)}getTargetData(t,e){const r=this.c_.get(e)||null;return S.resolve(r)}addMatchingKeys(t,e,r){return this.E_.Js(e,r),S.resolve()}removeMatchingKeys(t,e,r){this.E_.Zs(e,r);const s=this.persistence.referenceDelegate,o=[];return s&&e.forEach(a=>{o.push(s.markPotentiallyOrphaned(t,a))}),S.waitFor(o)}removeMatchingKeysForTargetId(t,e){return this.E_.Xs(e),S.resolve()}getMatchingKeysForTargetId(t,e){const r=this.E_.t_(e);return S.resolve(r)}containsKey(t,e){return S.resolve(this.E_.containsKey(e))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yl{constructor(t,e){this.T_={},this.overlays={},this.P_=new Qs(0),this.R_=!1,this.R_=!0,this.I_=new T_,this.referenceDelegate=t(this),this.A_=new A_(this),this.indexManager=new h_,this.remoteDocumentCache=function(s){return new v_(s)}(r=>this.referenceDelegate.V_(r)),this.serializer=new c_(e),this.d_=new y_(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.R_=!1,Promise.resolve()}get started(){return this.R_}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(t){return this.indexManager}getDocumentOverlayCache(t){let e=this.overlays[t.toKey()];return e||(e=new E_,this.overlays[t.toKey()]=e),e}getMutationQueue(t,e){let r=this.T_[t.toKey()];return r||(r=new w_(e,this.referenceDelegate),this.T_[t.toKey()]=r),r}getGlobalsCache(){return this.I_}getTargetCache(){return this.A_}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.d_}runTransaction(t,e,r){O("MemoryPersistence","Starting transaction:",t);const s=new R_(this.P_.next());return this.referenceDelegate.f_(),r(s).next(o=>this.referenceDelegate.m_(s).next(()=>o)).toPromise().then(o=>(s.raiseOnCommittedEvent(),o))}p_(t,e){return S.or(Object.values(this.T_).map(r=>()=>r.containsKey(t,e)))}}class R_ extends gm{constructor(t){super(),this.currentSequenceNumber=t}}class jo{constructor(t){this.persistence=t,this.g_=new Bo,this.y_=null}static w_(t){return new jo(t)}get b_(){if(this.y_)return this.y_;throw B(60996)}addReference(t,e,r){return this.g_.addReference(r,e),this.b_.delete(r.toString()),S.resolve()}removeReference(t,e,r){return this.g_.removeReference(r,e),this.b_.add(r.toString()),S.resolve()}markPotentiallyOrphaned(t,e){return this.b_.add(e.toString()),S.resolve()}removeTarget(t,e){this.g_.Xs(e.targetId).forEach(s=>this.b_.add(s.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(t,e.targetId).next(s=>{s.forEach(o=>this.b_.add(o.toString()))}).next(()=>r.removeTargetData(t,e))}f_(){this.y_=new Set}m_(t){const e=this.persistence.getRemoteDocumentCache().newChangeBuffer();return S.forEach(this.b_,r=>{const s=F.fromPath(r);return this.v_(t,s).next(o=>{o||e.removeEntry(s,q.min())})}).next(()=>(this.y_=null,e.apply(t)))}updateLimboDocument(t,e){return this.v_(t,e).next(r=>{r?this.b_.delete(e.toString()):this.b_.add(e.toString())})}V_(t){return 0}v_(t,e){return S.or([()=>S.resolve(this.g_.containsKey(e)),()=>this.persistence.getTargetCache().containsKey(t,e),()=>this.persistence.p_(t,e)])}}class Ds{constructor(t,e){this.persistence=t,this.S_=new ln(r=>o_(r.path),(r,s)=>r.isEqual(s)),this.garbageCollector=vm(this,e)}static w_(t,e){return new Ds(t,e)}f_(){}m_(t){return S.resolve()}forEachTarget(t,e){return this.persistence.getTargetCache().forEachTarget(t,e)}rr(t){const e=this.xs(t);return this.persistence.getTargetCache().getTargetCount(t).next(r=>e.next(s=>r+s))}xs(t){let e=0;return this.ir(t,r=>{e++}).next(()=>e)}ir(t,e){return S.forEach(this.S_,(r,s)=>this.Fs(t,r,s).next(o=>o?S.resolve():e(s)))}removeTargets(t,e,r){return this.persistence.getTargetCache().removeTargets(t,e,r)}removeOrphanedDocuments(t,e){let r=0;const s=this.persistence.getRemoteDocumentCache(),o=s.newChangeBuffer();return s.u_(t,a=>this.Fs(t,a,e).next(c=>{c||(r++,o.removeEntry(a,q.min()))})).next(()=>o.apply(t)).next(()=>r)}markPotentiallyOrphaned(t,e){return this.S_.set(e,t.currentSequenceNumber),S.resolve()}removeTarget(t,e){const r=e.withSequenceNumber(t.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(t,r)}addReference(t,e,r){return this.S_.set(r,t.currentSequenceNumber),S.resolve()}removeReference(t,e,r){return this.S_.set(r,t.currentSequenceNumber),S.resolve()}updateLimboDocument(t,e){return this.S_.set(e,t.currentSequenceNumber),S.resolve()}V_(t){let e=t.key.toString().length;return t.isFoundDocument()&&(e+=ds(t.data.value)),e}Fs(t,e,r){return S.or([()=>this.persistence.p_(t,e),()=>this.persistence.getTargetCache().containsKey(t,e),()=>{const s=this.S_.get(e);return S.resolve(s!==void 0&&s>r)}])}getCacheSize(t){return this.persistence.getRemoteDocumentCache().getSize(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qo{constructor(t,e,r,s){this.targetId=t,this.fromCache=e,this.Ao=r,this.Vo=s}static fo(t,e){let r=H(),s=H();for(const o of e.docChanges)switch(o.type){case 0:r=r.add(o.doc.key);break;case 1:s=s.add(o.doc.key)}return new qo(t,e.fromCache,r,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function V_(n,t){return F.comparator(n.key,t.key)}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P_{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(t){this._documentReadCount+=t}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b_{constructor(){this.mo=!1,this.po=!1,this.yo=100,this.wo=function(){return xf()?8:_m(lo())>0?6:4}()}initialize(t,e){this.bo=t,this.indexManager=e,this.mo=!0}getDocumentsMatchingQuery(t,e,r,s){const o={result:null};return this.vo(t,e).next(a=>{o.result=a}).next(()=>{if(!o.result)return this.So(t,e,s,r).next(a=>{o.result=a})}).next(()=>{if(o.result)return;const a=new P_;return this.Do(t,e,a).next(c=>{if(o.result=c,this.po)return this.xo(t,e,a,c.size)})}).next(()=>o.result)}xo(t,e,r,s){return yt(e)?S.resolve():r.documentReadCount<this.yo?(gn()<=X.DEBUG&&O("QueryEngine","SDK will not create cache indexes for query:",cr(e),"since it only creates cache indexes for collection contains","more than or equal to",this.yo,"documents"),S.resolve()):(gn()<=X.DEBUG&&O("QueryEngine","Query:",cr(e),"scans",r.documentReadCount,"local documents and returns",s,"documents as results."),r.documentReadCount>this.wo*s?(gn()<=X.DEBUG&&O("QueryEngine","The SDK decides to create cache indexes for query:",cr(e),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(t,oe(e))):S.resolve())}vo(t,e){if(yt(e))return S.resolve(null);let r=e;if(Nu(r))return S.resolve(null);let s=oe(r);return this.indexManager.getIndexType(t,s).next(o=>o===0?null:(r.limit!==null&&o===1&&(r=Xi(r,null,"F"),s=oe(r)),this.indexManager.getDocumentsMatchingTarget(t,s).next(a=>{const c=H(...a);return this.bo.getDocuments(t,c).next(h=>this.indexManager.getMinOffset(t,s).next(f=>{const p=this.Co(r,h);return this.Fo(r,p,c,f.readTime)?this.vo(t,Xi(r,null,"F")):this.Oo(t,p,r,f)}))})))}So(t,e,r,s){return(yt(e)?function(a){for(const c of a.stages){if(c instanceof rn||c instanceof Qu)return!1;if(c instanceof Zs){if(c.condition instanceof Ol&&c.condition._expr.name==="exists"&&c.condition._expr.params[0]instanceof Nn&&c.condition._expr.params[0].fieldName===re)continue;return!1}}return!0}(e):Nu(e))||s.isEqual(q.min())?S.resolve(null):this.bo.getDocuments(t,r).next(o=>{const a=this.Co(e,o);return this.Fo(e,a,r,s)?S.resolve(null):(gn()<=X.DEBUG&&O("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),Ku(e)),this.Oo(t,a,e,dp(s,Rr)).next(c=>c))})}Co(t,e){let r,s;return yt(t)?(r=new dt(V_),s=o=>ri(t,o)):(r=new dt(To(t)),s=o=>Hs(t,o)),e.forEach((o,a)=>{s(a)&&(r=r.add(a))}),r}Fo(t,e,r,s){if(yt(t))return function(c){return c.stages.some(h=>h instanceof rn||h instanceof Qu)}(t);if(t.limit===null)return!1;if(r.size!==e.size)return!0;const o=t.limitType==="F"?e.last():e.first();return!!o&&(o.hasPendingWrites||o.version.compareTo(s)>0)}Do(t,e,r){return gn()<=X.DEBUG&&O("QueryEngine","Using full collection scan to execute query:",Ku(e)),this.bo.getDocumentsMatchingQuery(t,e,Oe.min(),r)}Oo(t,e,r,s){return this.bo.getDocumentsMatchingQuery(t,r,s).next(o=>(e.forEach(a=>{o=o.insert(a.key,a)}),o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $o="LocalStore",S_=3e8;class C_{constructor(t,e,r,s){this.persistence=t,this.Mo=e,this.serializer=s,this.No=new rt(Q),this.Lo=new ln(o=>Ql(o),Kl),this.Bo=new Map,this.Uo=t.getRemoteDocumentCache(),this.A_=t.getTargetCache(),this.d_=t.getBundleCache(),this.ko(r)}ko(t){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(t),this.indexManager=this.persistence.getIndexManager(t),this.mutationQueue=this.persistence.getMutationQueue(t,this.indexManager),this.localDocuments=new __(this.Uo,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.Uo.setIndexManager(this.indexManager),this.Mo.initialize(this.localDocuments,this.indexManager)}collectGarbage(t){return this.persistence.runTransaction("Collect garbage","readwrite-primary",e=>t.collect(e,this.No))}}function x_(n,t,e,r){return new C_(n,t,e,r)}async function Zl(n,t){const e=$(n);return await e.persistence.runTransaction("Handle user change","readonly",r=>{let s;return e.mutationQueue.getAllMutationBatches(r).next(o=>(s=o,e.ko(t),e.mutationQueue.getAllMutationBatches(r))).next(o=>{const a=[],c=[];let h=H();for(const f of s){a.push(f.batchId);for(const p of f.mutations)h=h.add(p.key)}for(const f of o){c.push(f.batchId);for(const p of f.mutations)h=h.add(p.key)}return e.localDocuments.getDocuments(r,h).next(f=>({qo:f,removedBatchIds:a,addedBatchIds:c}))})})}function N_(n,t){const e=$(n);return e.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const s=t.batch.keys(),o=e.Uo.newChangeBuffer({trackRemovals:!0});return function(c,h,f,p){const m=f.batch,I=m.keys();let b=S.resolve();return I.forEach(C=>{b=b.next(()=>p.getEntry(h,C)).next(M=>{const k=f.docVersions.get(C);U(k!==null,48541),M.version.compareTo(k)<0&&(m.applyToRemoteDocument(M,f),M.isValidDocument()&&(M.setReadTime(f.commitVersion),p.addEntry(M)))})}),b.next(()=>c.mutationQueue.removeMutationBatch(h,m))}(e,r,t,o).next(()=>o.apply(r)).next(()=>e.mutationQueue.performConsistencyCheck(r)).next(()=>e.documentOverlayCache.removeOverlaysForBatchId(r,s,t.batch.batchId)).next(()=>e.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(c){let h=H();for(let f=0;f<c.mutationResults.length;++f)c.mutationResults[f].transformResults.length>0&&(h=h.add(c.batch.mutations[f].key));return h}(t))).next(()=>e.localDocuments.getDocuments(r,s))})}function th(n){const t=$(n);return t.persistence.runTransaction("Get last remote snapshot version","readonly",e=>t.A_.getLastRemoteSnapshotVersion(e))}function D_(n,t){const e=$(n),r=t.snapshotVersion;let s=e.No;return e.persistence.runTransaction("Apply remote event","readwrite-primary",o=>{const a=e.Uo.newChangeBuffer({trackRemovals:!0});s=e.No;const c=[];t.targetChanges.forEach((p,m)=>{const I=s.get(m);if(!I)return;c.push(e.A_.removeMatchingKeys(o,p.removedDocuments,m).next(()=>e.A_.addMatchingKeys(o,p.addedDocuments,m)));let b=I.withSequenceNumber(o.currentSequenceNumber);t.targetMismatches.get(m)!==null?b=b.withResumeToken(pt.EMPTY_BYTE_STRING,q.min()).withLastLimboFreeSnapshotVersion(q.min()):p.resumeToken.approximateByteSize()>0&&(b=b.withResumeToken(p.resumeToken,r)),s=s.insert(m,b),function(M,k,z){return M.resumeToken.approximateByteSize()===0||k.snapshotVersion.toMicroseconds()-M.snapshotVersion.toMicroseconds()>=S_?!0:z.addedDocuments.size+z.modifiedDocuments.size+z.removedDocuments.size>0}(I,b,p)&&c.push(e.A_.updateTargetData(o,b))});let h=Ot(),f=H();if(t.documentUpdates.forEach(p=>{t.resolvedLimboDocuments.has(p)&&c.push(e.persistence.referenceDelegate.updateLimboDocument(o,p))}),c.push(k_(o,a,t.documentUpdates).next(p=>{h=p.$o,f=p.Ko})),!r.isEqual(q.min())){const p=e.A_.getLastRemoteSnapshotVersion(o).next(m=>e.A_.setTargetsMetadata(o,o.currentSequenceNumber,r));c.push(p)}return S.waitFor(c).next(()=>a.apply(o)).next(()=>e.localDocuments.getLocalViewOfDocuments(o,h,f)).next(()=>h)}).then(o=>(e.No=s,o))}function k_(n,t,e){let r=H(),s=H();return e.forEach(o=>r=r.add(o)),t.getEntries(n,r).next(o=>{let a=Ot();return e.forEach((c,h)=>{const f=o.get(c);h.isFoundDocument()!==f.isFoundDocument()&&(s=s.add(c)),h.isNoDocument()&&h.version.isEqual(q.min())?(t.removeEntry(c,h.readTime),a=a.insert(c,h)):!f.isValidDocument()||h.version.compareTo(f.version)>0||h.version.compareTo(f.version)===0&&f.hasPendingWrites?(t.addEntry(h),a=a.insert(c,h)):O($o,"Ignoring outdated watch update for ",c,". Current version:",f.version," Watch version:",h.version)}),{$o:a,Ko:s}})}function O_(n,t){const e=$(n);return e.persistence.runTransaction("Get next mutation batch","readonly",r=>(t===void 0&&(t=mo),e.mutationQueue.getNextMutationBatchAfterBatchId(r,t)))}function L_(n,t){const e=$(n);return e.persistence.runTransaction("Allocate target","readwrite",r=>{let s;return e.A_.getTargetData(r,t).next(o=>o?(s=o,S.resolve(s)):e.A_.allocateTargetId(r).next(a=>(s=new pe(t,a,"TargetPurposeListen",r.currentSequenceNumber),e.A_.addTargetData(r,s).next(()=>s))))}).then(r=>{const s=e.No.get(r.targetId);return(s===null||r.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(e.No=e.No.insert(r.targetId,r),e.Lo.set(t,r.targetId)),r})}async function ro(n,t,e){const r=$(n),s=r.No.get(t),o=e?"readwrite":"readwrite-primary";try{e||await r.persistence.runTransaction("Release target",o,a=>r.persistence.referenceDelegate.removeTarget(a,s))}catch(a){if(!xn(a))throw a;O($o,`Failed to update sequence numbers for target ${t}: ${a}`)}r.No=r.No.remove(t),r.Lo.delete(s.target)}function Ju(n,t,e){const r=$(n);let s=q.min(),o=H();return r.persistence.runTransaction("Execute query","readwrite",a=>function(h,f,p){const m=$(h),I=m.Lo.get(p);return I!==void 0?S.resolve(m.No.get(I)):m.A_.getTargetData(f,p)}(r,a,yt(t)?t:oe(t)).next(c=>{if(c)return s=c.lastLimboFreeSnapshotVersion,r.A_.getMatchingKeysForTargetId(a,c.targetId).next(h=>{o=h})}).next(()=>r.Mo.getDocumentsMatchingQuery(a,t,e?s:q.min(),e?o:H())).next(c=>(M_(r,c),{documents:c,Wo:o})))}function M_(n,t){t.forEach((e,r)=>{const s=r.key.getCollectionGroup(),o=n.Bo.get(s)||q.min();r.readTime.compareTo(o)>0&&n.Bo.set(s,r.readTime)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U_{constructor(t,e){this.asyncQueue=t,this.onlineStateHandler=e,this.state="Unknown",this.Jo=0,this.Yo=null,this.Zo=!0}Xo(){this.Jo===0&&(this.ea("Unknown"),this.Yo=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.Yo=null,this.ta("Backend didn't respond within 10 seconds."),this.ea("Offline"),Promise.resolve())))}na(t){this.state==="Online"?this.ea("Unknown"):(this.Jo++,this.Jo>=1&&(this.ra(),this.ta(`Connection failed 1 times. Most recent error: ${t.toString()}`),this.ea("Offline")))}set(t){this.ra(),this.Jo=0,t==="Online"&&(this.Zo=!1),this.ea(t)}ea(t){t!==this.state&&(this.state=t,this.onlineStateHandler(t))}ta(t){const e=`Could not reach Cloud Firestore backend. ${t}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Zo?(ye(e),this.Zo=!1):O("OnlineStateTracker",e)}ra(){this.Yo!==null&&(this.Yo.cancel(),this.Yo=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const he="RemoteStore";class F_{constructor(t,e,r,s,o){this.localStore=t,this.datastore=e,this.asyncQueue=r,this.remoteSyncer={},this.ia=[],this.sa=new Map,this._a=new Map,this.oa=new Map,this.aa=new Ue(1e3),this.ua=new Ue(1001),this.ca=new Set,this.la=[],this.Ea=o,this.Ea.Ke(a=>{r.enqueueAndForget(async()=>{fn(this)&&(O(he,"Restarting streams for network reachability change."),await async function(h){const f=$(h);f.ca.add(4),await jr(f),f.ha.set("Unknown"),f.ca.delete(4),await si(f)}(this))})}),this.ha=new U_(r,s)}}async function si(n){if(fn(n))for(const t of n.la)await t(!0)}async function jr(n){for(const t of n.la)await t(!1)}function so(n,t){return n._a.get(t)||void 0}function eh(n,t){const e=$(n),r=so(e,t.targetId);if(r!==void 0&&e.sa.has(r))return;const s=function(c,h){const f=so(c,h);f!==void 0&&c.oa.delete(f);const p=function(I,b){return b%2!=0?I.ua.next():I.aa.next()}(c,h);return c._a.set(h,p),c.oa.set(p,h),p}(e,t.targetId);O(he,"remoteStoreListen mapping SDK target ID to remote",t.targetId,s);const o=new pe(t.target,s,t.purpose,t.sequenceNumber,t.snapshotVersion,t.lastLimboFreeSnapshotVersion,t.resumeToken);e.sa.set(s,o),Wo(e)?Ho(e):Ln(e).Jt()&&Go(e,o)}function zo(n,t){const e=$(n),r=Ln(e),s=so(e,t);O(he,"remoteStoreUnlisten removing mapping of SDK target ID to remote",t,s),e.sa.delete(s),e._a.delete(t),e.oa.delete(s),r.Jt()&&nh(e,s),e.sa.size===0&&(r.Jt()?r.Xt():fn(e)&&e.ha.set("Unknown"))}function Go(n,t){if(n.Ta.H(t.targetId),t.resumeToken.approximateByteSize()>0||t.snapshotVersion.compareTo(q.min())>0){const e=n.oa.get(t.targetId);if(e===void 0)return void O(he,"SDK target ID not found for remote ID: "+t.targetId);const r=n.remoteSyncer.getRemoteKeysForTarget(e).size;t=t.withExpectedCount(r)}Ln(n).Tn(t)}function nh(n,t){n.Ta.H(t),Ln(n).Pn(t)}function Ho(n){n.Ta=new Np({getRemoteKeysForTarget:t=>{const e=n.oa.get(t);return e!==void 0?n.remoteSyncer.getRemoteKeysForTarget(e):H()},ge:t=>n.sa.get(t)||null,Ae:()=>n.datastore.serializer.databaseId}),Ln(n).start(),n.ha.Xo()}function Wo(n){return fn(n)&&!Ln(n).Ht()&&n.sa.size>0}function fn(n){return $(n).ca.size===0}function rh(n){n.Ta=void 0}async function B_(n){n.ha.set("Online")}async function j_(n){n.sa.forEach((t,e)=>{Go(n,t)})}async function q_(n,t){rh(n),Wo(n)?(n.ha.na(t),Ho(n)):n.ha.set("Unknown")}async function $_(n,t,e){if(n.ha.set("Online"),t instanceof dl&&t.state===2&&t.cause)try{await async function(s,o){const a=o.cause;for(const c of o.targetIds){if(s.sa.has(c)){const h=s.oa.get(c);h!==void 0&&(await s.remoteSyncer.rejectListen(h,a),s._a.delete(h),s.oa.delete(c)),s.sa.delete(c)}s.Ta.removeTarget(c)}}(n,t)}catch(r){O(he,"Failed to remove targets %s: %s ",t.targetIds.join(","),r),await ks(n,r)}else if(t instanceof ms?n.Ta.se(t):t instanceof fl?n.Ta.Ee(t):n.Ta.ae(t),!e.isEqual(q.min()))try{const r=await th(n.localStore);e.compareTo(r)>=0&&await function(o,a){const c=o.Ta.de(a);c.targetChanges.forEach((f,p)=>{if(f.resumeToken.approximateByteSize()>0){const m=o.sa.get(p);m&&o.sa.set(p,m.withResumeToken(f.resumeToken,a))}}),c.targetMismatches.forEach((f,p)=>{const m=o.sa.get(f);if(!m)return;o.sa.set(f,m.withResumeToken(pt.EMPTY_BYTE_STRING,m.snapshotVersion)),nh(o,f);const I=new pe(m.target,f,p,m.sequenceNumber);Go(o,I)});const h=function(p,m){const I=new Map;m.targetChanges.forEach((C,M)=>{const k=p.oa.get(M);k!==void 0&&I.set(k,C)});let b=new rt(Q);return m.targetMismatches.forEach((C,M)=>{const k=p.oa.get(C);k!==void 0&&(b=b.insert(k,M))}),new Mr(m.snapshotVersion,I,b,m.documentUpdates,m.augmentedDocumentUpdates,m.resolvedLimboDocuments)}(o,c);return o.remoteSyncer.applyRemoteEvent(h)}(n,e)}catch(r){O(he,"Failed to raise snapshot:",r),await ks(n,r)}}async function ks(n,t,e){if(!xn(t))throw t;n.ca.add(1),await jr(n),n.ha.set("Offline"),e||(e=()=>th(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{O(he,"Retrying IndexedDB access"),await e(),n.ca.delete(1),await si(n)})}function sh(n,t){return t().catch(e=>ks(n,e,t))}async function ii(n){const t=$(n),e=Fe(t);let r=t.ia.length>0?t.ia[t.ia.length-1].batchId:mo;for(;z_(t);)try{const s=await O_(t.localStore,r);if(s===null){t.ia.length===0&&e.Xt();break}r=s.batchId,G_(t,s)}catch(s){await ks(t,s)}ih(t)&&oh(t)}function z_(n){return fn(n)&&n.ia.length<10}function G_(n,t){n.ia.push(t);const e=Fe(n);e.Jt()&&e.Rn&&e.In(t.mutations)}function ih(n){return fn(n)&&!Fe(n).Ht()&&n.ia.length>0}function oh(n){Fe(n).start()}async function H_(n){Fe(n).dn()}async function W_(n){const t=Fe(n);for(const e of n.ia)t.In(e.mutations)}async function Q_(n,t,e){const r=n.ia.shift(),s=Fo.from(r,t,e);await sh(n,()=>n.remoteSyncer.applySuccessfulWrite(s)),await ii(n)}async function K_(n,t){t&&Fe(n).Rn&&await async function(r,s){if(function(a){return Ap(a)&&a!==x.ABORTED}(s.code)){const o=r.ia.shift();Fe(r).Zt(),await sh(r,()=>r.remoteSyncer.rejectFailedWrite(o.batchId,s)),await ii(r)}}(n,t),ih(n)&&oh(n)}async function Yu(n,t){const e=$(n);e.asyncQueue.verifyOperationInProgress(),O(he,"RemoteStore received new credentials");const r=fn(e);e.ca.add(3),await jr(e),r&&e.ha.set("Unknown"),await e.remoteSyncer.handleCredentialChange(t),e.ca.delete(3),await si(e)}async function X_(n,t){const e=$(n);t?(e.ca.delete(2),await si(e)):t||(e.ca.add(2),await jr(e),e.ha.set("Unknown"))}function Ln(n){return n.Pa||(n.Pa=function(e,r,s){const o=$(e);return o.mn(),new um(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,s)}(n.datastore,n.asyncQueue,{ut:B_.bind(null,n),lt:j_.bind(null,n),ht:q_.bind(null,n),hn:$_.bind(null,n)}),n.la.push(async t=>{t?(n.Pa.Zt(),Wo(n)?Ho(n):n.ha.set("Unknown")):(await n.Pa.stop(),rh(n))})),n.Pa}function Fe(n){return n.Ra||(n.Ra=function(e,r,s){const o=$(e);return o.mn(),new cm(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,s)}(n.datastore,n.asyncQueue,{ut:()=>Promise.resolve(),lt:H_.bind(null,n),ht:K_.bind(null,n),An:W_.bind(null,n),Vn:Q_.bind(null,n)}),n.la.push(async t=>{t?(n.Ra.Zt(),await ii(n)):(await n.Ra.stop(),n.ia.length>0&&(O(he,`Stopping write stream with ${n.ia.length} pending writes`),n.ia=[]))})),n.Ra}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qo{constructor(t){this.observer=t,this.muted=!1}next(t){this.muted||this.observer.next&&this.Ia(this.observer.next,t)}error(t){this.muted||(this.observer.error?this.Ia(this.observer.error,t):ye("Uncaught Error in snapshot listener:",t.toString()))}Aa(){this.muted=!0}Ia(t,e){setTimeout(()=>{this.muted||t(e)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ko{constructor(t,e,r,s,o){this.asyncQueue=t,this.timerId=e,this.targetTimeMs=r,this.op=s,this.removalCallback=o,this.deferred=new me,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(a=>{})}get promise(){return this.deferred.promise}static createAndSchedule(t,e,r,s,o){const a=Date.now()+r,c=new Ko(t,e,a,s,o);return c.start(r),c}start(t){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),t)}skipDelay(){return this.handleDelayElapsed()}cancel(t){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new L(x.CANCELLED,"Operation cancelled"+(t?": "+t:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(t=>this.deferred.resolve(t))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Xo(n,t){if(ye("AsyncQueue",`${t}: ${n}`),xn(n))return new L(x.UNAVAILABLE,`${t}: ${n}`);throw n}class Zu{constructor(){this.activeTargetIds=Sp()}La(t){this.activeTargetIds=this.activeTargetIds.add(t)}Ba(t){this.activeTargetIds=this.activeTargetIds.delete(t)}Na(){const t={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(t)}}class J_{constructor(){this.du=new Zu,this.fu={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(t){}updateMutationState(t,e,r){}addLocalQueryTarget(t,e=!0){return e&&this.du.La(t),this.fu[t]||"not-current"}updateQueryState(t,e,r){this.fu[t]=e}removeLocalQueryTarget(t){this.du.Ba(t)}isLocalQueryTarget(t){return this.du.activeTargetIds.has(t)}clearQueryState(t){delete this.fu[t]}getAllActiveQueryTargets(){return this.du.activeTargetIds}isActiveQueryTarget(t){return this.du.activeTargetIds.has(t)}start(){return this.du=new Zu,Promise.resolve()}handleUserChange(t,e,r){}setOnlineState(t){}shutdown(){}writeSequenceNumber(t){}notifyBundleLoaded(t){}}function Ui(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ye{static emptySet(t){return new Ye(t.comparator)}constructor(t){this.comparator=t?(e,r)=>t(e,r)||F.comparator(e.key,r.key):(e,r)=>F.comparator(e.key,r.key),this.keyedMap=yn(),this.sortedSet=new rt(this.comparator)}has(t){return this.keyedMap.get(t)!=null}get(t){return this.keyedMap.get(t)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(t){const e=this.keyedMap.get(t);return e?this.sortedSet.indexOf(e):-1}get size(){return this.sortedSet.size}forEach(t){this.sortedSet.inorderTraversal((e,r)=>(t(e),!1))}add(t){const e=this.delete(t.key);return e.copy(e.keyedMap.insert(t.key,t),e.sortedSet.insert(t,null))}delete(t){const e=this.get(t);return e?this.copy(this.keyedMap.remove(t),this.sortedSet.remove(e)):this}isEqual(t){if(!(t instanceof Ye)||this.size!==t.size)return!1;const e=this.sortedSet.getIterator(),r=t.sortedSet.getIterator();for(;e.hasNext();){const s=e.getNext().key,o=r.getNext().key;if(!s.isEqual(o))return!1}return!0}toString(){const t=[];return this.forEach(e=>{t.push(e.toString())}),t.length===0?"DocumentSet ()":`DocumentSet (
  `+t.join(`  
`)+`
)`}copy(t,e){const r=new Ye;return r.comparator=this.comparator,r.keyedMap=t,r.sortedSet=e,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tc{constructor(){this.mu=new rt(F.comparator)}track(t){const e=t.doc.key,r=this.mu.get(e);r?t.type!==0&&r.type===3?this.mu=this.mu.insert(e,t):t.type===3&&r.type!==1?this.mu=this.mu.insert(e,{type:r.type,doc:t.doc}):t.type===2&&r.type===2?this.mu=this.mu.insert(e,{type:2,doc:t.doc}):t.type===2&&r.type===0?this.mu=this.mu.insert(e,{type:0,doc:t.doc}):t.type===1&&r.type===0?this.mu=this.mu.remove(e):t.type===1&&r.type===2?this.mu=this.mu.insert(e,{type:1,doc:r.doc}):t.type===0&&r.type===1?this.mu=this.mu.insert(e,{type:2,doc:t.doc}):B(63341,{ye:t,pu:r}):this.mu=this.mu.insert(e,t)}gu(){const t=[];return this.mu.inorderTraversal((e,r)=>{t.push(r)}),t}}class bn{constructor(t,e,r,s,o,a,c,h,f){this.query=t,this.docs=e,this.oldDocs=r,this.docChanges=s,this.mutatedKeys=o,this.fromCache=a,this.syncStateChanged=c,this.excludesMetadataChanges=h,this.hasCachedResults=f}static fromInitialDocuments(t,e,r,s,o){const a=[];return e.forEach(c=>{a.push({type:0,doc:c})}),new bn(t,e,Ye.emptySet(e),a,r,s,!0,!1,o)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(t){if(!(this.fromCache===t.fromCache&&this.hasCachedResults===t.hasCachedResults&&this.syncStateChanged===t.syncStateChanged&&this.mutatedKeys.isEqual(t.mutatedKeys)&&ni(this.query,t.query)&&this.docs.isEqual(t.docs)&&this.oldDocs.isEqual(t.oldDocs)))return!1;const e=this.docChanges,r=t.docChanges;if(e.length!==r.length)return!1;for(let s=0;s<e.length;s++)if(e[s].type!==r[s].type||!e[s].doc.isEqual(r[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y_{constructor(){this.yu=void 0,this.wu=[]}bu(){return this.wu.some(t=>t.vu())}}class Z_{constructor(){this.queries=ec(),this.onlineState="Unknown",this.Su=new Set}terminate(){(function(e,r){const s=$(e),o=s.queries;s.queries=ec(),o.forEach((a,c)=>{for(const h of c.wu)h.onError(r)})})(this,new L(x.ABORTED,"Firestore shutting down"))}}function ec(){return new ln(n=>Wl(n),ni)}async function Jo(n,t){const e=$(n);let r=3;const s=t.query;let o=e.queries.get(s);o?!o.bu()&&t.vu()&&(r=2):(o=new Y_,r=t.vu()?0:1);try{switch(r){case 0:o.yu=await e.onListen(s,!0);break;case 1:o.yu=await e.onListen(s,!1);break;case 2:await e.onFirstRemoteStoreListen(s)}}catch(a){const c=Xo(a,`Initialization of query '${yt(t.query)?ge(t.query):cr(t.query)}' failed`);return void t.onError(c)}e.queries.set(s,o),o.wu.push(t),t.Du(e.onlineState),o.yu&&t.xu(o.yu)&&Zo(e)}async function Yo(n,t){const e=$(n),r=t.query;let s=3;const o=e.queries.get(r);if(o){const a=o.wu.indexOf(t);a>=0&&(o.wu.splice(a,1),o.wu.length===0?s=t.vu()?0:1:!o.bu()&&t.vu()&&(s=2))}switch(s){case 0:return e.queries.delete(r),e.onUnlisten(r,!0);case 1:return e.queries.delete(r),e.onUnlisten(r,!1);case 2:return e.onLastRemoteStoreUnlisten(r);default:return}}function ty(n,t){const e=$(n);let r=!1;for(const s of t){const o=s.query,a=e.queries.get(o);if(a){for(const c of a.wu)c.xu(s)&&(r=!0);a.yu=s}}r&&Zo(e)}function ey(n,t,e){const r=$(n),s=r.queries.get(t);if(s)for(const o of s.wu)o.onError(e);r.queries.delete(t)}function Zo(n){n.Su.forEach(t=>{t.next()})}var io;(function(n){n.Default="default",n.Cache="cache"})(io||(io={}));class ta{constructor(t,e,r){this.query=t,this.Cu=e,this.Fu=!1,this.Ou=null,this.onlineState="Unknown",this.options=r||{}}xu(t){if(!this.options.includeMetadataChanges){const r=[];for(const s of t.docChanges)s.type!==3&&r.push(s);t=new bn(t.query,t.docs,t.oldDocs,r,t.mutatedKeys,t.fromCache,t.syncStateChanged,!0,t.hasCachedResults)}let e=!1;return this.Fu?this.Mu(t)&&(this.Cu.next(t),e=!0):this.Nu(t,this.onlineState)&&(this.Lu(t),e=!0),this.Ou=t,e}onError(t){this.Cu.error(t)}Du(t){this.onlineState=t;let e=!1;return this.Ou&&!this.Fu&&this.Nu(this.Ou,t)&&(this.Lu(this.Ou),e=!0),e}Nu(t,e){if(!t.fromCache||!this.vu())return!0;const r=e!=="Offline";return(!this.options.waitForSyncWhenOnline||!r)&&(!t.docs.isEmpty()||t.hasCachedResults||e==="Offline")}Mu(t){if(t.docChanges.length>0)return!0;const e=this.Ou&&this.Ou.hasPendingWrites!==t.hasPendingWrites;return!(!t.syncStateChanged&&!e)&&this.options.includeMetadataChanges===!0}Lu(t){t=bn.fromInitialDocuments(t.query,t.docs,t.mutatedKeys,t.fromCache,t.hasCachedResults),this.Fu=!0,this.Cu.next(t)}vu(){return this.options.source!==io.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ah{constructor(t){this.key=t}}class uh{constructor(t){this.key=t}}class ny{constructor(t,e){this.query=t,this.Gu=e,this.zu=null,this.hasCachedResults=!1,this.current=!1,this.ju=H(),this.mutatedKeys=H(),this.Hu=yt(t)?no(t):To(t),this.Ju=new Ye(this.Hu)}get Yu(){return this.Gu}Zu(t,e){const r=e?e.Xu:new tc,s=e?e.Ju:this.Ju;let o=e?e.mutatedKeys:this.mutatedKeys,a=s,c=!1;const[h,f]=this.ec(this.query,s);t.inorderTraversal((m,I)=>{const b=s.get(m),C=d_(this.query,I)?I:null,M=!!b&&this.mutatedKeys.has(b.key),k=!!C&&(C.hasLocalMutations||this.mutatedKeys.has(C.key)&&C.hasCommittedMutations);let z=!1;b&&C?b.data.isEqual(C.data)?M!==k&&(r.track({type:3,doc:C}),z=!0):this.tc(b,C)||(r.track({type:2,doc:C}),z=!0,(h&&this.Hu(C,h)>0||f&&this.Hu(C,f)<0)&&(c=!0)):!b&&C?(r.track({type:0,doc:C}),z=!0):b&&!C&&(r.track({type:1,doc:b}),z=!0,(h||f)&&(c=!0)),z&&(C?(a=a.add(C),o=k?o.add(m):o.delete(m)):(a=a.delete(m),o=o.delete(m)))});const p=this.nc(this.query);if(p)if(yt(this.query)){const m=[];a.forEach(C=>m.push(C));const I=Jl(this.query,m);let b=new Ye(no(this.query));for(const C of I)b=b.add(C);a.forEach(C=>{b.has(C.key)||(o=o.delete(C.key),r.track({type:1,doc:C}))}),a=b}else{const m=this.rc(this.query);for(;a.size>p;){const I=m==="F"?a.last():a.first();a=a.delete(I.key),o=o.delete(I.key),r.track({type:1,doc:I})}}return{Ju:a,Xu:r,Fo:c,mutatedKeys:o}}nc(t){var e;return yt(t)?(e=Mi(t))==null?void 0:e.limit:t.limit||void 0}rc(t){if(yt(t)){const e=Mi(t);return e&&e.limit<0?"L":"F"}return t.limitType}ec(t,e){var r;if(yt(t)){const s=(r=Mi(t))==null?void 0:r.limit;return[e.size===s?e.last():null,null]}return[t.limitType==="F"&&e.size===this.nc(this.query)?e.last():null,t.limitType==="L"&&e.size===this.nc(this.query)?e.first():null]}tc(t,e){return t.hasLocalMutations&&e.hasCommittedMutations&&!e.hasLocalMutations}applyChanges(t,e,r,s){const o=this.Ju;this.Ju=t.Ju,this.mutatedKeys=t.mutatedKeys;const a=t.Xu.gu();a.sort((p,m)=>function(b,C){const M=k=>{switch(k){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return B(20277,{ye:k})}};return M(b)-M(C)}(p.type,m.type)||this.Hu(p.doc,m.doc)),this.sc(r),s=s??!1;const c=e&&!s?this._c():[],h=this.ju.size===0&&this.current&&!s?1:0,f=h!==this.zu;return this.zu=h,a.length!==0||f?{snapshot:new bn(this.query,t.Ju,o,a,t.mutatedKeys,h===0,f,!1,!!r&&r.resumeToken.approximateByteSize()>0),oc:c}:{oc:c}}Du(t){return this.current&&t==="Offline"?(this.current=!1,this.applyChanges({Ju:this.Ju,Xu:new tc,mutatedKeys:this.mutatedKeys,Fo:!1},!1)):{oc:[]}}ac(t){return!this.Gu.has(t)&&!!this.Ju.has(t)&&!this.Ju.get(t).hasLocalMutations}sc(t){t&&(t.addedDocuments.forEach(e=>this.Gu=this.Gu.add(e)),t.modifiedDocuments.forEach(e=>{}),t.removedDocuments.forEach(e=>this.Gu=this.Gu.delete(e)),this.current=t.current)}_c(){if(!this.current)return[];const t=this.ju;this.ju=H(),this.Ju.forEach(r=>{this.ac(r.key)&&(this.ju=this.ju.add(r.key))});const e=[];return t.forEach(r=>{this.ju.has(r)||e.push(new uh(r))}),this.ju.forEach(r=>{t.has(r)||e.push(new ah(r))}),e}uc(t){this.Gu=t.Wo,this.ju=H();const e=this.Zu(t.documents);return this.applyChanges(e,!0)}cc(){return bn.fromInitialDocuments(this.query,this.Ju,this.mutatedKeys,this.zu===0,this.hasCachedResults)}}const ea="SyncEngine";class ry{constructor(t,e,r){this.query=t,this.targetId=e,this.view=r}}class sy{constructor(t){this.key=t,this.lc=!1}}class iy{constructor(t,e,r,s,o,a){this.localStore=t,this.remoteStore=e,this.eventManager=r,this.sharedClientState=s,this.currentUser=o,this.maxConcurrentLimboResolutions=a,this.Ec={},this.hc=new ln(c=>Wl(c),ni),this.Tc=new Map,this.Pc=new Set,this.Rc=new rt(F.comparator),this.Ic=new Map,this.Ac=new Bo,this.Vc={},this.dc=new Map,this.fc=Ue.ws(),this.onlineState="Unknown",this.mc=void 0}get isPrimaryClient(){return this.mc===!0}}async function oy(n,t,e=!0){const r=ph(n);let s;const o=r.hc.get(t);return o?(r.sharedClientState.addLocalQueryTarget(o.targetId),s=o.view.cc()):s=await ch(r,t,e,!0),s}async function ay(n,t){const e=ph(n);await ch(e,t,!0,!1)}async function ch(n,t,e,r){const s=await L_(n.localStore,yt(t)?t:oe(t)),o=s.targetId,a=n.sharedClientState.addLocalQueryTarget(o,e);let c;return r&&(c=await uy(n,t,o,a==="current",s.resumeToken)),n.isPrimaryClient&&e&&eh(n.remoteStore,s),c}async function uy(n,t,e,r,s){n.gc=(m,I,b)=>async function(M,k,z,W){let J=k.view.Zu(z);J.Fo&&(J=await Ju(M.localStore,k.query,!1).then(({documents:w})=>k.view.Zu(w,J)));const Z=W&&W.targetChanges.get(k.targetId),ut=W&&W.targetMismatches.get(k.targetId)!=null,lt=k.view.applyChanges(J,M.isPrimaryClient,Z,ut);return rc(M,k.targetId,lt.oc),lt.snapshot}(n,m,I,b);const o=await Ju(n.localStore,t,!0),a=new ny(t,o.Wo),c=a.Zu(o.documents),h=Ur.createSynthesizedTargetChangeForCurrentChange(e,r&&n.onlineState!=="Offline",s),f=a.applyChanges(c,n.isPrimaryClient,h);rc(n,e,f.oc);const p=new ry(t,e,a);return n.hc.set(t,p),n.Tc.has(e)?n.Tc.get(e).push(t):n.Tc.set(e,[t]),f.snapshot}async function cy(n,t,e){const r=$(n),s=r.hc.get(t),o=r.Tc.get(s.targetId);if(o.length>1)return r.Tc.set(s.targetId,o.filter(a=>!ni(a,t))),void r.hc.delete(t);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(s.targetId),r.sharedClientState.isActiveQueryTarget(s.targetId)||await ro(r.localStore,s.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(s.targetId),e&&zo(r.remoteStore,s.targetId),oo(r,s.targetId)}).catch(Cn)):(oo(r,s.targetId),await ro(r.localStore,s.targetId,!0))}async function ly(n,t){const e=$(n),r=e.hc.get(t),s=e.Tc.get(r.targetId);e.isPrimaryClient&&s.length===1&&(e.sharedClientState.removeLocalQueryTarget(r.targetId),zo(e.remoteStore,r.targetId))}async function hy(n,t,e){const r=yy(n);try{const s=await function(a,c){const h=$(a),f=nt.now(),p=c.reduce((b,C)=>b.add(C.key),H());let m,I;return h.persistence.runTransaction("Locally write mutations","readwrite",b=>{let C=Ot(),M=H();return h.Uo.getEntries(b,p).next(k=>{C=k,C.forEach((z,W)=>{W.isValidDocument()||(M=M.add(z))})}).next(()=>h.localDocuments.getOverlayedDocuments(b,C)).next(k=>{m=k;const z=[];for(const W of c){const J=np(W,m.get(W.key).overlayedDocument);J!=null&&z.push(new cn(W.key,J,Hc(J.value.mapValue),ie.exists(!0)))}return h.mutationQueue.addMutationBatch(b,f,z,c)}).next(k=>{I=k;const z=k.applyToLocalDocumentSet(m,M);return h.documentOverlayCache.saveOverlays(b,k.batchId,z)})}).then(()=>({batchId:I.batchId,changes:ll(m)}))}(r.localStore,t);r.sharedClientState.addPendingMutation(s.batchId),function(a,c,h){let f=a.Vc[a.currentUser.toKey()];f||(f=new rt(Q)),f=f.insert(c,h),a.Vc[a.currentUser.toKey()]=f}(r,s.batchId,e),await qr(r,s.changes),await ii(r.remoteStore)}catch(s){const o=Xo(s,"Failed to persist write");e.reject(o)}}async function lh(n,t){const e=$(n);try{const r=await D_(e.localStore,t);t.targetChanges.forEach((s,o)=>{const a=e.Ic.get(o);a&&(U(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1,22616),s.addedDocuments.size>0?a.lc=!0:s.modifiedDocuments.size>0?U(a.lc,14607):s.removedDocuments.size>0&&(U(a.lc,42227),a.lc=!1))}),await qr(e,r,t)}catch(r){await Cn(r)}}function nc(n,t,e){const r=$(n);if(r.isPrimaryClient&&e===0||!r.isPrimaryClient&&e===1){const s=[];r.hc.forEach((o,a)=>{const c=a.view.Du(t);c.snapshot&&s.push(c.snapshot)}),function(a,c){const h=$(a);h.onlineState=c;let f=!1;h.queries.forEach((p,m)=>{for(const I of m.wu)I.Du(c)&&(f=!0)}),f&&Zo(h)}(r.eventManager,t),s.length&&r.Ec.hn(s),r.onlineState=t,r.isPrimaryClient&&r.sharedClientState.setOnlineState(t)}}async function fy(n,t,e){const r=$(n);r.sharedClientState.updateQueryState(t,"rejected",e);const s=r.Ic.get(t),o=s&&s.key;if(o){let a=new rt(F.comparator);a=a.insert(o,Pt.newNoDocument(o,q.min()));const c=H().add(o),h=new Mr(q.min(),new Map,new rt(Q),a,Ot(),c);await lh(r,h),r.Rc=r.Rc.remove(o),r.Ic.delete(t),na(r)}else await ro(r.localStore,t,!1).then(()=>oo(r,t,e)).catch(Cn)}async function dy(n,t){const e=$(n),r=t.batch.batchId;try{const s=await N_(e.localStore,t);fh(e,r,null),hh(e,r),e.sharedClientState.updateMutationState(r,"acknowledged"),await qr(e,s)}catch(s){await Cn(s)}}async function py(n,t,e){const r=$(n);try{const s=await function(a,c){const h=$(a);return h.persistence.runTransaction("Reject batch","readwrite-primary",f=>{let p;return h.mutationQueue.lookupMutationBatch(f,c).next(m=>(U(m!==null,37113),p=m.keys(),h.mutationQueue.removeMutationBatch(f,m))).next(()=>h.mutationQueue.performConsistencyCheck(f)).next(()=>h.documentOverlayCache.removeOverlaysForBatchId(f,p,c)).next(()=>h.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(f,p)).next(()=>h.localDocuments.getDocuments(f,p))})}(r.localStore,t);fh(r,t,e),hh(r,t),r.sharedClientState.updateMutationState(t,"rejected",e),await qr(r,s)}catch(s){await Cn(s)}}function hh(n,t){(n.dc.get(t)||[]).forEach(e=>{e.resolve()}),n.dc.delete(t)}function fh(n,t,e){const r=$(n);let s=r.Vc[r.currentUser.toKey()];if(s){const o=s.get(t);o&&(e?o.reject(e):o.resolve(),s=s.remove(t)),r.Vc[r.currentUser.toKey()]=s}}function oo(n,t,e=null){n.sharedClientState.removeLocalQueryTarget(t);for(const r of n.Tc.get(t))n.hc.delete(r),e&&n.Ec.yc(r,e);n.Tc.delete(t),n.isPrimaryClient&&n.Ac.Xs(t).forEach(r=>{n.Ac.containsKey(r)||dh(n,r)})}function dh(n,t){n.Pc.delete(t.path.canonicalString());const e=n.Rc.get(t);e!==null&&(zo(n.remoteStore,e),n.Rc=n.Rc.remove(t),n.Ic.delete(e),na(n))}function rc(n,t,e){for(const r of e)r instanceof ah?(n.Ac.addReference(r.key,t),my(n,r)):r instanceof uh?(O(ea,"Document no longer in limbo: "+r.key),n.Ac.removeReference(r.key,t),n.Ac.containsKey(r.key)||dh(n,r.key)):B(19791,{wc:r})}function my(n,t){const e=t.key,r=e.path.canonicalString();n.Rc.get(e)||n.Pc.has(r)||(O(ea,"New document in limbo: "+e),n.Pc.add(r),na(n))}function na(n){for(;n.Pc.size>0&&n.Rc.size<n.maxConcurrentLimboResolutions;){const t=n.Pc.values().next().value;n.Pc.delete(t);const e=new F(Y.fromString(t)),r=n.fc.next();n.Ic.set(r,new sy(e)),n.Rc=n.Rc.insert(e,r),eh(n.remoteStore,new pe(oe(Gs(e.path)),r,"TargetPurposeLimboResolution",Qs.yn))}}async function qr(n,t,e){const r=$(n),s=[],o=[],a=[];r.hc.isEmpty()||(r.hc.forEach((c,h)=>{a.push(r.gc(h,t,e).then(f=>{var p;if((f||e)&&r.isPrimaryClient){const m=f?!f.fromCache:(p=e==null?void 0:e.targetChanges.get(h.targetId))==null?void 0:p.current;r.sharedClientState.updateQueryState(h.targetId,m?"current":"not-current")}if(f){s.push(f);const m=qo.fo(h.targetId,f);o.push(m)}}))}),await Promise.all(a),r.Ec.hn(s),await async function(h,f){const p=$(h);try{await p.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>S.forEach(f,I=>S.forEach(I.Ao,b=>p.persistence.referenceDelegate.addReference(m,I.targetId,b)).next(()=>S.forEach(I.Vo,b=>p.persistence.referenceDelegate.removeReference(m,I.targetId,b)))))}catch(m){if(!xn(m))throw m;O($o,"Failed to update sequence numbers: "+m)}for(const m of f){const I=m.targetId;if(!m.fromCache){const b=p.No.get(I),C=b.snapshotVersion,M=b.withLastLimboFreeSnapshotVersion(C);p.No=p.No.insert(I,M)}}}(r.localStore,o))}async function gy(n,t){const e=$(n);if(!e.currentUser.isEqual(t)){O(ea,"User change. New user:",t.toKey());const r=await Zl(e.localStore,t);e.currentUser=t,function(o,a){o.dc.forEach(c=>{c.forEach(h=>{h.reject(new L(x.CANCELLED,a))})}),o.dc.clear()}(e,"'waitForPendingWrites' promise is rejected due to a user change."),e.sharedClientState.handleUserChange(t,r.removedBatchIds,r.addedBatchIds),await qr(e,r.qo)}}function _y(n,t){const e=$(n),r=e.Ic.get(t);if(r&&r.lc)return H().add(r.key);{let s=H();const o=e.Tc.get(t);if(!o)return s;for(const a of o??[]){const c=e.hc.get(a);s=s.unionWith(c.view.Yu)}return s}}function ph(n){const t=$(n);return t.remoteStore.remoteSyncer.applyRemoteEvent=lh.bind(null,t),t.remoteStore.remoteSyncer.getRemoteKeysForTarget=_y.bind(null,t),t.remoteStore.remoteSyncer.rejectListen=fy.bind(null,t),t.Ec.hn=ty.bind(null,t.eventManager),t.Ec.yc=ey.bind(null,t.eventManager),t}function yy(n){const t=$(n);return t.remoteStore.remoteSyncer.applySuccessfulWrite=dy.bind(null,t),t.remoteStore.remoteSyncer.rejectFailedWrite=py.bind(null,t),t}class Os{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(t){this.serializer=Ws(t.databaseInfo.databaseId),this.sharedClientState=this.vc(t),this.persistence=this.Sc(t),await this.persistence.start(),this.localStore=this.Dc(t),this.gcScheduler=this.xc(t,this.localStore),this.indexBackfillerScheduler=this.Cc(t,this.localStore)}xc(t,e){return null}Cc(t,e){return null}Dc(t){return x_(this.persistence,new b_,t.initialUser,this.serializer)}Sc(t){return new Yl(jo.w_,this.serializer)}vc(t){return new J_}async terminate(){var t,e;(t=this.gcScheduler)==null||t.stop(),(e=this.indexBackfillerScheduler)==null||e.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Os.provider={build:()=>new Os};class Ey extends Os{constructor(t){super(),this.cacheSizeBytes=t}xc(t,e){U(this.persistence.referenceDelegate instanceof Ds,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new Tm(r,t.asyncQueue,e)}Sc(t){const e=this.cacheSizeBytes!==void 0?kt.withCacheSize(this.cacheSizeBytes):kt.DEFAULT;return new Yl(r=>Ds.w_(r,e),this.serializer)}}class ao{async initialize(t,e){this.localStore||(this.localStore=t.localStore,this.sharedClientState=t.sharedClientState,this.datastore=this.createDatastore(e),this.remoteStore=this.createRemoteStore(e),this.eventManager=this.createEventManager(e),this.syncEngine=this.createSyncEngine(e,!t.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>nc(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=gy.bind(null,this.syncEngine),await X_(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(t){return function(){return new Z_}()}createDatastore(t){const e=Ws(t.databaseInfo.databaseId),r=am(t.databaseInfo);return fm(t.authCredentials,t.appCheckCredentials,r,e)}createRemoteStore(t){return function(r,s,o,a,c){return new F_(r,s,o,a,c)}(this.localStore,this.datastore,t.asyncQueue,e=>nc(this.syncEngine,e,0),function(){return Bu.Je()?new Bu:new rm}())}createSyncEngine(t,e){return function(s,o,a,c,h,f,p){const m=new iy(s,o,a,c,h,f);return p&&(m.mc=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,t.initialUser,t.maxConcurrentLimboResolutions,e)}async terminate(){var t,e;await async function(s){const o=$(s);O(he,"RemoteStore shutting down."),o.ca.add(5),await jr(o),o.Ea.shutdown(),o.ha.set("Unknown")}(this.remoteStore),(t=this.datastore)==null||t.terminate(),(e=this.eventManager)==null||e.terminate()}}ao.provider={build:()=>new ao};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Be="FirestoreClient";class Ty{constructor(t,e,r,s,o){this.authCredentials=t,this.appCheckCredentials=e,this.asyncQueue=r,this._databaseInfo=s,this.user=Vt.UNAUTHENTICATED,this.clientId=fo.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=o,this.authCredentials.start(r,async a=>{O(Be,"Received user=",a.uid),await this.authCredentialListener(a),this.user=a}),this.appCheckCredentials.start(r,a=>(O(Be,"Received new app check token=",a),this.appCheckCredentialListener(a,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(t){this.authCredentialListener=t}setAppCheckTokenChangeListener(t){this.appCheckCredentialListener=t}terminate(){this.asyncQueue.enterRestrictedMode();const t=new me;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),t.resolve()}catch(e){const r=Xo(e,"Failed to shutdown persistence");t.reject(r)}}),t.promise}}async function Fi(n,t){n.asyncQueue.verifyOperationInProgress(),O(Be,"Initializing OfflineComponentProvider");const e=n.configuration;await t.initialize(e);let r=e.initialUser;n.setCredentialChangeListener(async s=>{r.isEqual(s)||(await Zl(t.localStore,s),r=s)}),t.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=t}async function sc(n,t){n.asyncQueue.verifyOperationInProgress();const e=await wy(n);O(Be,"Initializing OnlineComponentProvider"),await t.initialize(e,n.configuration),n.setCredentialChangeListener(r=>Yu(t.remoteStore,r)),n.setAppCheckTokenChangeListener((r,s)=>Yu(t.remoteStore,s)),n._onlineComponents=t}async function wy(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){O(Be,"Using user provided OfflineComponentProvider");try{await Fi(n,n._uninitializedComponentsProvider._offline)}catch(t){const e=t;if(!function(s){return s.name==="FirebaseError"?s.code===x.FAILED_PRECONDITION||s.code===x.UNIMPLEMENTED:!(typeof DOMException<"u"&&s instanceof DOMException)||s.code===22||s.code===20||s.code===11}(e))throw e;Zt("Error using user provided cache. Falling back to memory cache: "+e),await Fi(n,new Os)}}else O(Be,"Using default OfflineComponentProvider"),await Fi(n,new Ey(void 0));return n._offlineComponents}async function mh(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(O(Be,"Using user provided OnlineComponentProvider"),await sc(n,n._uninitializedComponentsProvider._online)):(O(Be,"Using default OnlineComponentProvider"),await sc(n,new ao))),n._onlineComponents}function vy(n){return mh(n).then(t=>t.syncEngine)}async function Ls(n){const t=await mh(n),e=t.eventManager;return e.onListen=oy.bind(null,t.syncEngine),e.onUnlisten=cy.bind(null,t.syncEngine),e.onFirstRemoteStoreListen=ay.bind(null,t.syncEngine),e.onLastRemoteStoreUnlisten=ly.bind(null,t.syncEngine),e}function Iy(n,t,e,r){const s=new Qo(r),o=new ta(t,s,e);return n.asyncQueue.enqueueAndForget(async()=>Jo(await Ls(n),o)),()=>{s.Aa(),n.asyncQueue.enqueueAndForget(async()=>Yo(await Ls(n),o))}}function Ay(n,t,e={}){const r=new me;return n.asyncQueue.enqueueAndForget(async()=>function(o,a,c,h,f){const p=new Qo({next:I=>{p.Aa(),a.enqueueAndForget(()=>Yo(o,m));const b=I.docs.has(c);!b&&I.fromCache?f.reject(new L(x.UNAVAILABLE,"Failed to get document because the client is offline.")):b&&I.fromCache&&h&&h.source==="server"?f.reject(new L(x.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):f.resolve(I)},error:I=>f.reject(I)}),m=new ta(Gs(c.path),p,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return Jo(o,m)}(await Ls(n),n.asyncQueue,t,e,r)),r.promise}function Ry(n,t,e={}){const r=new me;return n.asyncQueue.enqueueAndForget(async()=>function(o,a,c,h,f){const p=new Qo({next:I=>{p.Aa(),a.enqueueAndForget(()=>Yo(o,m)),I.fromCache&&h.source==="server"?f.reject(new L(x.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):f.resolve(I)},error:I=>f.reject(I)}),m=new ta(c instanceof hr?s_(c):c,p,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return Jo(o,m)}(await Ls(n),n.asyncQueue,t,e,r)),r.promise}function Vy(n,t){const e=new me;return n.asyncQueue.enqueueAndForget(async()=>hy(await vy(n),t,e)),e.promise}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ic="AsyncQueue";class oc{constructor(t=Promise.resolve()){this.Wc=[],this.Qc=!1,this.Gc=[],this.zc=null,this.jc=!1,this.Hc=!1,this.Jc=[],this.jt=new Rl(this,"async_queue_retry"),this.Yc=()=>{const r=Ui();r&&O(ic,"Visibility state changed to "+r.visibilityState),this.jt.qt()},this.Zc=t;const e=Ui();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.Yc)}get isShuttingDown(){return this.Qc}enqueueAndForget(t){this.enqueue(t)}enqueueAndForgetEvenWhileRestricted(t){this.Xc(),this.el(t)}enterRestrictedMode(t){if(!this.Qc){this.Qc=!0,this.Hc=t||!1;const e=Ui();e&&typeof e.removeEventListener=="function"&&e.removeEventListener("visibilitychange",this.Yc)}}enqueue(t){if(this.Xc(),this.Qc)return new Promise(()=>{});const e=new me;return this.el(()=>this.Qc&&this.Hc?Promise.resolve():(t().then(e.resolve,e.reject),e.promise)).then(()=>e.promise)}enqueueRetryable(t){this.enqueueAndForget(()=>(this.Wc.push(t),this.tl()))}async tl(){if(this.Wc.length!==0){try{await this.Wc[0](),this.Wc.shift(),this.jt.reset()}catch(t){if(!xn(t))throw t;O(ic,"Operation failed with retryable error: "+t)}this.Wc.length>0&&this.jt.Ut(()=>this.tl())}}el(t){const e=this.Zc.then(()=>(this.jc=!0,t().catch(r=>{throw this.zc=r,this.jc=!1,ye("INTERNAL UNHANDLED ERROR: ",ac(r)),r}).then(r=>(this.jc=!1,r))));return this.Zc=e,e}enqueueAfterDelay(t,e,r){this.Xc(),this.Jc.indexOf(t)>-1&&(e=0);const s=Ko.createAndSchedule(this,t,e,r,o=>this.nl(o));return this.Gc.push(s),s}Xc(){this.zc&&B(47125,{rl:ac(this.zc)})}verifyOperationInProgress(){}async il(){let t;do t=this.Zc,await t;while(t!==this.Zc)}sl(t){for(const e of this.Gc)if(e.timerId===t)return!0;return!1}_l(t){return this.il().then(()=>{this.Gc.sort((e,r)=>e.targetTimeMs-r.targetTimeMs);for(const e of this.Gc)if(e.skipDelay(),t!=="all"&&e.timerId===t)break;return this.il()})}ol(t){this.Jc.push(t)}nl(t){const e=this.Gc.indexOf(t);this.Gc.splice(e,1)}}function ac(n){let t=n.message||"";return n.stack&&(t=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),t}class sn extends Ks{constructor(t,e,r,s){super(t,e,r,s),this.type="firestore",this._queue=new oc,this._persistenceKey=(s==null?void 0:s.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const t=this._firestoreClient.terminate();this._queue=new oc(t),this._firestoreClient=void 0,await t}}}function oT(n,t){const e=typeof n=="object"?n:Pc(),r=typeof n=="string"?n:vs,s=Ac(e,"firestore").getImmediate({identifier:r});if(!s._initialized){const o=yc("firestore");o&&Im(s,...o)}return s}function oi(n){if(n._terminated)throw new L(x.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||Py(n),n._firestoreClient}function Py(n){var r,s,o,a;const t=n._freezeSettings(),e=pm(n._databaseId,((r=n._app)==null?void 0:r.options.appId)||"",n._persistenceKey,(s=n._app)==null?void 0:s.options.apiKey,t);n._componentsProvider||(o=t.localCache)!=null&&o._offlineComponentProvider&&((a=t.localCache)!=null&&a._onlineComponentProvider)&&(n._componentsProvider={_offline:t.localCache._offlineComponentProvider,_online:t.localCache._onlineComponentProvider}),n._firestoreClient=new Ty(n._authCredentials,n._appCheckCredentials,n._queue,e,n._componentsProvider&&function(h){const f=h==null?void 0:h._online.build();return{_offline:h==null?void 0:h._offline.build(f),_online:f}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class by{convertValue(t,e="none"){switch(mt(t)){case 0:return null;case 1:return t.booleanValue;case 2:return st(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(De(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 11:return this.convertObject(t.mapValue,e);case 10:return this.convertVectorValue(t.mapValue);default:throw B(62114,{value:t})}}convertObject(t,e){return this.convertObjectMap(t.fields,e)}convertObjectMap(t,e="none"){const r={};return un(t,(s,o)=>{r[s]=this.convertValue(o,e)}),r}convertVectorValue(t){var r,s,o;const e=(o=(s=(r=t.fields)==null?void 0:r[Er].arrayValue)==null?void 0:s.values)==null?void 0:o.map(a=>st(a.doubleValue));return new Lt(e)}convertGeoPoint(t){return new ue(st(t.latitude),st(t.longitude))}convertArray(t,e){return(t.values||[]).map(r=>this.convertValue(r,e))}convertServerTimestamp(t,e){switch(e){case"previous":const r=Or(t);return r==null?null:this.convertValue(r,e);case"estimate":return this.convertTimestamp(An(t));default:return null}}convertTimestamp(t){const e=Ne(t);return new nt(e.seconds,e.nanos)}convertDocumentKey(t,e){const r=Y.fromString(t);U(Tl(r),9688,{name:t});const s=new _r(r.get(1),r.get(3)),o=new F(r.popFirst(5));return s.isEqual(e)||ye(`Document ${o} contains a document reference within a different database (${s.projectId}/${s.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),o}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ra extends by{constructor(t){super(),this.firestore=t}convertBytes(t){return new Wt(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new ct(this.firestore,null,e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uc(n){return function(e,r){if(typeof e!="object"||e===null)return!1;const s=e;for(const o of r)if(o in s&&typeof s[o]=="function")return!0;return!1}(n,["next","error","complete"])}const cc="@firebase/firestore",lc="4.17.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let gh=class{constructor(t,e,r,s,o){this._firestore=t,this._userDataWriter=e,this._key=r,this._document=s,this._converter=o}get id(){return this._key.path.lastSegment()}get ref(){return new ct(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const t=new Sy(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var t;return((t=this._document)==null?void 0:t.data.clone().value.mapValue.fields)??void 0}get(t){if(this._document){const e=this._document.data.field(Xs("DocumentSnapshot.get",t));if(e!==null)return this._userDataWriter.convertValue(e)}}},Sy=class extends gh{data(){return super.data()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _h(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new L(x.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}function Cy(n,t,e){let r;return r=n?e&&(e.merge||e.mergeFields)?n.toFirestore(t,e):n.toFirestore(t):t,r}class ir{constructor(t,e){this.hasPendingWrites=t,this.fromCache=e}isEqual(t){return this.hasPendingWrites===t.hasPendingWrites&&this.fromCache===t.fromCache}}class Ze extends gh{constructor(t,e,r,s,o,a){super(t,e,r,s,a),this._firestore=t,this._firestoreImpl=t,this.metadata=o}exists(){return super.exists()}data(t={}){if(this._document){if(this._converter){const e=new ys(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(e,t)}return this._userDataWriter.convertValue(this._document.data.value,t.serverTimestamps)}}get(t,e={}){if(this._document){const r=this._document.data.field(Xs("DocumentSnapshot.get",t));if(r!==null)return this._userDataWriter.convertValue(r,e.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new L(x.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t=this._document,e={};return e.type=Ze._jsonSchemaVersion,e.bundle="",e.bundleSource="DocumentSnapshot",e.bundleName=this._key.toString(),!t||!t.isValidDocument()||!t.isFoundDocument()?e:(this._userDataWriter.convertObjectMap(t.data.value.mapValue.fields,"previous"),e.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),e)}}Ze._jsonSchemaVersion="firestore/documentSnapshot/1.0",Ze._jsonSchema={type:ft("string",Ze._jsonSchemaVersion),bundleSource:ft("string","DocumentSnapshot"),bundleName:ft("string"),bundle:ft("string")};class ys extends Ze{data(t={}){return super.data(t)}}class tn{constructor(t,e,r,s){this._firestore=t,this._userDataWriter=e,this._snapshot=s,this.metadata=new ir(s.hasPendingWrites,s.fromCache),this.query=r}get docs(){const t=[];return this.forEach(e=>t.push(e)),t}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(t,e){this._snapshot.docs.forEach(r=>{t.call(e,new ys(this._firestore,this._userDataWriter,r.key,r,new ir(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(t={}){const e=!!t.includeMetadataChanges;if(e&&this._snapshot.excludesMetadataChanges)throw new L(x.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===e||(this._cachedChanges=function(s,o){if(s._snapshot.oldDocs.isEmpty()){let a=0;return s._snapshot.docChanges.map(c=>{yt(s._snapshot.query)?no(s._snapshot.query):To(s.query._query);const h=new ys(s._firestore,s._userDataWriter,c.doc.key,c.doc,new ir(s._snapshot.mutatedKeys.has(c.doc.key),s._snapshot.fromCache),s.query.converter);return c.doc,{type:"added",doc:h,oldIndex:-1,newIndex:a++}})}{let a=s._snapshot.oldDocs;return s._snapshot.docChanges.filter(c=>o||c.type!==3).map(c=>{const h=new ys(s._firestore,s._userDataWriter,c.doc.key,c.doc,new ir(s._snapshot.mutatedKeys.has(c.doc.key),s._snapshot.fromCache),s.query.converter);let f=-1,p=-1;return c.type!==0&&(f=a.indexOf(c.doc.key),a=a.delete(c.doc.key)),c.type!==1&&(a=a.add(c.doc),p=a.indexOf(c.doc.key)),{type:xy(c.type),doc:h,oldIndex:f,newIndex:p}})}}(this,e),this._cachedChangesIncludeMetadataChanges=e),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new L(x.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t={};t.type=tn._jsonSchemaVersion,t.bundleSource="QuerySnapshot",t.bundleName=fo.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const e=[],r=[],s=[];return this.docs.forEach(o=>{o._document!==null&&(e.push(o._document),r.push(this._userDataWriter.convertObjectMap(o._document.data.value.mapValue.fields,"previous")),s.push(o.ref.path))}),t.bundle=(this._firestore,this.query._query,t.bundleName,"NOT SUPPORTED"),t}}function xy(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return B(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */tn._jsonSchemaVersion="firestore/querySnapshot/1.0",tn._jsonSchema={type:ft("string",tn._jsonSchemaVersion),bundleSource:ft("string","QuerySnapshot"),bundleName:ft("string"),bundle:ft("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cT(n){n=Jt(n,ct);const t=Jt(n.firestore,sn),e=oi(t);return Ay(e,n._key).then(r=>Eh(t,n,r))}function lT(n){n=Jt(n,Fr);const t=Jt(n.firestore,sn),e=oi(t),r=new ra(t);return _h(n._query),Ry(e,n._query).then(s=>new tn(t,r,n,s))}function hT(n,t,e){n=Jt(n,ct);const r=Jt(n.firestore,sn),s=Cy(n.converter,t,e),o=Pm(r);return yh(r,[bm(o,"setDoc",n._key,s,n.converter!==null,e).toMutation(n._key,ie.none())])}function fT(n){return yh(Jt(n.firestore,sn),[new Eo(n._key,ie.none())])}function dT(n,...t){var f,p,m;n=Yt(n);let e={includeMetadataChanges:!1,source:"default"},r=0;typeof t[r]!="object"||uc(t[r])||(e=t[r++]);const s={includeMetadataChanges:e.includeMetadataChanges,source:e.source};if(uc(t[r])){const I=t[r];t[r]=(f=I.next)==null?void 0:f.bind(I),t[r+1]=(p=I.error)==null?void 0:p.bind(I),t[r+2]=(m=I.complete)==null?void 0:m.bind(I)}let o,a,c;if(n instanceof ct)a=Jt(n.firestore,sn),c=Gs(n._key.path),o={next:I=>{t[r]&&t[r](Eh(a,n,I))},error:t[r+1],complete:t[r+2]};else{const I=Jt(n,Fr);a=Jt(I.firestore,sn),c=I._query;const b=new ra(a);o={next:C=>{t[r]&&t[r](new tn(a,b,I,C))},error:t[r+1],complete:t[r+2]},_h(n._query)}const h=oi(a);return Iy(h,c,s,o)}function yh(n,t){const e=oi(n);return Vy(e,t)}function Eh(n,t,e){const r=e.docs.get(t._key),s=new ra(n);return new Ze(n,s,t._key,r,new ir(e.hasPendingWrites,e.fromCache),t.converter)}(function(t,e=!0){Ld(Vc),mr(new vn("firestore",(r,{instanceIdentifier:s,options:o})=>{const a=r.getProvider("app").getImmediate(),c=new sn(new Zp(r.getProvider("auth-internal")),new nm(a,r.getProvider("app-check-internal")),Gd(a,s),a);return o={useFetchStreams:e,...o},c._setSettings(o),c},"PUBLIC").setMultipleInstances(!0)),Xe(cc,lc,t),Xe(cc,lc,"esm2020")})();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Th="firebasestorage.googleapis.com",wh="storageBucket",Ny=2*60*1e3,Dy=10*60*1e3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class at extends an{constructor(t,e,r=0){super(Bi(t),`Firebase Storage: ${e} (${Bi(t)})`),this.status_=r,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,at.prototype)}get status(){return this.status_}set status(t){this.status_=t}_codeEquals(t){return Bi(t)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(t){this.customData.serverResponse=t,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}var ot;(function(n){n.UNKNOWN="unknown",n.OBJECT_NOT_FOUND="object-not-found",n.BUCKET_NOT_FOUND="bucket-not-found",n.PROJECT_NOT_FOUND="project-not-found",n.QUOTA_EXCEEDED="quota-exceeded",n.UNAUTHENTICATED="unauthenticated",n.UNAUTHORIZED="unauthorized",n.UNAUTHORIZED_APP="unauthorized-app",n.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",n.INVALID_CHECKSUM="invalid-checksum",n.CANCELED="canceled",n.INVALID_EVENT_NAME="invalid-event-name",n.INVALID_URL="invalid-url",n.INVALID_DEFAULT_BUCKET="invalid-default-bucket",n.NO_DEFAULT_BUCKET="no-default-bucket",n.CANNOT_SLICE_BLOB="cannot-slice-blob",n.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",n.NO_DOWNLOAD_URL="no-download-url",n.INVALID_ARGUMENT="invalid-argument",n.INVALID_ARGUMENT_COUNT="invalid-argument-count",n.APP_DELETED="app-deleted",n.INVALID_ROOT_OPERATION="invalid-root-operation",n.INVALID_FORMAT="invalid-format",n.INTERNAL_ERROR="internal-error",n.UNSUPPORTED_ENVIRONMENT="unsupported-environment"})(ot||(ot={}));function Bi(n){return"storage/"+n}function sa(){const n="An unknown error occurred, please check the error payload for server response.";return new at(ot.UNKNOWN,n)}function ky(n){return new at(ot.OBJECT_NOT_FOUND,"Object '"+n+"' does not exist.")}function Oy(n){return new at(ot.QUOTA_EXCEEDED,"Quota for bucket '"+n+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function Ly(){const n="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new at(ot.UNAUTHENTICATED,n)}function My(){return new at(ot.UNAUTHORIZED_APP,"This app does not have permission to access Firebase Storage on this project.")}function Uy(n){return new at(ot.UNAUTHORIZED,"User does not have permission to access '"+n+"'.")}function Fy(){return new at(ot.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function By(){return new at(ot.CANCELED,"User canceled the upload/download.")}function jy(n){return new at(ot.INVALID_URL,"Invalid URL '"+n+"'.")}function qy(n){return new at(ot.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+n+"'.")}function $y(){return new at(ot.NO_DEFAULT_BUCKET,"No default bucket found. Did you set the '"+wh+"' property when initializing the app?")}function zy(){return new at(ot.CANNOT_SLICE_BLOB,"Cannot slice blob for upload. Please retry the upload.")}function Gy(){return new at(ot.NO_DOWNLOAD_URL,"The given file does not have any download URLs.")}function Hy(n){return new at(ot.UNSUPPORTED_ENVIRONMENT,`${n} is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.`)}function uo(n){return new at(ot.INVALID_ARGUMENT,n)}function vh(){return new at(ot.APP_DELETED,"The Firebase app was deleted.")}function Wy(n){return new at(ot.INVALID_ROOT_OPERATION,"The operation '"+n+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function dr(n,t){return new at(ot.INVALID_FORMAT,"String does not match format '"+n+"': "+t)}function er(n){throw new at(ot.INTERNAL_ERROR,"Internal error: "+n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(t,e){this.bucket=t,this.path_=e}get path(){return this.path_}get isRoot(){return this.path.length===0}fullServerUrl(){const t=encodeURIComponent;return"/b/"+t(this.bucket)+"/o/"+t(this.path)}bucketOnlyServerUrl(){return"/b/"+encodeURIComponent(this.bucket)+"/o"}static makeFromBucketSpec(t,e){let r;try{r=zt.makeFromUrl(t,e)}catch{return new zt(t,"")}if(r.path==="")return r;throw qy(t)}static makeFromUrl(t,e){let r=null;const s="([A-Za-z0-9.\\-_]+)";function o(Z){Z.path.charAt(Z.path.length-1)==="/"&&(Z.path_=Z.path_.slice(0,-1))}const a="(/(.*))?$",c=new RegExp("^gs://"+s+a,"i"),h={bucket:1,path:3};function f(Z){Z.path_=decodeURIComponent(Z.path)}const p="v[A-Za-z0-9_]+",m=e.replace(/[.]/g,"\\."),I="(/([^?#]*).*)?$",b=new RegExp(`^https?://${m}/${p}/b/${s}/o${I}`,"i"),C={bucket:1,path:3},M=e===Th?"(?:storage.googleapis.com|storage.cloud.google.com)":e,k="([^?#]*)",z=new RegExp(`^https?://${M}/${s}/${k}`,"i"),J=[{regex:c,indices:h,postModify:o},{regex:b,indices:C,postModify:f},{regex:z,indices:{bucket:1,path:2},postModify:f}];for(let Z=0;Z<J.length;Z++){const ut=J[Z],lt=ut.regex.exec(t);if(lt){const w=lt[ut.indices.bucket];let g=lt[ut.indices.path];g||(g=""),r=new zt(w,g),ut.postModify(r);break}}if(r==null)throw jy(t);return r}}class Qy{constructor(t){this.promise_=Promise.reject(t)}getPromise(){return this.promise_}cancel(t=!1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ky(n,t,e){let r=1,s=null,o=null,a=!1,c=0;function h(){return c===2}let f=!1;function p(...k){f||(f=!0,t.apply(null,k))}function m(k){s=setTimeout(()=>{s=null,n(b,h())},k)}function I(){o&&clearTimeout(o)}function b(k,...z){if(f){I();return}if(k){I(),p.call(null,k,...z);return}if(h()||a){I(),p.call(null,k,...z);return}r<64&&(r*=2);let J;c===1?(c=2,J=0):J=(r+Math.random())*1e3,m(J)}let C=!1;function M(k){C||(C=!0,I(),!f&&(s!==null?(k||(c=2),clearTimeout(s),m(0)):k||(c=1)))}return m(0),o=setTimeout(()=>{a=!0,M(!0)},e),M}function Xy(n){n(!1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jy(n){return n!==void 0}function Yy(n){return typeof n=="object"&&!Array.isArray(n)}function ia(n){return typeof n=="string"||n instanceof String}function hc(n){return oa()&&n instanceof Blob}function oa(){return typeof Blob<"u"}function fc(n,t,e,r){if(r<t)throw uo(`Invalid value for '${n}'. Expected ${t} or greater.`);if(r>e)throw uo(`Invalid value for '${n}'. Expected ${e} or less.`)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function aa(n,t,e){let r=t;return e==null&&(r=`https://${t}`),`${e}://${r}/v0${n}`}function Ih(n){const t=encodeURIComponent;let e="?";for(const r in n)if(n.hasOwnProperty(r)){const s=t(r)+"="+t(n[r]);e=e+s+"&"}return e=e.slice(0,-1),e}var en;(function(n){n[n.NO_ERROR=0]="NO_ERROR",n[n.NETWORK_ERROR=1]="NETWORK_ERROR",n[n.ABORT=2]="ABORT"})(en||(en={}));/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zy(n,t){const e=n>=500&&n<600,s=[408,429].indexOf(n)!==-1,o=t.indexOf(n)!==-1;return e||s||o}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tE{constructor(t,e,r,s,o,a,c,h,f,p,m,I=!0,b=!1){this.url_=t,this.method_=e,this.headers_=r,this.body_=s,this.successCodes_=o,this.additionalRetryCodes_=a,this.callback_=c,this.errorCallback_=h,this.timeout_=f,this.progressCallback_=p,this.connectionFactory_=m,this.retry=I,this.isUsingEmulator=b,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((C,M)=>{this.resolve_=C,this.reject_=M,this.start_()})}start_(){const t=(r,s)=>{if(s){r(!1,new ls(!1,null,!0));return}const o=this.connectionFactory_();this.pendingConnection_=o;const a=c=>{const h=c.loaded,f=c.lengthComputable?c.total:-1;this.progressCallback_!==null&&this.progressCallback_(h,f)};this.progressCallback_!==null&&o.addUploadProgressListener(a),o.send(this.url_,this.method_,this.isUsingEmulator,this.body_,this.headers_).then(()=>{this.progressCallback_!==null&&o.removeUploadProgressListener(a),this.pendingConnection_=null;const c=o.getErrorCode()===en.NO_ERROR,h=o.getStatus();if(!c||Zy(h,this.additionalRetryCodes_)&&this.retry){const p=o.getErrorCode()===en.ABORT;r(!1,new ls(!1,null,p));return}const f=this.successCodes_.indexOf(h)!==-1;r(!0,new ls(f,o))})},e=(r,s)=>{const o=this.resolve_,a=this.reject_,c=s.connection;if(s.wasSuccessCode)try{const h=this.callback_(c,c.getResponse());Jy(h)?o(h):o()}catch(h){a(h)}else if(c!==null){const h=sa();h.serverResponse=c.getErrorText(),this.errorCallback_?a(this.errorCallback_(c,h)):a(h)}else if(s.canceled){const h=this.appDelete_?vh():By();a(h)}else{const h=Fy();a(h)}};this.canceled_?e(!1,new ls(!1,null,!0)):this.backoffId_=Ky(t,e,this.timeout_)}getPromise(){return this.promise_}cancel(t){this.canceled_=!0,this.appDelete_=t||!1,this.backoffId_!==null&&Xy(this.backoffId_),this.pendingConnection_!==null&&this.pendingConnection_.abort()}}class ls{constructor(t,e,r){this.wasSuccessCode=t,this.connection=e,this.canceled=!!r}}function eE(n,t){t!==null&&t.length>0&&(n.Authorization="Firebase "+t)}function nE(n,t){n["X-Firebase-Storage-Version"]="webjs/"+(t??"AppManager")}function rE(n,t){t&&(n["X-Firebase-GMPID"]=t)}function sE(n,t){t!==null&&(n["X-Firebase-AppCheck"]=t)}function iE(n,t,e,r,s,o,a=!0,c=!1){const h=Ih(n.urlParams),f=n.url+h,p=Object.assign({},n.headers);return rE(p,t),eE(p,e),nE(p,o),sE(p,r),new tE(f,n.method,p,n.body,n.successCodes,n.additionalRetryCodes,n.handler,n.errorHandler,n.timeout,n.progressCallback,s,a,c)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oE(){return typeof BlobBuilder<"u"?BlobBuilder:typeof WebKitBlobBuilder<"u"?WebKitBlobBuilder:void 0}function aE(...n){const t=oE();if(t!==void 0){const e=new t;for(let r=0;r<n.length;r++)e.append(n[r]);return e.getBlob()}else{if(oa())return new Blob(n);throw new at(ot.UNSUPPORTED_ENVIRONMENT,"This browser doesn't seem to support creating Blobs")}}function uE(n,t,e){return n.webkitSlice?n.webkitSlice(t,e):n.mozSlice?n.mozSlice(t,e):n.slice?n.slice(t,e):null}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cE(n){if(typeof atob>"u")throw Hy("base-64");return atob(n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xt={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"};class ji{constructor(t,e){this.data=t,this.contentType=e||null}}function Ah(n,t){switch(n){case Xt.RAW:return new ji(Rh(t));case Xt.BASE64:case Xt.BASE64URL:return new ji(Vh(n,t));case Xt.DATA_URL:return new ji(hE(t),fE(t))}throw sa()}function Rh(n){const t=[];for(let e=0;e<n.length;e++){let r=n.charCodeAt(e);if(r<=127)t.push(r);else if(r<=2047)t.push(192|r>>6,128|r&63);else if((r&64512)===55296)if(!(e<n.length-1&&(n.charCodeAt(e+1)&64512)===56320))t.push(239,191,189);else{const o=r,a=n.charCodeAt(++e);r=65536|(o&1023)<<10|a&1023,t.push(240|r>>18,128|r>>12&63,128|r>>6&63,128|r&63)}else(r&64512)===56320?t.push(239,191,189):t.push(224|r>>12,128|r>>6&63,128|r&63)}return new Uint8Array(t)}function lE(n){let t;try{t=decodeURIComponent(n)}catch{throw dr(Xt.DATA_URL,"Malformed data URL.")}return Rh(t)}function Vh(n,t){switch(n){case Xt.BASE64:{const s=t.indexOf("-")!==-1,o=t.indexOf("_")!==-1;if(s||o)throw dr(n,"Invalid character '"+(s?"-":"_")+"' found: is it base64url encoded?");break}case Xt.BASE64URL:{const s=t.indexOf("+")!==-1,o=t.indexOf("/")!==-1;if(s||o)throw dr(n,"Invalid character '"+(s?"+":"/")+"' found: is it base64 encoded?");t=t.replace(/-/g,"+").replace(/_/g,"/");break}}let e;try{e=cE(t)}catch(s){throw s.message.includes("polyfill")?s:dr(n,"Invalid character found")}const r=new Uint8Array(e.length);for(let s=0;s<e.length;s++)r[s]=e.charCodeAt(s);return r}class Ph{constructor(t){this.base64=!1,this.contentType=null;const e=t.match(/^data:([^,]+)?,/);if(e===null)throw dr(Xt.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");const r=e[1]||null;r!=null&&(this.base64=dE(r,";base64"),this.contentType=this.base64?r.substring(0,r.length-7):r),this.rest=t.substring(t.indexOf(",")+1)}}function hE(n){const t=new Ph(n);return t.base64?Vh(Xt.BASE64,t.rest):lE(t.rest)}function fE(n){return new Ph(n).contentType}function dE(n,t){return n.length>=t.length?n.substring(n.length-t.length)===t:!1}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pe{constructor(t,e){let r=0,s="";hc(t)?(this.data_=t,r=t.size,s=t.type):t instanceof ArrayBuffer?(e?this.data_=new Uint8Array(t):(this.data_=new Uint8Array(t.byteLength),this.data_.set(new Uint8Array(t))),r=this.data_.length):t instanceof Uint8Array&&(e?this.data_=t:(this.data_=new Uint8Array(t.length),this.data_.set(t)),r=t.length),this.size_=r,this.type_=s}size(){return this.size_}type(){return this.type_}slice(t,e){if(hc(this.data_)){const r=this.data_,s=uE(r,t,e);return s===null?null:new Pe(s)}else{const r=new Uint8Array(this.data_.buffer,t,e-t);return new Pe(r,!0)}}static getBlob(...t){if(oa()){const e=t.map(r=>r instanceof Pe?r.data_:r);return new Pe(aE.apply(null,e))}else{const e=t.map(a=>ia(a)?Ah(Xt.RAW,a).data:a.data_);let r=0;e.forEach(a=>{r+=a.byteLength});const s=new Uint8Array(r);let o=0;return e.forEach(a=>{for(let c=0;c<a.length;c++)s[o++]=a[c]}),new Pe(s,!0)}}uploadData(){return this.data_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bh(n){let t;try{t=JSON.parse(n)}catch{return null}return Yy(t)?t:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pE(n){if(n.length===0)return null;const t=n.lastIndexOf("/");return t===-1?"":n.slice(0,t)}function mE(n,t){const e=t.split("/").filter(r=>r.length>0).join("/");return n.length===0?e:n+"/"+e}function Sh(n){const t=n.lastIndexOf("/",n.length-2);return t===-1?n:n.slice(t+1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gE(n,t){return t}class xt{constructor(t,e,r,s){this.server=t,this.local=e||t,this.writable=!!r,this.xform=s||gE}}let hs=null;function _E(n){return!ia(n)||n.length<2?n:Sh(n)}function Ch(){if(hs)return hs;const n=[];n.push(new xt("bucket")),n.push(new xt("generation")),n.push(new xt("metageneration")),n.push(new xt("name","fullPath",!0));function t(o,a){return _E(a)}const e=new xt("name");e.xform=t,n.push(e);function r(o,a){return a!==void 0?Number(a):a}const s=new xt("size");return s.xform=r,n.push(s),n.push(new xt("timeCreated")),n.push(new xt("updated")),n.push(new xt("md5Hash",null,!0)),n.push(new xt("cacheControl",null,!0)),n.push(new xt("contentDisposition",null,!0)),n.push(new xt("contentEncoding",null,!0)),n.push(new xt("contentLanguage",null,!0)),n.push(new xt("contentType",null,!0)),n.push(new xt("metadata","customMetadata",!0)),hs=n,hs}function yE(n,t){function e(){const r=n.bucket,s=n.fullPath,o=new zt(r,s);return t._makeStorageReference(o)}Object.defineProperty(n,"ref",{get:e})}function EE(n,t,e){const r={};r.type="file";const s=e.length;for(let o=0;o<s;o++){const a=e[o];r[a.local]=a.xform(r,t[a.server])}return yE(r,n),r}function xh(n,t,e){const r=bh(t);return r===null?null:EE(n,r,e)}function TE(n,t,e,r){const s=bh(t);if(s===null||!ia(s.downloadTokens))return null;const o=s.downloadTokens;if(o.length===0)return null;const a=encodeURIComponent;return o.split(",").map(f=>{const p=n.bucket,m=n.fullPath,I="/b/"+a(p)+"/o/"+a(m),b=aa(I,e,r),C=Ih({alt:"media",token:f});return b+C})[0]}function wE(n,t){const e={},r=t.length;for(let s=0;s<r;s++){const o=t[s];o.writable&&(e[o.server]=n[o.local])}return JSON.stringify(e)}class Nh{constructor(t,e,r,s){this.url=t,this.method=e,this.handler=r,this.timeout=s,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dh(n){if(!n)throw sa()}function vE(n,t){function e(r,s){const o=xh(n,s,t);return Dh(o!==null),o}return e}function IE(n,t){function e(r,s){const o=xh(n,s,t);return Dh(o!==null),TE(o,s,n.host,n._protocol)}return e}function kh(n){function t(e,r){let s;return e.getStatus()===401?e.getErrorText().includes("Firebase App Check token is invalid")?s=My():s=Ly():e.getStatus()===402?s=Oy(n.bucket):e.getStatus()===403?s=Uy(n.path):s=r,s.status=e.getStatus(),s.serverResponse=r.serverResponse,s}return t}function AE(n){const t=kh(n);function e(r,s){let o=t(r,s);return r.getStatus()===404&&(o=ky(n.path)),o.serverResponse=s.serverResponse,o}return e}function RE(n,t,e){const r=t.fullServerUrl(),s=aa(r,n.host,n._protocol),o="GET",a=n.maxOperationRetryTime,c=new Nh(s,o,IE(n,e),a);return c.errorHandler=AE(t),c}function VE(n,t){return n&&n.contentType||t&&t.type()||"application/octet-stream"}function PE(n,t,e){const r=Object.assign({},e);return r.fullPath=n.path,r.size=t.size(),r.contentType||(r.contentType=VE(null,t)),r}function bE(n,t,e,r,s){const o=t.bucketOnlyServerUrl(),a={"X-Goog-Upload-Protocol":"multipart"};function c(){let J="";for(let Z=0;Z<2;Z++)J=J+Math.random().toString().slice(2);return J}const h=c();a["Content-Type"]="multipart/related; boundary="+h;const f=PE(t,r,s),p=wE(f,e),m="--"+h+`\r
Content-Type: application/json; charset=utf-8\r
\r
`+p+`\r
--`+h+`\r
Content-Type: `+f.contentType+`\r
\r
`,I=`\r
--`+h+"--",b=Pe.getBlob(m,r,I);if(b===null)throw zy();const C={name:f.fullPath},M=aa(o,n.host,n._protocol),k="POST",z=n.maxUploadRetryTime,W=new Nh(M,k,vE(n,e),z);return W.urlParams=C,W.headers=a,W.body=b.uploadData(),W.errorHandler=kh(t),W}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SE{constructor(){this.sent_=!1,this.xhr_=new XMLHttpRequest,this.initXhr(),this.errorCode_=en.NO_ERROR,this.sendPromise_=new Promise(t=>{this.xhr_.addEventListener("abort",()=>{this.errorCode_=en.ABORT,t()}),this.xhr_.addEventListener("error",()=>{this.errorCode_=en.NETWORK_ERROR,t()}),this.xhr_.addEventListener("load",()=>{t()})})}send(t,e,r,s,o){if(this.sent_)throw er("cannot .send() more than once");if(Us(t)&&r&&(this.xhr_.withCredentials=!0),this.sent_=!0,this.xhr_.open(e,t,!0),o!==void 0)for(const a in o)o.hasOwnProperty(a)&&this.xhr_.setRequestHeader(a,o[a].toString());return s!==void 0?this.xhr_.send(s):this.xhr_.send(),this.sendPromise_}getErrorCode(){if(!this.sent_)throw er("cannot .getErrorCode() before sending");return this.errorCode_}getStatus(){if(!this.sent_)throw er("cannot .getStatus() before sending");try{return this.xhr_.status}catch{return-1}}getResponse(){if(!this.sent_)throw er("cannot .getResponse() before sending");return this.xhr_.response}getErrorText(){if(!this.sent_)throw er("cannot .getErrorText() before sending");return this.xhr_.statusText}abort(){this.xhr_.abort()}getResponseHeader(t){return this.xhr_.getResponseHeader(t)}addUploadProgressListener(t){this.xhr_.upload!=null&&this.xhr_.upload.addEventListener("progress",t)}removeUploadProgressListener(t){this.xhr_.upload!=null&&this.xhr_.upload.removeEventListener("progress",t)}}class CE extends SE{initXhr(){this.xhr_.responseType="text"}}function Oh(){return new CE}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(t,e){this._service=t,e instanceof zt?this._location=e:this._location=zt.makeFromUrl(e,t.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(t,e){return new on(t,e)}get root(){const t=new zt(this._location.bucket,"");return this._newRef(this._service,t)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return Sh(this._location.path)}get storage(){return this._service}get parent(){const t=pE(this._location.path);if(t===null)return null;const e=new zt(this._location.bucket,t);return new on(this._service,e)}_throwIfRoot(t){if(this._location.path==="")throw Wy(t)}}function Lh(n,t,e){n._throwIfRoot("uploadBytes");const r=bE(n.storage,n._location,Ch(),new Pe(t,!0),e);return n.storage.makeRequestWithTokens(r,Oh).then(s=>({metadata:s,ref:n}))}function xE(n,t,e=Xt.RAW,r){n._throwIfRoot("uploadString");const s=Ah(e,t),o={...r};return o.contentType==null&&s.contentType!=null&&(o.contentType=s.contentType),Lh(n,s.data,o)}function NE(n){n._throwIfRoot("getDownloadURL");const t=RE(n.storage,n._location,Ch());return n.storage.makeRequestWithTokens(t,Oh).then(e=>{if(e===null)throw Gy();return e})}function DE(n,t){const e=mE(n._location.path,t),r=new zt(n._location.bucket,e);return new on(n.storage,r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kE(n){return/^[A-Za-z]+:\/\//.test(n)}function OE(n,t){return new on(n,t)}function Mh(n,t){if(n instanceof ua){const e=n;if(e._bucket==null)throw $y();const r=new on(e,e._bucket);return t!=null?Mh(r,t):r}else return t!==void 0?DE(n,t):n}function LE(n,t){if(t&&kE(t)){if(n instanceof ua)return OE(n,t);throw uo("To use ref(service, url), the first argument must be a Storage instance.")}else return Mh(n,t)}function dc(n,t){const e=t==null?void 0:t[wh];return e==null?null:zt.makeFromBucketSpec(e,n)}function ME(n,t,e,r={}){n.host=`${t}:${e}`;const s=Us(t);s&&vc(`https://${n.host}/b`),n._isUsingEmulator=!0,n._protocol=s?"https":"http";const{mockUserToken:o}=r;o&&(n._overrideAuthToken=typeof o=="string"?o:Tc(o,n.app.options.projectId))}class ua{constructor(t,e,r,s,o,a=!1){this.app=t,this._authProvider=e,this._appCheckProvider=r,this._url=s,this._firebaseVersion=o,this._isUsingEmulator=a,this._bucket=null,this._host=Th,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=Ny,this._maxUploadRetryTime=Dy,this._requests=new Set,s!=null?this._bucket=zt.makeFromBucketSpec(s,this._host):this._bucket=dc(this._host,this.app.options)}get host(){return this._host}set host(t){this._host=t,this._url!=null?this._bucket=zt.makeFromBucketSpec(this._url,t):this._bucket=dc(t,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(t){fc("time",0,Number.POSITIVE_INFINITY,t),this._maxUploadRetryTime=t}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(t){fc("time",0,Number.POSITIVE_INFINITY,t),this._maxOperationRetryTime=t}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const t=this._authProvider.getImmediate({optional:!0});if(t){const e=await t.getToken();if(e!==null)return e.accessToken}return null}async _getAppCheckToken(){if(Rc(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const t=this._appCheckProvider.getImmediate({optional:!0});return t?(await t.getToken()).token:null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(t=>t.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(t){return new on(this,t)}_makeRequest(t,e,r,s,o=!0){if(this._deleted)return new Qy(vh());{const a=iE(t,this._appId,r,s,e,this._firebaseVersion,o,this._isUsingEmulator);return this._requests.add(a),a.getPromise().then(()=>this._requests.delete(a),()=>this._requests.delete(a)),a}}async makeRequestWithTokens(t,e){const[r,s]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(t,e,r,s).getPromise()}}const pc="@firebase/storage",mc="0.14.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Uh="storage";function pT(n,t,e){return n=Yt(n),Lh(n,t,e)}function mT(n,t,e,r){return n=Yt(n),xE(n,t,e,r)}function gT(n){return n=Yt(n),NE(n)}function _T(n,t){return n=Yt(n),LE(n,t)}function yT(n=Pc(),t){n=Yt(n);const r=Ac(n,Uh).getImmediate({identifier:t}),s=yc("storage");return s&&UE(r,...s),r}function UE(n,t,e,r={}){ME(n,t,e,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function FE(n,{instanceIdentifier:t}){const e=n.getProvider("app").getImmediate(),r=n.getProvider("auth-internal"),s=n.getProvider("app-check-internal");return new ua(e,r,s,t,Vc)}function BE(){mr(new vn(Uh,FE,"PUBLIC").setMultipleInstances(!0)),Xe(pc,mc,""),Xe(pc,mc,"esm2020")}BE();export{QE as A,zE as B,vn as C,Sf as D,wc as E,an as F,WE as G,dT as H,vc as I,XE as J,JE as K,X as L,_T as M,Xe as N,iT as O,hT as P,pT as Q,mT as R,Vc as S,Ac as _,Ic as a,Rc as b,mr as c,If as d,rT as e,ZE as f,Ts as g,fT as h,sT as i,YE as j,Pc as k,tT as l,bf as m,cT as n,lT as o,gT as p,$E as q,oT as r,Yt as s,yT as t,lo as u,Rd as v,HE as w,Us as x,GE as y,KE as z};
