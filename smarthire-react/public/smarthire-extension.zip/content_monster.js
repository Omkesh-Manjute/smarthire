// SmartHire Sourcing Copilot - Monster+ Content Script (Auto-Click Deep Scraper & Multi-Field Search)
(function() {
  window.smartHirePortal = 'Monster+';
  console.log('[SmartHire Copilot] Monster+ scraper v2.0 initialized on:', window.location.href);

  const utils = window.SmartHireUtils;
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Helper: Clean candidate name (strip Monster accessible text like "Open In New Tab")
  function cleanCandidateName(raw) {
    if (!raw) return '';
    return raw
      .replace(/open\s*in\s*new\s*tab/gi, '')
      .replace(/view\s*profile/gi, '')
      .replace(/^[\s\S]*?(?:Candidate|Profile|Name:)?\s*/i, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Helper: Find all candidate card elements on Monster+
  function getMonsterCards() {
    // 1. Browserflow verified selector: smui-card
    const smuiCards = document.querySelectorAll('smui-card, [class*="smui-card"]');
    if (smuiCards && smuiCards.length > 0) {
      return Array.from(smuiCards);
    }

    // 2. Standard candidate list item containers
    const selectors = [
      '[data-testid*="candidate-card"]',
      '[data-testid*="candidate-item"]',
      '[data-testid*="search-result"]',
      '[class*="CandidateCard"]',
      '[class*="candidate-card"]',
      'article[class*="candidate"]',
      'div[data-candidate-id]'
    ];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      if (els && els.length > 0) return Array.from(els);
    }

    // 3. Fallback: links with /candidate/ or candidate name headings
    const profileLinks = document.querySelectorAll('a[href*="/candidate/"], a[href*="/profile/"]');
    const parents = new Set();
    const list = [];
    profileLinks.forEach(link => {
      const parent = link.closest('smui-card') || link.closest('article') || link.closest('li') || link.parentElement?.parentElement;
      if (parent && !parents.has(parent)) {
        parents.add(parent);
        list.push(parent);
      }
    });
    return list;
  }

  // Helper: Extract contact info from right detail pane
  function extractFromDetailPane() {
    // Detail pane typically contains Profile, Resume tabs, and Phone/Email text
    const allDivs = document.querySelectorAll('div, section, aside');
    let detailContainer = null;

    for (const d of allDivs) {
      const txt = d.innerText || '';
      if ((txt.includes('Phone:') || txt.includes('Email:')) && (txt.includes('Resume') || txt.includes('Profile') || txt.includes('Home:'))) {
        detailContainer = d;
        break;
      }
    }

    if (!detailContainer) {
      detailContainer = document.querySelector('[role="dialog"], [data-testid*="drawer"], [class*="drawer"], [class*="Drawer"], [class*="detail"], aside');
    }

    if (!detailContainer) return null;

    const detailText = detailContainer.innerText || '';
    let phone = '';
    let email = '';

    // Direct label extraction
    const phoneMatch = detailText.match(/(?:Phone|Mobile|Cell|Direct|Home|Work):\s*([+\d\s().-]+)/i);
    if (phoneMatch && phoneMatch[1].trim().length >= 7) {
      phone = phoneMatch[1].trim();
    } else {
      const phones = utils.extractPhones(detailText);
      if (phones.length > 0) phone = phones[0];
    }

    const emailMatch = detailText.match(/(?:Email|Mail):\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i);
    if (emailMatch) {
      email = emailMatch[1].trim().toLowerCase();
    } else {
      const emails = utils.extractEmails(detailText);
      if (emails.length > 0) email = emails[0];
    }

    // Name in detail pane
    const nameEl = detailContainer.querySelector('h1, h2, h3, [class*="name"], [class*="Name"]');
    const name = nameEl ? cleanCandidateName(nameEl.innerText) : '';

    // Location in detail pane
    let location = '';
    const locMatch = detailText.match(/\b([A-Z][a-zA-Z\s.-]+),\s*([A-Z]{2}|[A-Za-z\s]+),\s*United States\b/);
    if (locMatch) {
      location = locMatch[0].replace(', United States', '').trim();
    }

    return { phone, email, name, location, rawText: detailText };
  }

  // 1. Asynchronous Deep Scraper (Auto-clicks each card to extract Email & Phone like Browserflow)
  window.smartHireScrapeCandidatesAsync = async function(onProgress) {
    const cards = getMonsterCards();
    console.log(`[SmartHire Copilot] Found ${cards.length} cards for deep scrape.`);

    const candidates = [];
    const seenNames = new Set();

    if (cards.length === 0) {
      // If no cards found, check if a detail pane is currently open
      const detail = extractFromDetailPane();
      if (detail && detail.name) {
        candidates.push({
          id: `mon-single-${Date.now()}`,
          name: detail.name,
          title: 'Candidate Profile',
          email: detail.email || `${detail.name.toLowerCase().replace(/\s+/g, '.')}@monster.talent`,
          phone: detail.phone || '',
          location: detail.location || 'United States',
          experience: utils.extractExperience(detail.rawText) || '7+ Years',
          skills: [],
          source: 'Monster+',
          profileUrl: window.location.href,
          notes: 'Captured directly from active Monster+ view'
        });
      }
      return candidates;
    }

    // Sequential loop over cards (Browserflow model)
    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      try {
        const cardText = card.innerText || '';

        // Extract basic info from card
        const nameEl = card.querySelector('h2, h3, h4, a, [class*="name"], [class*="Name"]');
        let name = nameEl ? cleanCandidateName(nameEl.innerText) : '';
        if (name.includes('\n')) name = name.split('\n')[0].trim();
        name = cleanCandidateName(name);

        if (!name || name.length < 2 || name.toLowerCase().includes('monster') || seenNames.has(name.toLowerCase())) {
          continue;
        }

        if (typeof onProgress === 'function') {
          onProgress(`Extracting candidate ${i + 1} of ${cards.length}: ${name}...`);
        }

        // Job Title from card
        let title = 'Professional';
        const lines = cardText.split('\n').map(l => l.trim()).filter(Boolean);
        for (const line of lines) {
          const cleanLine = cleanCandidateName(line);
          if (cleanLine && cleanLine !== name && cleanLine.length > 3 && !cleanLine.includes('Updated') && !cleanLine.includes('Current:') && !cleanLine.includes('Previous:') && !cleanLine.includes('Top Skills:')) {
            title = cleanLine;
            break;
          }
        }

        // Location from card
        let location = '';
        const locMatch = cardText.match(/\b([A-Z][a-zA-Z\s.-]+),\s*([A-Z]{2}|[A-Za-z\s]+)\b/);
        if (locMatch && !locMatch[0].includes('Brooks Tractor') && !locMatch[0].includes('Geek Squad')) {
          location = locMatch[0].trim();
        }

        // Experience & Recency
        const experience = utils.extractExperience(cardText) || '7+ Years';
        let recency = 'Active on Monster+';
        const recMatch = cardText.match(/Updated:\s*([^\n\r·]+)/i);
        if (recMatch) recency = `Updated ${recMatch[1].trim()}`;

        // Skills from card
        const skills = [];
        const skillMatch = cardText.match(/Top Skills:\s*([^\n\r]+)/i);
        if (skillMatch) {
          const rawSkills = skillMatch[1].replace(/\+\d+\s*more/i, '').split(',');
          rawSkills.forEach(s => {
            const trimmed = s.trim();
            if (trimmed && !skills.includes(trimmed)) skills.push(trimmed);
          });
        }

        // AUTO-CLICK CARD TO REVEAL DETAIL PANE (Just like Browserflow)
        const clickTarget = card.querySelector('a, h2, h3, [role="button"]') || card;
        clickTarget.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        clickTarget.click();

        // Wait for right pane to update with this candidate's details
        await sleep(400);

        // Extract contact info from right detail pane
        let phone = '';
        let email = '';
        const detail = extractFromDetailPane();
        if (detail) {
          if (detail.phone) phone = detail.phone;
          if (detail.email) email = detail.email;
          if (detail.location && !location) location = detail.location;
        }

        // Fallback to card text regex if detail pane didn't render
        if (!email) {
          const emails = utils.extractEmails(cardText);
          if (emails.length > 0) email = emails[0];
        }
        if (!phone) {
          const phones = utils.extractPhones(cardText);
          if (phones.length > 0) phone = phones[0];
        }

        seenNames.add(name.toLowerCase());

        candidates.push({
          id: `mon-${i}-${Date.now().toString().slice(-4)}`,
          name,
          title: title.slice(0, 80),
          email: email || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@monster.talent`,
          phone: phone || '',
          location: location || 'United States',
          experience,
          skills: skills.slice(0, 10),
          source: 'Monster+',
          recency,
          profileUrl: window.location.href,
          notes: `${recency} · Sourced from Monster+ candidate search.`
        });
      } catch (err) {
        console.warn(`[SmartHire Copilot] Error scraping card ${i}:`, err);
      }
    }

    if (typeof onProgress === 'function') {
      onProgress(`✓ Extracted ${candidates.length} candidates from Monster+!`);
    }

    return candidates;
  };

  // Synchronous quick fallback
  window.smartHireScrapeCandidates = function() {
    const cards = getMonsterCards();
    const candidates = [];
    const detail = extractFromDetailPane();

    cards.forEach((card, i) => {
      const cardText = card.innerText || '';
      const nameEl = card.querySelector('h2, h3, h4, a, [class*="name"]');
      let name = nameEl ? cleanCandidateName(nameEl.innerText) : '';
      if (name.includes('\n')) name = name.split('\n')[0].trim();
      name = cleanCandidateName(name);
      if (!name || name.length < 2 || name.toLowerCase().includes('monster')) return;

      const emails = utils.extractEmails(cardText);
      const phones = utils.extractPhones(cardText);

      // If active detail matches this candidate name, attach detail phone & email
      let email = emails[0] || '';
      let phone = phones[0] || '';
      if (detail && detail.name && detail.name.toLowerCase().includes(name.toLowerCase())) {
        if (detail.email) email = detail.email;
        if (detail.phone) phone = detail.phone;
      }

      candidates.push({
        id: `mon-sync-${i}-${Date.now().toString().slice(-4)}`,
        name,
        title: 'Professional',
        email: email || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@monster.talent`,
        phone,
        location: 'United States',
        experience: utils.extractExperience(cardText) || '7+ Years',
        skills: [],
        source: 'Monster+',
        profileUrl: window.location.href
      });
    });

    return candidates;
  };

  // 2. Comprehensive 1-Click Search Auto-Fill for Monster+ (Dashboard & Results Sidebar)
  window.smartHireAutoFillSearch = function({ title, skillsQuery, query, location }) {
    console.log('[SmartHire Copilot] Auto-filling Monster+ search with:', { title, skillsQuery, query, location });
    const cleanTitle = (title || '').replace(/\(.*?\)/g, '').replace(/\[.*?\]/g, '').trim();
    const cleanSkills = skillsQuery || query || '';
    const cleanLoc = (location || '').toLowerCase() === 'remote' ? '' : (location || '');

    let filledCount = 0;

    // Helper: Find input by placeholder, label text, or aria-label
    function findInput(patterns) {
      const allInputs = Array.from(document.querySelectorAll('input[type="text"], input[type="search"], input:not([type])'));
      for (const pattern of patterns) {
        for (const inp of allInputs) {
          const ph = (inp.placeholder || '').toLowerCase();
          const name = (inp.name || '').toLowerCase();
          const id = (inp.id || '').toLowerCase();
          const aria = (inp.getAttribute('aria-label') || '').toLowerCase();
          const parentText = (inp.closest('div')?.parentElement?.innerText || '').toLowerCase();

          if (
            ph.includes(pattern) ||
            name.includes(pattern) ||
            id.includes(pattern) ||
            aria.includes(pattern) ||
            parentText.startsWith(pattern)
          ) {
            return inp;
          }
        }
      }
      return null;
    }

    // A. Fill Job Title input
    const titleInp = findInput(['cook, developer, nurse', 'job title', 'jobtitle', 'title']);
    if (titleInp && cleanTitle) {
      utils.setNativeValue(titleInp, cleanTitle);
      filledCount++;
    }

    // B. Fill Skills / Keywords input
    const skillsInp = findInput(['javascript, management, finance', 'skills / keywords', 'skills/keywords', 'boolean', 'skills', 'keyword']);
    if (skillsInp && cleanSkills) {
      utils.setNativeValue(skillsInp, cleanSkills);
      filledCount++;
    }

    // C. Fill Location input
    const locInp = findInput(['city, state, or zip', 'city, state', 'location', 'zip']);
    if (locInp && cleanLoc) {
      utils.setNativeValue(locInp, cleanLoc);
      filledCount++;
    }

    // D. Check for UPDATE button on Search Results page (Image 2/3 purple button)
    const updateButtons = Array.from(document.querySelectorAll('button'));
    const updateBtn = updateButtons.find(b => {
      const txt = (b.innerText || '').trim().toUpperCase();
      return txt === 'UPDATE' || txt.includes('UPDATE SEARCH');
    });

    if (updateBtn) {
      setTimeout(() => { updateBtn.click(); }, 300);
      return `Filled Title, Skills, and Location, and clicked UPDATE!`;
    }

    // E. Check for Find Candidates / Search button on Dashboard (Image 1)
    const searchBtn = updateButtons.find(b => {
      const txt = (b.innerText || '').toLowerCase();
      return txt.includes('find candidates') || txt.includes('search') || b.getAttribute('data-testid')?.includes('search');
    });

    if (searchBtn) {
      setTimeout(() => { searchBtn.click(); }, 300);
      return `Filled Title, Skills, and Location, and triggered Find Candidates!`;
    } else if (titleInp || skillsInp || locInp) {
      // Trigger Enter on the last filled input
      const targetInp = locInp || skillsInp || titleInp;
      targetInp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
      return `Injected search criteria and submitted form!`;
    } else {
      // Direct navigation fallback
      const directUrl = `https://manage.monster.com/en-us/candidateSearch/job?title=${encodeURIComponent(cleanTitle)}&keywords=${encodeURIComponent(cleanSkills)}&location=${encodeURIComponent(cleanLoc)}`;
      window.location.href = directUrl;
      return `Navigating directly to Monster+ search.`;
    }
  };
})();
