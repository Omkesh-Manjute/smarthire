// SmartHire Sourcing Copilot - Monster+ Content Script
(function() {
  window.smartHirePortal = 'Monster+';
  console.log('[SmartHire Copilot] Monster+ scraper initialized on:', window.location.href);

  // Main scraper function for Monster+ candidate results
  window.smartHireScrapeCandidates = function() {
    const candidates = [];
    const utils = window.SmartHireUtils;

    // 1. First, check if a candidate detail drawer/modal is currently open
    const drawer = document.querySelector('[role="dialog"], [data-testid*="drawer"], [class*="drawer"], [class*="Drawer"], [class*="CandidateDetail"]');
    if (drawer) {
      const drawerText = drawer.innerText || '';
      const nameEl = drawer.querySelector('h1, h2, [data-testid*="candidate-name"], [class*="name"]');
      const drawerName = nameEl ? utils.cleanText(nameEl.innerText) : '';
      
      if (drawerName && drawerName.length > 2 && !drawerName.toLowerCase().includes('monster')) {
        const titleEl = drawer.querySelector('h3, [data-testid*="candidate-title"], [class*="title"], [class*="Headline"]');
        const phones = utils.extractPhones(drawerText);
        const emails = utils.extractEmails(drawerText);
        const exp = utils.extractExperience(drawerText);
        
        candidates.push({
          id: `mon-drawer-${Date.now()}`,
          name: drawerName,
          title: titleEl ? utils.cleanText(titleEl.innerText) : 'Candidate',
          email: emails[0] || `${drawerName.toLowerCase().replace(/\s+/g, '.')}@monster.talent`,
          phone: phones[0] || '',
          location: extractLocationFromText(drawerText),
          experience: exp || '7+ Years',
          skills: extractSkillsFromContainer(drawer),
          source: 'Monster+ Active Drawer',
          profileUrl: window.location.href,
          notes: 'Captured directly from open Monster+ detail drawer'
        });
      }
    }

    // 2. Query all candidate card elements on search results page
    const cardSelectors = [
      '[data-testid*="candidate-card"]',
      '[data-testid*="candidate-item"]',
      '[data-testid*="search-result"]',
      '[class*="CandidateCard"]',
      '[class*="candidate-card"]',
      '[class*="CandidateListItem"]',
      '[class*="search-result-item"]',
      'article[class*="candidate"]',
      'div[data-candidate-id]',
      'tr[class*="candidate"]'
    ];

    let cardElements = [];
    for (const sel of cardSelectors) {
      const els = document.querySelectorAll(sel);
      if (els && els.length > 0) {
        cardElements = Array.from(els);
        break;
      }
    }

    // Fallback: if no custom candidate classes match, find links that point to /candidate or /profile
    if (cardElements.length === 0) {
      const profileLinks = document.querySelectorAll('a[href*="/candidate/"], a[href*="/profile/"], a[href*="/candidates/"]');
      const parents = new Set();
      profileLinks.forEach(link => {
        let parent = link.closest('article') || link.closest('li') || link.closest('tr') || link.closest('div[class*="card"]') || link.parentElement?.parentElement;
        if (parent && !parents.has(parent)) {
          parents.add(parent);
          cardElements.push(parent);
        }
      });
    }

    console.log(`[SmartHire Copilot] Found ${cardElements.length} candidate card elements on Monster+`);

    cardElements.forEach((card, index) => {
      try {
        const cardText = card.innerText || '';
        
        // Candidate Name
        const nameEl = card.querySelector('h2, h3, h4, a[data-testid*="name"], a[href*="/candidate/"], a[href*="/profile/"], [class*="name"], [class*="Name"]');
        let name = nameEl ? utils.cleanText(nameEl.innerText) : '';
        
        // Strip prefixes/titles like "Dr.", "Mr." or click hints
        name = name.replace(/^[\s\S]*?(?:Candidate|Profile|Name:)?\s*/i, '').trim();
        if (name.includes('\n')) name = name.split('\n')[0].trim();
        if (!name || name.length < 2 || name.toLowerCase().includes('monster') || name.toLowerCase() === 'search') return;

        // Job Title
        const titleEl = card.querySelector('[data-testid*="title"], [class*="title"], [class*="Title"], [class*="headline"], [class*="Headline"], [class*="position"], p, span');
        let title = titleEl ? utils.cleanText(titleEl.innerText) : 'Professional';
        if (title.toLowerCase() === name.toLowerCase()) {
          // Find next sibling
          const nextP = card.querySelectorAll('p, span');
          for (const p of nextP) {
            const txt = utils.cleanText(p.innerText);
            if (txt && txt !== name && txt.length > 3 && !txt.includes('$') && !txt.includes('Updated')) {
              title = txt;
              break;
            }
          }
        }

        // Contact info: emails & phones
        const emails = utils.extractEmails(cardText);
        const phones = utils.extractPhones(cardText);

        // Experience
        const experience = utils.extractExperience(cardText) || '7+ Years';

        // Location
        const location = extractLocationFromText(cardText);

        // Skills
        const skills = extractSkillsFromContainer(card);

        // Profile link
        const linkEl = card.querySelector('a[href*="/candidate/"], a[href*="/profile/"], a[href*="/candidates/"]') || card.querySelector('a');
        let profileUrl = linkEl ? linkEl.href : window.location.href;

        // Recency
        let updated = 'Active on Monster+';
        const updatedMatch = cardText.match(/Updated\s+[^·\n\r|]+/i);
        if (updatedMatch) updated = updatedMatch[0];

        candidates.push({
          id: `mon-${index}-${Date.now().toString().slice(-4)}`,
          name,
          title: title.slice(0, 80),
          email: emails[0] || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@monster.talent`,
          phone: phones[0] || '',
          location: location || 'United States',
          experience,
          skills: skills.slice(0, 10),
          source: 'Monster+',
          recency: updated,
          profileUrl,
          notes: `${updated} · Sourced from Monster+ candidate search.`
        });
      } catch (err) {
        console.warn('[SmartHire Copilot] Error parsing Monster candidate card:', err);
      }
    });

    // Helper: Location extractor
    function extractLocationFromText(text) {
      if (!text) return '';
      // Look for City, State pattern (e.g., Richmond, VA or Columbia, SC)
      const locMatch = text.match(/\b([A-Z][a-zA-Z\s.-]+),\s*([A-Z]{2})\b/);
      if (locMatch) {
        return `${locMatch[1].trim()}, ${locMatch[2].trim()}`;
      }
      if (text.toLowerCase().includes('remote')) return 'Remote';
      return '';
    }

    // Helper: Skills extractor from card badges/chips
    function extractSkillsFromContainer(container) {
      const skills = [];
      const skillEls = container.querySelectorAll('[data-testid*="skill"], [class*="skill"], [class*="Skill"], [class*="chip"], [class*="Chip"], [class*="badge"], [class*="Badge"], [class*="tag"], [class*="Tag"]');
      skillEls.forEach(el => {
        const txt = utils.cleanText(el.innerText);
        if (txt && txt.length > 1 && txt.length < 35 && !txt.includes('Updated') && !skills.includes(txt)) {
          skills.push(txt);
        }
      });
      return skills;
    }

    // Deduplicate by name
    const unique = [];
    const seen = new Set();
    for (const c of candidates) {
      const key = c.name.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(c);
      }
    }

    return unique;
  };

  // 1-Click Search Auto-Fill for Monster+
  window.smartHireAutoFillSearch = function(query, location) {
    const utils = window.SmartHireUtils;
    console.log('[SmartHire Copilot] Auto-filling Monster+ search:', { query, location });

    // 1. Locate Query Input
    const querySelectors = [
      'input[data-testid*="search-input"]',
      'input[data-testid*="keyword"]',
      'input[placeholder*="Job title, skills"]',
      'input[placeholder*="Search by job title"]',
      'input[placeholder*="keyword"]',
      'input[name="q"]',
      'input[name="keyword"]',
      '#search-input',
      '#keywords'
    ];
    let queryInput = null;
    for (const sel of querySelectors) {
      const el = document.querySelector(sel);
      if (el) { queryInput = el; break; }
    }

    // 2. Locate Location Input
    const locSelectors = [
      'input[data-testid*="location-input"]',
      'input[placeholder*="City, state"]',
      'input[placeholder*="Location"]',
      'input[name="location"]',
      '#location-input',
      '#location'
    ];
    let locInput = null;
    for (const sel of locSelectors) {
      const el = document.querySelector(sel);
      if (el) { locInput = el; break; }
    }

    if (queryInput && query) {
      utils.setNativeValue(queryInput, query);
    }

    if (locInput && location && location !== 'Remote') {
      utils.setNativeValue(locInput, location);
    }

    // 3. Locate Search Button
    const btnSelectors = [
      'button[data-testid*="search-submit"]',
      'button[data-testid*="search-button"]',
      'button[type="submit"]',
      'button[class*="search-button"]',
      'button[class*="submit"]'
    ];
    let searchBtn = null;
    for (const sel of btnSelectors) {
      const el = document.querySelector(sel);
      if (el) { searchBtn = el; break; }
    }

    if (searchBtn) {
      setTimeout(() => {
        searchBtn.click();
      }, 300);
      return 'Injected Boolean query and triggered Monster+ search!';
    } else if (queryInput) {
      // Simulate Enter key
      queryInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
      return 'Injected Boolean query and dispatched Enter key!';
    } else {
      // Direct navigation fallback
      const encodedQ = encodeURIComponent(query);
      const encodedL = encodeURIComponent(location || '');
      window.location.href = `https://manage.monster.com/candidates/search?q=${encodedQ}&location=${encodedL}`;
      return 'Navigating directly to Monster+ search with query.';
    }
  };
})();
