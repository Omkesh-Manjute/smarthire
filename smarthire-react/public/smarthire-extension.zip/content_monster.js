// SmartHire Sourcing Copilot - Monster+ Content Script (Auto-Click Deep Scraper & Multi-Field Search)
(function() {
  window.smartHirePortal = 'Monster+';
  console.log('[SmartHire Copilot] Monster+ scraper v3.0 initialized on:', window.location.href);

  const utils = window.SmartHireUtils;
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Helper: Clean candidate name (strip Monster accessible noise & prefixes)
  window.extractCleanMonsterName = function(raw) {
    if (!raw) return '';
    
    // Pattern 1: Select a Card Number-X, [NAME] · Favorite
    const cardMatch = raw.match(/Select\s+a\s+Card\s+Number-\d+,\s*([^·\n\r]+?)(?:\s*·|\s*Favorite|\s*Open\s*In\s*New\s*Tab|$)/i);
    if (cardMatch && cardMatch[1].trim().length > 1) {
      return cardMatch[1].replace(/open\s*in\s*new\s*tab/gi, '').replace(/\s+/g, ' ').trim();
    }

    // Pattern 2: Strip known phrases
    let str = raw
      .replace(/Select\s+a\s+Card\s+Number-\d+,?\s*/gi, '')
      .replace(/Favorite\s+[^\n\r·]+/gi, '')
      .replace(/Open\s*In\s*New\s*Tab/gi, '')
      .replace(/Veteran\s*Diversity/gi, '')
      .replace(/Updated\s*[:\s]*[^\n\r·]+/gi, '')
      .replace(/^[\s\S]*?(?:Candidate|Profile|Name:)?\s*/i, '')
      .trim();

    const lines = str.split('\n').map(l => l.trim()).filter(Boolean);
    const candidateLine = lines[0] || '';
    return candidateLine.replace(/open\s*in\s*new\s*tab/gi, '').replace(/\s+/g, ' ').trim();
  };

  // Helper: Find all candidate card elements on Monster+
  function getMonsterCards() {
    // 1. Browserflow verified selector: smui-card
    const smuiCards = document.querySelectorAll('smui-card, [class*="smui-card"]');
    if (smuiCards && smuiCards.length > 0) {
      return Array.from(smuiCards);
    }

    // 2. Standard candidate list item containers
    const selectors = [
      '[data-testid*="candidate-card"]',
      '[data-testid*="candidate-item"]',
      '[data-testid*="search-result"]',
      '[class*="CandidateCard"]',
      '[class*="candidate-card"]',
      'article[class*="candidate"]',
      'div[data-candidate-id]'
    ];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      if (els && els.length > 0) return Array.from(els);
    }

    // 3. Fallback: links with /candidate/ or candidate name headings
    const profileLinks = document.querySelectorAll('a[href*="/candidate/"], a[href*="/profile/"]');
    const parents = new Set();
    const list = [];
    profileLinks.forEach(link => {
      const parent = link.closest('smui-card') || link.closest('article') || link.closest('li') || link.parentElement?.parentElement;
      if (parent && !parents.has(parent)) {
        parents.add(parent);
        list.push(parent);
      }
    });
    return list;
  }

  // Helper: Extract contact info from #contact-legend-detail (Browserflow exact selector!)
  function extractContactLegend() {
    let phone = '';
    let email = '';
    let rawText = '';

    // Direct Browserflow selector: #contact-legend-detail
    const contactBox = document.querySelector('#contact-legend-detail, [id*="contact-legend"]');
    if (contactBox) {
      rawText = contactBox.innerText || '';

      const emailEl = contactBox.querySelector('a[href^="mailto:"]');
      if (emailEl) {
        email = emailEl.href.replace('mailto:', '').trim().toLowerCase();
      } else {
        const emailMatch = rawText.match(/(?:Email|Mail)?\s*[:\s]?\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i);
        if (emailMatch) email = emailMatch[1].trim().toLowerCase();
      }

      const phoneEl = contactBox.querySelector('a[href^="tel:"]');
      if (phoneEl) {
        phone = phoneEl.href.replace('tel:', '').trim();
      } else {
        const phoneMatch = rawText.match(/(?:Phone|Mobile|Cell|Direct|Home|Work)?\s*[:\s]?\s*([+\d\s().-]{10,})/i);
        if (phoneMatch) phone = phoneMatch[1].trim();
      }
    }

    // Fallback: search right detail container if #contact-legend-detail not directly found
    if (!email || !phone) {
      const allDivs = document.querySelectorAll('div, section, aside');
      for (const d of allDivs) {
        const txt = d.innerText || '';
        if ((txt.includes('Phone:') || txt.includes('Email:') || txt.includes('@')) && (txt.includes('Resume') || txt.includes('Profile') || txt.includes('Home:'))) {
          if (!email) {
            const em = txt.match(/(?:Email|Mail)?\s*[:\s]?\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i);
            if (em && !em[1].includes('monster.com')) email = em[1].trim().toLowerCase();
          }
          if (!phone) {
            const ph = txt.match(/(?:Phone|Mobile|Cell|Direct|Home|Work)?\s*[:\s]?\s*([+\d\s().-]{10,})/i);
            if (ph && ph[1].replace(/\D/g, '').length >= 10) phone = ph[1].trim();
          }
          if (email && phone) {
            rawText = txt;
            break;
          }
        }
      }
    }

    return { phone, email, rawText };
  }

  // 1. Asynchronous Deep Scraper (Auto-clicks each card to extract Email & Phone like Browserflow)
  window.smartHireScrapeCandidatesAsync = async function(onProgress) {
    const cards = getMonsterCards();
    console.log(`[SmartHire Copilot] Found ${cards.length} cards for deep scrape.`);

    const candidates = [];
    const seenNames = new Set();

    // Sequential loop over cards (Browserflow model)
    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      try {
        const cardText = card.innerText || '';

        // Extract clean candidate name
        const nameEl = card.querySelector('a, h2, h3, h4, [class*="name"], [class*="Name"]') || card;
        let name = window.extractCleanMonsterName(nameEl.innerText || cardText);

        if (!name || name.length < 2 || name.toLowerCase().includes('monster') || seenNames.has(name.toLowerCase())) {
          continue;
        }

        if (typeof onProgress === 'function') {
          onProgress(`Extracting candidate ${i + 1} of ${cards.length}: ${name}...`);
        }

        // Job Title from card
        let title = 'Business Analyst';
        const lines = cardText.split('\n').map(l => l.trim()).filter(Boolean);
        for (const line of lines) {
          const cleanLine = window.extractCleanMonsterName(line);
          if (
            cleanLine &&
            cleanLine !== name &&
            cleanLine.length > 3 &&
            !cleanLine.includes('Updated') &&
            !cleanLine.includes('Current:') &&
            !cleanLine.includes('Previous:') &&
            !cleanLine.includes('Top Skills:') &&
            !cleanLine.includes('Select a Card')
          ) {
            title = cleanLine;
            break;
          }
        }

        // Location from card
        let location = '';
        const locMatch = cardText.match(/\b([A-Z][a-zA-Z\s.-]+),\s*([A-Z]{2}|[A-Za-z\s]+)\b/);
        if (locMatch && !locMatch[0].includes('Select a Card') && !locMatch[0].includes('Open In')) {
          location = locMatch[0].trim();
        }

        // Experience & Recency
        const experience = utils.extractExperience(cardText) || '7+ Years';
        let recency = 'Active on Monster+';
        const recMatch = cardText.match(/Updated:\s*([^\n\r·]+)/i);
        if (recMatch) recency = `Updated ${recMatch[1].trim()}`;

        // Skills from card
        const skills = [];
        const skillMatch = cardText.match(/Top Skills:\s*([^\n\r]+)/i);
        if (skillMatch) {
          const rawSkills = skillMatch[1].replace(/\+\d+\s*more/i, '').split(',');
          rawSkills.forEach(s => {
            const trimmed = s.trim();
            if (trimmed && !skills.includes(trimmed)) skills.push(trimmed);
          });
        }

        // AUTO-CLICK CARD TO REVEAL DETAIL PANE & #contact-legend-detail
        const clickTarget = card.querySelector('a, button, h2, h3, [role="button"]') || card;
        clickTarget.scrollIntoView({ behavior: 'auto', block: 'nearest' });
        clickTarget.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        clickTarget.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        clickTarget.click();

        // Wait 500ms for Monster to render #contact-legend-detail for this candidate
        await sleep(500);

        // Extract contact info from #contact-legend-detail!
        let phone = '';
        let email = '';
        const contact = extractContactLegend();
        if (contact) {
          if (contact.phone) phone = contact.phone;
          if (contact.email) email = contact.email;
        }

        // Fallback to card text regex if detail pane didn't render
        if (!email) {
          const emails = utils.extractEmails(cardText);
          if (emails.length > 0) email = emails[0];
        }
        if (!phone) {
          const phones = utils.extractPhones(cardText);
          if (phones.length > 0) phone = phones[0];
        }

        seenNames.add(name.toLowerCase());

        candidates.push({
          id: `mon-${i}-${Date.now().toString().slice(-4)}`,
          name,
          title: title.slice(0, 80),
          email: email || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@monster.talent`,
          phone: phone || '',
          location: location || 'United States',
          experience,
          skills: skills.slice(0, 10),
          source: 'Monster+',
          recency,
          profileUrl: window.location.href,
          notes: `${recency} · Sourced from Monster+ candidate search.`
        });
      } catch (err) {
        console.warn(`[SmartHire Copilot] Error scraping card ${i}:`, err);
      }
    }

    if (typeof onProgress === 'function') {
      onProgress(`✓ Extracted ${candidates.length} candidates from Monster+!`);
    }

    return candidates;
  };

  // Synchronous quick fallback
  window.smartHireScrapeCandidates = function() {
    const cards = getMonsterCards();
    const candidates = [];
    const contact = extractContactLegend();

    cards.forEach((card, i) => {
      const cardText = card.innerText || '';
      const nameEl = card.querySelector('a, h2, h3, h4, [class*="name"]') || card;
      let name = window.extractCleanMonsterName(nameEl.innerText || cardText);
      if (!name || name.length < 2 || name.toLowerCase().includes('monster')) return;

      const emails = utils.extractEmails(cardText);
      const phones = utils.extractPhones(cardText);

      let email = (i === 0 && contact.email) ? contact.email : (emails[0] || '');
      let phone = (i === 0 && contact.phone) ? contact.phone : (phones[0] || '');

      candidates.push({
        id: `mon-sync-${i}-${Date.now().toString().slice(-4)}`,
        name,
        title: 'Candidate Profile',
        email: email || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@monster.talent`,
        phone,
        location: 'United States',
        experience: utils.extractExperience(cardText) || '7+ Years',
        skills: [],
        source: 'Monster+',
        profileUrl: window.location.href
      });
    });

    return candidates;
  };

  // 2. Comprehensive 1-Click Search Auto-Fill for Monster+ (Dashboard & Results Sidebar)
  window.smartHireAutoFillSearch = function({ title, skillsQuery, query, location }) {
    console.log('[SmartHire Copilot] Auto-filling Monster+ search with:', { title, skillsQuery, query, location });
    const cleanTitle = (title || '').replace(/\(.*?\)/g, '').replace(/\[.*?\]/g, '').trim();
    const cleanSkills = skillsQuery || query || '';
    const cleanLoc = (location || '').toLowerCase() === 'remote' ? '' : (location || '');

    let filledCount = 0;

    // Helper: Find input by placeholder, label text, or aria-label
    function findInput(patterns) {
      const allInputs = Array.from(document.querySelectorAll('input[type="text"], input[type="search"], input:not([type])'));
      for (const pattern of patterns) {
        for (const inp of allInputs) {
          const ph = (inp.placeholder || '').toLowerCase();
          const name = (inp.name || '').toLowerCase();
          const id = (inp.id || '').toLowerCase();
          const aria = (inp.getAttribute('aria-label') || '').toLowerCase();
          const parentText = (inp.closest('div')?.parentElement?.innerText || '').toLowerCase();

          if (
            ph.includes(pattern) ||
            name.includes(pattern) ||
            id.includes(pattern) ||
            aria.includes(pattern) ||
            parentText.startsWith(pattern)
          ) {
            return inp;
          }
        }
      }
      return null;
    }

    // A. Fill Job Title input
    const titleInp = findInput(['cook, developer, nurse', 'job title', 'jobtitle', 'title']);
    if (titleInp && cleanTitle) {
      utils.setNativeValue(titleInp, cleanTitle);
      filledCount++;
    }

    // B. Fill Skills / Keywords input
    const skillsInp = findInput(['javascript, management, finance', 'skills / keywords', 'skills/keywords', 'boolean', 'skills', 'keyword']);
    if (skillsInp && cleanSkills) {
      utils.setNativeValue(skillsInp, cleanSkills);
      filledCount++;
    }

    // C. Fill Location input
    const locInp = findInput(['city, state, or zip', 'city, state', 'location', 'zip']);
    if (locInp && cleanLoc) {
      utils.setNativeValue(locInp, cleanLoc);
      filledCount++;
    }

    // D. Check for UPDATE button on Search Results page (Image 2/3 purple button)
    const updateButtons = Array.from(document.querySelectorAll('button'));
    const updateBtn = updateButtons.find(b => {
      const txt = (b.innerText || '').trim().toUpperCase();
      return txt === 'UPDATE' || txt.includes('UPDATE SEARCH');
    });

    if (updateBtn) {
      setTimeout(() => { updateBtn.click(); }, 300);
      return `Filled Title, Skills, and Location, and clicked UPDATE!`;
    }

    // E. Check for Find Candidates / Search button on Dashboard (Image 1)
    const searchBtn = updateButtons.find(b => {
      const txt = (b.innerText || '').toLowerCase();
      return txt.includes('find candidates') || txt.includes('search') || b.getAttribute('data-testid')?.includes('search');
    });

    if (searchBtn) {
      setTimeout(() => { searchBtn.click(); }, 300);
      return `Filled Title, Skills, and Location, and triggered Find Candidates!`;
    } else if (titleInp || skillsInp || locInp) {
      const targetInp = locInp || skillsInp || titleInp;
      targetInp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
      return `Injected search criteria and submitted form!`;
    } else {
      const directUrl = `https://manage.monster.com/en-us/candidateSearch/job?title=${encodeURIComponent(cleanTitle)}&keywords=${encodeURIComponent(cleanSkills)}&location=${encodeURIComponent(cleanLoc)}`;
      window.location.href = directUrl;
      return `Navigating directly to Monster+ search.`;
    }
  };
})();
