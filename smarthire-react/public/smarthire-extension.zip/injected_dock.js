// SmartHire Sourcing Copilot - Injected In-Page Sidebar Dock
(function() {
  if (window.__smartHireDockInjected) return;
  window.__smartHireDockInjected = true;

  let scrapedCandidates = [];
  let currentJobs = [];
  let selectedJob = null;

  function initDock() {
    // 1. Floating Compact Trigger Button (Logo only - no long text strip)
    const trigger = document.createElement('div');
    trigger.id = 'smarthire-copilot-trigger';
    trigger.title = 'SmartHire ATS Sourcing Copilot (Click to Open)';
    trigger.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="#3B82F6">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <path d="m9 11 2 2 4-4" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
      </svg>
    `;

    // 2. Slide-out Drawer Panel
    const drawer = document.createElement('div');
    drawer.id = 'smarthire-copilot-drawer';
    drawer.innerHTML = `
      <div class="smarthire-drawer-header">
        <div style="display:flex; align-items:center; gap:8px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#3B82F6">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <path d="m9 11 2 2 4-4" stroke="#ffffff" stroke-width="2.5" fill="none"/>
          </svg>
          <span style="font-weight:700; font-size:14px; letter-spacing:-0.02em;">SmartHire Copilot</span>
        </div>
        <button id="smarthire-drawer-close" style="background:none; border:none; color:#94A3B8; font-size:20px; cursor:pointer; line-height:1;">&times;</button>
      </div>

      <div class="smarthire-drawer-body">
        <div class="smarthire-card">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <label class="smarthire-label" style="margin-bottom:0;">Target ATS Requisition</label>
            <span id="smarthire-refresh-jobs" style="font-size:10px; color:#2563EB; cursor:pointer; font-weight:600;">Refresh</span>
          </div>
          <select id="smarthire-req-select" class="smarthire-select">
            <option value="">Loading requisitions from SmartHire ATS...</option>
          </select>
          <div id="smarthire-req-info" style="margin-top:8px; font-size:11px; color:#475569; display:none;"></div>
          <button id="smarthire-btn-autosearch" class="smarthire-btn-secondary" style="display:none; margin-top:8px;">
            🔍 Auto-Fill Search on Current Page
          </button>
        </div>

        <div class="smarthire-card">
          <label class="smarthire-label">Current Page Extraction</label>
          <button id="smarthire-btn-scrape" class="smarthire-btn-primary">
            ⚡ 1-Click Scrape Candidates
          </button>
          <div id="smarthire-scrape-status" style="margin-top:8px; font-size:11px; color:#64748B; text-align:center; font-weight:500;">
            Extracts names, verified emails & phone numbers from cards & detail pane
          </div>
        </div>

        <div id="smarthire-results-card" class="smarthire-card" style="display:none;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <label class="smarthire-label" style="margin-bottom:0;">Scraped Candidates (<span id="smarthire-count">0</span>)</label>
            <span id="smarthire-portal-tag" style="background:#EFF6FF; color:#1D4ED8; font-size:10px; font-weight:700; padding:2px 6px; border-radius:4px; text-transform:uppercase;"></span>
          </div>

          <div id="smarthire-candidate-preview-list" style="max-height:220px; overflow-y:auto; border:1px solid #E2E8F0; border-radius:4px; background:#FFFFFF; margin-bottom:10px;">
          </div>

          <button id="smarthire-btn-copy-tsv" class="smarthire-btn-secondary">
            📋 Copy to Clipboard (Excel Format)
          </button>
          <button id="smarthire-btn-import-ats" class="smarthire-btn-primary" style="background:#059669;">
            🚀 1-Click Import to SmartHire ATS
          </button>
          <div id="smarthire-import-msg" style="margin-top:6px; font-size:11px; text-align:center; font-weight:600;"></div>
        </div>
      </div>
    `;

    document.body.appendChild(trigger);
    document.body.appendChild(drawer);

    // Event handlers
    trigger.addEventListener('click', () => {
      drawer.classList.add('open');
      loadRequisitions();
    });

    document.getElementById('smarthire-drawer-close').addEventListener('click', () => {
      drawer.classList.remove('open');
    });

    document.getElementById('smarthire-refresh-jobs').addEventListener('click', () => {
      loadRequisitions();
    });

    document.getElementById('smarthire-btn-scrape').addEventListener('click', () => {
      runInPageScrape();
    });

    document.getElementById('smarthire-btn-copy-tsv').addEventListener('click', () => {
      copyCandidatesToClipboard();
    });

    document.getElementById('smarthire-btn-import-ats').addEventListener('click', () => {
      importToSmartHireAts();
    });

    document.getElementById('smarthire-req-select').addEventListener('change', (e) => {
      const reqId = e.target.value;
      selectedJob = currentJobs.find(j => String(j.id || j.reqId) === String(reqId));
      updateJobDisplay();
    });

    document.getElementById('smarthire-btn-autosearch').addEventListener('click', () => {
      if (!selectedJob) return;
      const title = (selectedJob.title || selectedJob.positionTitle || '').replace(/\(.*?\)/g, '').replace(/\[.*?\]/g, '').trim();
      const skillsQuery = generateBooleanQuery(selectedJob);
      const loc = selectedJob.location || selectedJob.city || '';
      const status = document.getElementById('smarthire-scrape-status');
      
      if (typeof window.smartHireAutoFillSearch === 'function') {
        const resMsg = window.smartHireAutoFillSearch({
          title,
          skillsQuery,
          query: skillsQuery,
          location: loc
        });
        status.innerText = resMsg || 'Search parameters injected!';
      }
    });
  }

  // Load Requisitions via Background (bypasses Monster CSP)
  function loadRequisitions() {
    const select = document.getElementById('smarthire-req-select');
    select.innerHTML = '<option value="">Loading requisitions from SmartHire ATS...</option>';

    chrome.runtime.sendMessage({ action: 'FETCH_JOBS' }, (response) => {
      if (response && response.success && Array.isArray(response.jobs) && response.jobs.length > 0) {
        currentJobs = response.jobs;
        renderJobOptions(response.jobs);
      } else {
        // Fallback direct fetch
        fetch('https://smarthireus.com/api/jobs')
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data) && data.length > 0) {
              currentJobs = data;
              renderJobOptions(data);
            } else {
              renderFallbackJobs();
            }
          })
          .catch(() => renderFallbackJobs());
      }
    });
  }

  function renderJobOptions(jobs) {
    const select = document.getElementById('smarthire-req-select');
    select.innerHTML = '<option value="">-- Select Requisition (' + jobs.length + ' Available) --</option>' +
      jobs.map(j => {
        const id = j.id || j.reqId;
        const title = j.title || j.positionTitle || 'Open Requisition';
        const loc = j.location || (j.city ? `${j.city}, ${j.state || ''}` : 'Remote');
        return `<option value="${id}">#${id} · ${title} (${loc})</option>`;
      }).join('');

    if (jobs.length > 0 && !selectedJob) {
      selectedJob = jobs[0];
      select.value = jobs[0].id || jobs[0].reqId;
      updateJobDisplay();
    }
  }

  function renderFallbackJobs() {
    const fallback = [
      { id: '159287', title: 'Microsoft .NET Developer', location: 'Richmond, VA', skills: ['.NET Core', 'C#', 'SQL Server', 'Angular', 'Web API'] },
      { id: '159023', title: 'Business Analyst', location: 'Columbia, SC', skills: ['SharePoint', 'MS Excel', 'Agile', 'Requirements Gathering'] },
      { id: '159281', title: 'Information Technology Administrator', location: 'Madison, WI', skills: ['Windows Server', 'SOC', 'Active Directory', 'Azure'] }
    ];
    currentJobs = fallback;
    renderJobOptions(fallback);
  }

  function updateJobDisplay() {
    const info = document.getElementById('smarthire-req-info');
    const autoBtn = document.getElementById('smarthire-btn-autosearch');
    if (!selectedJob) {
      info.style.display = 'none';
      autoBtn.style.display = 'none';
      return;
    }
    const skills = Array.isArray(selectedJob.skills) ? selectedJob.skills.slice(0, 5).join(', ') : (selectedJob.skills || 'General');
    info.style.display = 'block';
    info.innerHTML = `<strong>Location:</strong> ${selectedJob.location || 'Remote'}<br/><strong>Key Skills:</strong> ${skills}`;
    autoBtn.style.display = 'flex';
  }

  function generateBooleanQuery(job) {
    const title = (job.title || job.positionTitle || '').replace(/\(.*?\)/g, '').replace(/\[.*?\]/g, '').trim();
    const skills = Array.isArray(job.skills) ? job.skills.slice(0, 3) : (job.skills ? String(job.skills).split(',').slice(0, 3) : []);
    if (skills.length > 0) {
      const skillClause = skills.map(s => `"${s.trim()}"`).join(' OR ');
      return `("${title}") AND (${skillClause})`;
    }
    return `"${title}"`;
  }

  // Run scraper on current page (Deep Click-through extraction)
  async function runInPageScrape() {
    const status = document.getElementById('smarthire-scrape-status');
    const scrapeBtn = document.getElementById('smarthire-btn-scrape');
    scrapeBtn.disabled = true;
    scrapeBtn.style.opacity = '0.7';
    status.innerText = 'Starting automated candidate extraction...';

    try {
      let list = [];
      if (typeof window.smartHireScrapeCandidatesAsync === 'function') {
        list = await window.smartHireScrapeCandidatesAsync((progressMsg) => {
          status.innerText = progressMsg;
        });
      } else if (typeof window.smartHireScrapeCandidates === 'function') {
        list = window.smartHireScrapeCandidates();
      } else if (typeof window.genericFallbackScrape === 'function') {
        list = window.genericFallbackScrape();
      }

      scrapedCandidates = list;
      status.innerText = `✓ Extracted ${list.length} candidate(s) with contact details!`;

      const resultsCard = document.getElementById('smarthire-results-card');
      const countEl = document.getElementById('smarthire-count');
      const portalEl = document.getElementById('smarthire-portal-tag');
      const previewList = document.getElementById('smarthire-candidate-preview-list');

      if (list.length > 0) {
        resultsCard.style.display = 'block';
        countEl.innerText = list.length;
        portalEl.innerText = window.smartHirePortal || 'Monster / Dice';

        previewList.innerHTML = list.map((c, i) => {
          const hasPhone = c.phone && !c.phone.includes('555-0199');
          const hasEmail = c.email && !c.email.includes('@monster.talent') && !c.email.includes('@dice.talent');
          return `
            <div style="padding:8px 10px; border-bottom:1px solid #F1F5F9; font-size:11px;">
              <div style="display:flex; justify-content:space-between; align-items:center;">
                <span style="font-weight:700; color:#0F172A;">${i + 1}. ${c.name}</span>
                ${(hasPhone || hasEmail) ? '<span style="background:#DCFCE7; color:#15803D; font-size:9px; font-weight:700; padding:1px 5px; border-radius:3px;">VERIFIED</span>' : ''}
              </div>
              <div style="color:#475569; font-size:10.5px; margin-top:2px;">${c.title} · ${c.location}</div>
              <div style="margin-top:3px; font-size:10.5px; display:flex; flex-direction:column; gap:2px;">
                <div style="color:#2563EB;"><strong>Email:</strong> ${c.email || '—'}</div>
                <div style="color:#0F172A; font-family:monospace;"><strong>Phone:</strong> ${c.phone || '—'}</div>
              </div>
            </div>
          `;
        }).join('');
      } else {
        resultsCard.style.display = 'none';
        status.innerText = 'No candidates detected. Make sure you are on Monster or Dice search results.';
      }
    } catch (err) {
      console.error('[SmartHire Copilot] Scrape error:', err);
      status.innerText = `Error: ${err.message}`;
    } finally {
      scrapeBtn.disabled = false;
      scrapeBtn.style.opacity = '1';
    }
  }

  // Copy TSV to clipboard for Excel
  function copyCandidatesToClipboard() {
    if (!scrapedCandidates || scrapedCandidates.length === 0) return;
    const header = ['Sl. No', 'Candidate Name', 'Job Title', 'Email', 'Phone', 'Location', 'Experience', 'Skills', 'Source', 'Profile Link'];
    const rows = scrapedCandidates.map((c, i) => [
      i + 1,
      c.name,
      c.title,
      c.email || '',
      c.phone || '',
      c.location || '',
      c.experience || '',
      (c.skills || []).join(', '),
      c.source || window.smartHirePortal,
      c.profileUrl || ''
    ]);

    const tsv = [header.join('\t'), ...rows.map(r => r.join('\t'))].join('\n');
    navigator.clipboard.writeText(tsv).then(() => {
      const msg = document.getElementById('smarthire-import-msg');
      msg.style.color = '#059669';
      msg.innerText = '✓ Copied TSV to clipboard! Press Ctrl+V in Excel or Google Sheets.';
      setTimeout(() => { msg.innerText = ''; }, 3500);
    });
  }

  // 1-Click Import to ATS via Background (bypasses Monster CSP)
  function importToSmartHireAts() {
    const msg = document.getElementById('smarthire-import-msg');
    if (!scrapedCandidates || scrapedCandidates.length === 0) {
      msg.innerText = 'No candidates to import.';
      return;
    }

    const targetReqId = selectedJob ? (selectedJob.id || selectedJob.reqId) : null;
    msg.style.color = '#2563EB';
    msg.innerText = `Ingesting ${scrapedCandidates.length} candidate(s) to SmartHire ATS...`;

    chrome.runtime.sendMessage({
      action: 'BULK_IMPORT_ATS',
      payload: {
        candidates: scrapedCandidates,
        targetReqId,
        source: window.smartHirePortal || 'Monster+ Extension',
        recruiterEmail: 'omkesh@coolsofttech.com',
        recruiterName: 'Omkesh Manjute'
      }
    }, (response) => {
      if (response && response.success && response.data) {
        msg.style.color = '#059669';
        msg.innerText = `✓ ${response.data.message || 'Successfully imported to ATS!'}`;
      } else {
        msg.style.color = '#DC2626';
        msg.innerText = `Import failed: ${response?.error || 'Could not connect to ATS'}`;
      }
    });
  }

  // Auto-mount after DOM loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDock);
  } else {
    initDock();
  }
})();
